<?php
namespace Bullitt\Paypal\App;

use Magento\Framework\App\RequestInterface;

/**
 * Class Request
 *
 * @package Bullitt\Paypal\App
 */
class RequestDecorator implements RequestInterface
{
    /**
     * @var RequestInterface
     */
    private $originalRequest;

    /**
     * Request constructor.
     *
     * @param RequestInterface $originalRequest
     */
    public function __construct(RequestInterface $originalRequest)
    {
        $this->originalRequest = $originalRequest;
    }

    /**
     * @return array
     */
    public function getPostValue()
    {
        $post = $this->originalRequest->getPostValue();

        if (!$post) {
            $post = $this->getParams();
        }

        return $post;
    }

    /**
     * @param $method
     * @param $args
     *
     * @return null
     */
    public function __call($method, $args)
    {
        if (method_exists($this->originalRequest, $method)) {
            return $this->originalRequest->{$method}(...$args);
        }

        return null;
    }

    /**
     * Retrieve module name
     *
     * @return string
     */
    public function getModuleName()
    {
        return $this->originalRequest->getModuleName();
    }

    /**
     * Set Module name
     *
     * @param string $name
     *
     * @return $this
     */
    public function setModuleName($name)
    {
        $this->originalRequest->setModuleName($name);

        return $this;
    }

    /**
     * Retrieve action name
     *
     * @return string
     */
    public function getActionName()
    {
        return $this->originalRequest->getActionName();
    }

    /**
     * Set action name
     *
     * @param string $name
     *
     * @return $this
     */
    public function setActionName($name)
    {
        $this->originalRequest->setActionName($name);

        return $this;
    }

    /**
     * Retrieve param by key
     *
     * @param string $key
     * @param mixed  $defaultValue
     *
     * @return mixed
     */
    public function getParam($key, $defaultValue = null)
    {
        return $this->originalRequest->getParam($key, $defaultValue);
    }

    /**
     * Set params from key value array
     *
     * @param array $params
     *
     * @return $this
     */
    public function setParams(array $params)
    {
        $this->originalRequest->setParams($params);

        return $this;
    }

    /**
     * Retrieve all params as array
     *
     * @return array
     */
    public function getParams()
    {
        return $this->originalRequest->getParams();
    }

    /**
     * Retrieve cookie value
     *
     * @param string|null $name
     * @param string|null $default
     *
     * @return string|null
     */
    public function getCookie($name, $default)
    {
        return $this->originalRequest->getCookie($name, $default);
    }

    /**
     * Returns whether request was delivered over HTTPS
     *
     * @return bool
     */
    public function isSecure()
    {
        return $this->originalRequest->isSecure();
    }
}
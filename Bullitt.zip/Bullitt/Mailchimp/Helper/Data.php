<?php

namespace Bullitt\Mailchimp\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Api\CountryInformationAcquirerInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    const XML_MAILCHIMP_ENABLE          = 'custommailchimp_section/custommailchimp_group/active';
    const XML_MAILCHIMP_KEY             = 'custommailchimp_section/custommailchimp_group/api_key';
    const XML_MAILCHIMP_ENDPOINT        = 'custommailchimp_section/custommailchimp_group/api_endpoint';
    const XML_NEWSLETTER_LIST_ID        = 'custommailchimp_section/custommailchimp_group/list_id';
    const XML_NEWSLETTER_SOURCE         = 'custommailchimp_section/custommailchimp_group/source';
    const XML_NEWSLETTER_LOCALE         = 'custommailchimp_section/custommailchimp_group/locale';
    const XML_NEWSLETTER_SUBSCRIBER     = 'custommailchimp_section/custommailchimp_group/subscriber';
    const XML_DEFAULT_COUNTRY           = 'general/country/default';
    
    protected $_scopeConfig;
    protected $_request;
    protected $_storeManager;
    protected $_countryInformation;

    /**
     * @param Context $context
     */
    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        CountryInformationAcquirerInterface $countryInformation
    ) {
        $this->_scopeConfig         = $context->getScopeConfig();
        $this->_request             = $context->getRequest();
        $this->_storeManager        = $storeManager;
        $this->_countryInformation  = $countryInformation;

        parent::__construct($context);
    }

    public function getStoreViewCode() {
        $lang          = '';
        $storeViewCode = $this->_storeManager->getStore()->getCode();
        if($storeViewCode){
            $lang = strtolower(str_replace("_","-",$storeViewCode));
        }
        return $lang;
    }

    public function getCountryFullName()
    {
        $countryid      = '';
        $websiteId      = $this->_request->getParam(\Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE);
        $countryid      = $this->_scopeConfig->getValue(self::XML_DEFAULT_COUNTRY, \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE, $websiteId);
        
        if($countryid == ''){
            return 'United Kingdom';
        }
        $country        = $this->_countryInformation->getCountryInfo($countryid);
        $countryname    = $country->getFullNameEnglish();
        return $countryname;
    }

    public function isMailchimpEnable($store = null) {
        return $this->getConfigValue(self::XML_MAILCHIMP_ENABLE, $store);
    }

    public function getMailchimpApiKey($store = null) {
        return $this->getConfigValue(self::XML_MAILCHIMP_KEY, $store);
    }

    public function getMailchimpApiEndpoint($store = null) {
        return $this->getConfigValue(self::XML_MAILCHIMP_ENDPOINT, $store);
    }
    
    public function getMailchimpListId($store = null) {
        return $this->getConfigValue(self::XML_NEWSLETTER_LIST_ID, $store);
    }

    public function getSourceMerge($store = null) {
        return $this->getConfigValue(self::XML_NEWSLETTER_SOURCE, $store);
    }

        
    public function getLocaleMerge($store = null) {
        return $this->getConfigValue(self::XML_NEWSLETTER_LOCALE, $store);
    }

        
    public function getSubscriberMerge($store = null) {
        return $this->getConfigValue(self::XML_NEWSLETTER_SUBSCRIBER, $store);
    }

    public function getConfigValue($path, $storeId = null) {

        $storeId = $this->_request->getParam(\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $websiteId = $this->_request->getParam(\Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE);
        if (!empty($storeId)) {
            $configValue = $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE, $storeId);
        }elseif (!empty($websiteId)) {
            $configValue = $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE, $websiteId);
        } else {
            $configValue = $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE, 0);
        }

        return $configValue;
    }

    function mc_checklist($email, $apikey, $listid){
        $userid = md5( strtolower( $email ) );
        $auth = base64_encode( 'user:'. $apikey );
        $endpoint = $this->getMailchimpApiEndpoint();

        $data = array(
            'apikey'        => $apikey,
            'email_address' => $email
            );
        $json_data = json_encode($data);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $endpoint.$listid.'/members/' . $userid);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json',
            'Authorization: Basic '. $auth));
        curl_setopt($ch, CURLOPT_USERAGENT, 'PHP-MCAPI/2.0');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
        $result = curl_exec($ch);
        $resultarr = json_decode($result, true);
        $status = $resultarr['status'];
        return $status;
    }

}
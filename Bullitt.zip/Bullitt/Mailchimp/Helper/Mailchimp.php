<?php

namespace Bullitt\Mailchimp\Helper;

use Magento\Store\Model\Store;
use Magento\Framework\App\Helper\Context;
use Bullitt\Mailchimp\Helper\Data;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Response\RedirectInterface;

class Mailchimp extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_helper;

    /**
     * @param Context $context
     */
    public function __construct(
        Context $context, Data $helper, StoreManagerInterface $storeManager, RedirectInterface $redirect
    ) {
        $this->_scopeConfig     = $context->getScopeConfig();
        $this->_request         = $context->getRequest();
        $this->_helper          = $helper;
        $this->_storeManager    = $storeManager;
        $this->_redirect        = $redirect;
        parent::__construct($context);
    }

    function subscribeToMailchimp($email, $status){
        
        if($this->_helper->isMailchimpEnable()){
                $apiKey             =   $this->_helper->getMailchimpApiKey();
                $listID             =   $this->_helper->getMailchimpListId();
                $sourceMerge        =   $this->_helper->getSourceMerge();
                $localeMerge        =   $this->_helper->getLocaleMerge();
                $subscriberMerge    =   $this->_helper->getSubscriberMerge();

            $loginstat = $this->_helper->mc_checklist($email,$apiKey,$listID);
            $result = array();
            $msg = '';

            if($loginstat == 'subscribed'){
                    $msg = __('You are already subscribed to receive Cat phones marketing communications');
                    $result = array('type' => 'error','message' => $msg);
                    return $result;

            }else if($loginstat == 404 || 'unsubscribed'){
                $language   =   $this->_helper->getStoreViewCode();
                if($language){
                    $language = strtolower(str_replace("_","-",$language));
                }

                $country     = '';
                $country     = $this->_helper->getCountryFullName();
                if($country == 'United States'){
                    $country = 'United States of America';
                }

                $baseUrl = '';
                $baseUrl        = $this->_storeManager->getStore()->getBaseUrl();
                $referer_url    = $this->_redirect->getRefererUrl();
                $baseUrl        = rtrim($baseUrl, "/");

                $referer_url    = str_replace($baseUrl,"",$referer_url);
                $referer_url    = str_replace(".html","",$referer_url);
                $referer_url    = rtrim($referer_url, "/");
                $referer_url    = ltrim($referer_url, "/");
                
                $sourcePage     = $referer_url;


                if($sourcePage == ''){
                    $sourcePage = 'Home Page';
                }
                // MailChimp API URL
                $memberID   = md5(strtolower($email));
                $dataCenter = substr($apiKey,strpos($apiKey,'-')+1);
                $endpoint = $this->_helper->getMailchimpApiEndpoint();
                $url = $endpoint . $listID . '/members/' . $memberID;

                // member information

                 $json = json_encode([
                    'email_address' => $email,
                    'status'        => $status,
                    'merge_fields'  => [
                        'COUNTRY'           => $country,
                        "$subscriberMerge"  => '',
                        "$sourceMerge"      => $sourcePage,
                        "$localeMerge"      => $language
                    ]
                ]);

                $ch         = curl_init($url);
                curl_setopt($ch, CURLOPT_USERPWD, 'user:' . $apiKey);
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
                $result     = curl_exec($ch);
                $httpCode   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                
                $resultarr = json_decode($result, true);
                $status = $resultarr['status'];
                // store the status message based on response code
                if ($httpCode == 200) {
                    $msg = __('Thank you for subscribing!');
                    $result = array('type' => 'success','message' => $msg);
                    return $result;

                }else if($loginstat == 404){
                    $msg = __('Looks fake or invalid, please enter a real email address.');
                    $result = array('type' => 'error','message' => $msg);
                    return $result;
                } else {
                    $msg = __('An error occured');
                    $result = array('type' => 'error','message' => $msg);
                    return $result;
                }

            }else if($loginstat == 400){
                    $msg = __('An error occured');
                    $result = array('type' => 'error','message' => $msg);
                    return $result;
            }
            else{
                $msg = __('An error occured');
                $result = array('type' => 'error','message' => $msg);
                return $result;
            }
        }else{
                $msg = __('An error occured');
                $result = array('type' => 'error','message' => $msg);
                return $result;
        }
    }
}
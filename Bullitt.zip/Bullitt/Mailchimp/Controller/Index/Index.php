<?php

namespace Bullitt\Mailchimp\Controller\Index;

use Bullitt\Mailchimp\Helper\Mailchimp;

class Index extends \Magento\Framework\App\Action\Action
{

	protected $_helper;
	protected $jsonHelper;

    /**
     * @param Context $context
     */
    public function __construct(
    	\Magento\Framework\App\Action\Context $context,
        Mailchimp $helper,
        \Magento\Framework\Json\Helper\Data $jsonHelper
    ) {
        $this->_helper          = $helper;
        $this->jsonHelper = $jsonHelper;
        parent::__construct($context);
    }

    public function execute()
    {
    		$data     = $this->getRequest()->getParams();
    		$email    = $this->getRequest()->getPost('email');
    	if ($this->getRequest()->isPost() && $this->getRequest()->getPost('email')) {
    		$email = (string)$this->getRequest()->getPost('email');
    		try {
    		$result = $this->_helper->subscribeToMailchimp($email, $status='pending');
    		return $this->jsonResponse($result);
    		} catch (\Magento\Framework\Exception\LocalizedException $e) {
                $result['type'] = 'error';
                $result['message'] = $e->getMessage();
                return $this->jsonResponse($result);
            } catch (\Exception $e) {
                $result['type'] = 'error';
                $result['message'] = $e->getMessage();
                return $this->jsonResponse($result);
            }
    	}else{
        	return false;
    	}
    }

    /**
     * Create json response
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function jsonResponse($response = '')
    {
        return $this->getResponse()->representJson(
            $this->jsonHelper->jsonEncode($response)
        );
    }
}
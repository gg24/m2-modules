<?php

namespace Bullitt\Customsitemap\Model\Magento\Sitemap;


class Customsitemap extends \Magento\Sitemap\Model\Sitemap
{
    public function generateCustomXml($arra)
    {
        $this->_initSitemapItems();
        /** @var $sitemapItem \Magento\Framework\DataObject */
        $i=1;
        foreach ($this->_sitemapItems as $sitemapItem) {
            if($i<2){
            $changefreq = $sitemapItem->getChangefreq();
            $priority = $sitemapItem->getPriority();

            foreach ($sitemapItem->getCollection() as $itemex) {
           $arritem[] = array("id"=>$itemex->getId(),"url"=>$itemex->getUrl(),"updated_at" => $itemex->getUpdatedAt());
            
           }
            $finalarr = array_merge($arritem,$arra); 
            foreach ($finalarr as $item) {
                
                $xml = $this->_getSitemapRow(
                    $item['url'],
                    $item['updated_at'],
                    $changefreq,
                    $priority
                );

                if ($this->_isSplitRequired($xml) && $this->_sitemapIncrement > 0) {
                    $this->_finalizeSitemap();
                }
                if (!$this->_fileSize) {
                    $this->_createSitemap();
                }
                $this->_writeSitemapRow($xml);
                // Increase counters
                $this->_lineCount++;
                $this->_fileSize += strlen($xml);
            }
        }
           $i++;
        }

        $this->_finalizeSitemap();

            // In case when only one increment file was created use it as default sitemap
            $path = rtrim(
                $this->getSitemapPath(),
                '/'
            ) . '/' . $this->_getCurrentSitemapFilename(
                $this->_sitemapIncrement
            );
            $destination = rtrim($this->getSitemapPath(), '/') . '/' . $this->getSitemapFilename();

            $this->_directory->renameFile($path, $destination);

        // Push sitemap to robots.txt
        if ($this->_isEnabledSubmissionRobots()) {
            $this->_addSitemapToRobotsTxt($this->getSitemapFilename());
        }

        $this->setSitemapTime($this->_dateModel->gmtDate('Y-m-d H:i:s'));
        $this->save();
        return $this;
    }
    
}
<?php

namespace Bullitt\Customloviit\Model\Loviit\Loviit;

use Magento\Checkout\Model\ConfigProviderInterface;
use Loviit\Loviit\Plugin\Data as LoviitHelper;
use Loviit\Loviit\Helper\Payment as LoviitPaymentHelper;
use Loviit\Loviit\Helper\Payment;
use Magento\Checkout\Model\Session as CheckoutSession;


class LoviitConfigProvider extends \Loviit\Loviit\Model\LoviitConfigProvider
{
	
	const CODE = 'loviit_config_provider';

    protected $config;
    protected $checkoutSession;
   

    /**
     * Constructor
     *
     * @param ConfigFactory $configFactory
     * @param ResolverInterface $localeResolver
     * @param CurrentCustomer $currentCustomer
     * @param PaypalHelper $paypalHelper
     * @param PaymentHelper $paymentHelper
     * @param UrlInterface $urlBuilder
     */
    public function __construct(
    LoviitHelper $loviitHelper, LoviitPaymentHelper $paymentHelper, CheckoutSession $checkoutSession) {
        $this->loviitHelper = $loviitHelper;
        $this->loviitPaymentHelper = $paymentHelper;
        $this->checkoutSession = $checkoutSession;

    }

    public function getConfig() {
        $quote = $this->checkoutSession->getQuote();
        $config = array();
        
        
        $config['settings']['general_conditions'] = $this->loviitPaymentHelper->getLoviitConfig('general_conditions');

        // Add New Field in Backend to display Fine Trade PDF 
        $config['settings']['docomo_conditions'] = $this->loviitPaymentHelper->getLoviitConfig('docomo_conditions');

        $config['settings']['privacy_policy'] = $this->loviitPaymentHelper->getLoviitConfig('privacy_policy');
        $config['settings']['required_fields'] = $this->loviitPaymentHelper->getRequiredFieldsForThisStore($quote);
        $config['settings']['docomo_allow_different_shipping_address'] = $this->loviitPaymentHelper->getLoviitConfig('allow_different_shipping_address');
        $config['lastInstallmentUpdate'] = 1;
        
        return $config;
    }
}
	
	
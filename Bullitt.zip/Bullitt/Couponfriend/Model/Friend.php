<?php
namespace Bullitt\Couponfriend\Model;

use Bullitt\Couponfriend\Model\CouponemailFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Directory\WriteInterface;
use Magento\Framework\Controller\Result\RawFactory;
 use Magento\Framework\Filesystem\Directory\ReadFactory;

class Friend extends \Magento\Framework\DataObject
{
	protected $_modelCouponFactory;
	protected $directoryList;
	protected $resultRawFactory;

   public function __construct(
    \Bullitt\Couponfriend\Model\CouponemailFactory $modelCouponemailFactory,
     \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
    Filesystem $filesystem,
     \Magento\Framework\App\Filesystem\DirectoryList $directory_list,
     \Magento\Framework\Controller\Result\RawFactory $resultRawFactory,
      \Magento\Framework\Filesystem\Directory\ReadFactory $readFactory

     ){
    parent::__construct();
		$this->_modelCouponFactory = $modelCouponemailFactory;
        $this->_fileFactory = $fileFactory;
        $this->directory = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);
        $this->directoryList = $directory_list; 
        $this->resultRawFactory  = $resultRawFactory; 
         $this->readFactory = $readFactory;
	}
	
	public function couponemailexport($ruleId)
	{ 
		
		$couponemailsdetail = array();
		$couponemails = $this->_modelCouponFactory->create()->getCollection()->addFieldToFilter('rule_id',array('eq' => $ruleId));
   		$i=0;
		foreach($couponemails as $couponemailsdata){
			$couponemailsdetail[$i]['coupon_code'] = $couponemailsdata->getData('coupon_code');
			$couponemailsdetail[$i]['email'] = $couponemailsdata->getData('email');
			$i++;
		}
	
		$couponemailsdetails[] =  $couponemailsdetail;
		return $couponemailsdetails;

	}
	
	public function getCsvdataFile($headers,$couponemails)
    {
 		 
		$name = strtotime("now");
		
		$file = 'export/friendexport' . $name . '.csv';
		$this->directory->create('export');
		$stream = $this->directory->openFile($file, 'w+');
		$stream->lock();
		$stream->writeCsv($headers);
		foreach($couponemails as $couponemailsdata){
			$couponemailsdetail['coupon_code'] = $couponemailsdata->getData('coupon_code');
			$couponemailsdetail['email'] = $couponemailsdata->getData('email');
			$stream->writeCsv($couponemailsdetail);
		 }
		$stream->unlock();
		$stream->close();



	
		 chmod( $this->directoryList->getPath('var').'/'.$file, 0777);


		

		return [
			'type' => 'filename',
			'value' => $file,
			'rm' => true  // can delete file after use
		];

		 


		
		
 	
		
	}
}
?>
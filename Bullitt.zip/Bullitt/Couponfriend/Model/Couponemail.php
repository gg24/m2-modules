<?php
namespace Bullitt\Couponfriend\Model;

class Couponemail extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Bullitt\Couponfriend\Model\ResourceModel\Couponemail');
    }
}
?>
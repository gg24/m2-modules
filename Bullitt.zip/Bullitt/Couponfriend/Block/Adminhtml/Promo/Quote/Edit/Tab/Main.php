<?php
namespace Bullitt\Couponfriend\Block\Adminhtml\Promo\Quote\Edit\Tab;
class Main extends \Magento\Framework\View\Element\Template
{
    function _prepareLayout(){}
	
	public function getAjaxUrl(){
    return $this->getUrl("couponfriend/promo_quote/exportfriend"); // Controller Url
	}
	
	public function getRuleID() {
		 $id = $this->getRequest()->getParam('id');
		 if($id) {
			 return $id;
		 } else {
			 return false;
		 }
	}

}

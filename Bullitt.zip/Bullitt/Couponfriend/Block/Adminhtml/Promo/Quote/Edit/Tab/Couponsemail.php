<?php

namespace Bullitt\Couponfriend\Block\Adminhtml\Promo\Quote\Edit\Tab;

class Couponsemail extends \Magento\Backend\Block\Text\ListText implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Framework\View\Element\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __('Import Emails');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Import Emails');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return $this->_isEditing();
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return !$this->_isEditing();
    }

    /**
     * Check whether we edit existing rule or adding new one
     *
     * @return bool
     */
    protected function _isEditing()
    {
        $salesRule = $this->_coreRegistry->registry('current_promo_quote_rule');
        return $salesRule->getRuleId() !== null;
    }
}


/* For Template
class Couponsemail extends \Magento\Framework\View\Element\Template
{
    protected $_template = 'tab/uploadfile.phtml';

    protected $_coreRegistry = null;

    public function __construct(
        Context $context,
        Registry $registry,
        array $data = []
    )
    {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

     /**
   
    protected function _isEditing()
    {
        echo "---".$salesRule = $this->_coreRegistry->registry('current_promo_quote_rule'); die('herere');
        return $salesRule->getRuleId() !== null;
	}
} */



















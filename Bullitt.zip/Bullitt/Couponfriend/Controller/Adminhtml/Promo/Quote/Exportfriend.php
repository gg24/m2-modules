<?php
namespace Bullitt\Couponfriend\Controller\Adminhtml\Promo\Quote;

use Magento\SalesRule\Model\CouponFactory;
use Bullitt\Couponfriend\Model\CouponemailFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Directory\WriteInterface;

class Exportfriend extends \Magento\Backend\App\Action
{
    /**
     * @param Action\Context $context
     */
    
	protected $_modelCouponFactory;
	protected $_fileCsv;
	protected $_modelCouponemailFactory;
	protected $_modelFriend;
	protected $directory_list;
	protected $directory;

   public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Filesystem\DirectoryList $directory_list,
       // \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
      //  \Magento\Framework\Stdlib\DateTime\Filter\Date $dateFilter,
        \Magento\SalesRule\Model\CouponFactory $modelCouponFactory,
		\Magento\Framework\File\Csv $fileCsv,
		\Bullitt\Couponfriend\Model\Friend $modelFriend,
		\Bullitt\Couponfriend\Model\CouponemailFactory $modelCouponemailFactory,
		Filesystem $filesystem,
		\Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        $this->directory_list = $directory_list;  
        //$this->_coreRegistry = $coreRegistry;
        $this->_fileFactory = $fileFactory;
       // $this->_dateFilter = $dateFilter;
        $this->_modelCouponFactory = $modelCouponFactory;
		$this->_fileCsv = $fileCsv;
		$this->_modelCouponemailFactory = $modelCouponemailFactory;
		$this->_modelFriend = $modelFriend;
		$this->directory = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);
		$this->_storeManager = $storeManager;
    }
    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
    	 

    	$referer_url = explode('/',$this->_redirect->getRefererUrl());
		$ruleIdKey = array_keys($referer_url, "id");
		$ruleId = $referer_url[$ruleIdKey[0]+1];
    	
		$this->_modelFriend = $this->_objectManager->get('Bullitt\Couponfriend\Model\Friend');
		$csvFile = $this->_modelFriend->couponemailexport($ruleId);
		
		$heading = [
         __('Coupon Code'),
         __('Email')
     ];
   
    
     $outputFile = $this->directory->getAbsolutePath()."friendsexport". date('Ymd_His').".csv"; /// UAT
      
     $handle = fopen($outputFile, 'w+');
      chmod( $outputFile, 0777);
     fputcsv($handle, $heading);
     foreach ($csvFile as $coupon) {
     	foreach($coupon as $code) {
     		if($code['coupon_code']!='') {
	         $row = [
	             $code['coupon_code'],
	              $code['email']  
	            
	         ];
         }
         fputcsv($handle, $row);
     	
   		}
     } 

		return $this->_fileFactory->create(
		    //File name you would like to download it by
		    basename($outputFile),
		    [
		        'type'  => "filename", //type has to be "filename"
		        'value' => basename($outputFile), // path will append to the
		                                         // base dir
		        'rm'    => true, // add this only if you would like to file to
		                         // deleted after download from server
		    ],
		    \Magento\Framework\App\Filesystem\DirectoryList::VAR_DIR,
		    $contentType = 'application/csv'
		);

		 
		
	}
	
    
}
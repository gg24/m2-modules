<?php

namespace Bullitt\Couponfriend\Controller\Adminhtml\Promo\Quote;

use Magento\SalesRule\Model\CouponFactory;
use Bullitt\Couponfriend\Model\CouponemailFactory;
use Magento\Framework\Controller\ResultFactory;

class Post extends \Magento\Backend\App\Action {

    /**
     * @param Action\Context $context
     */
    protected $_modelCouponFactory;
    protected $_fileCsv;
    protected $_modelCouponemailFactory;

    public function __construct(
    \Magento\Backend\App\Action\Context $context,
    // \Magento\Framework\Registry $coreRegistry,
    // \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
    //  \Magento\Framework\Stdlib\DateTime\Filter\Date $dateFilter,
            \Magento\SalesRule\Model\CouponFactory $modelCouponFactory, \Magento\Framework\File\Csv $fileCsv, \Bullitt\Couponfriend\Model\CouponemailFactory $modelCouponemailFactory
    ) {
        parent::__construct($context);
        // $this->_coreRegistry = $coreRegistry;
        //$this->_fileFactory = $fileFactory;
        // $this->_dateFilter = $dateFilter;
        $this->_modelCouponFactory = $modelCouponFactory;
        $this->_fileCsv = $fileCsv;
        $this->_modelCouponemailFactory = $modelCouponemailFactory;
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute() {

        $emailArray1 = array();
        $emailArray2 = array();
        $emailAndCode = array();
        $alreayAssignedCodes = array();

        if (!$this->getRequest()->isAjax()) {
            $this->_forward('noroute');
            return;
        }
		$result = [];
        
		
		$inputFileName = $_FILES["file_uploader"]["tmp_name"];
		
		if (file_exists($inputFileName)) {

			// GET CSV Email Array
			$data = $this->_fileCsv->getData($inputFileName);
			for($i=1; $i<count($data); $i++) {
				$emailArray1[] = $data[$i];   
			}
			
			// Get rule Id
			$referer_url = explode('/',$this->_redirect->getRefererUrl());
			$ruleIdKey = array_keys($referer_url, "id");
			$rule_id = $referer_url[$ruleIdKey[0]+1];

			// Get Aggeigned Coupon Codes
			$couponEmailModel = $this->_modelCouponemailFactory->create();
			$couponEmailCollection = $couponEmailModel->getCollection()->addFieldToFilter('rule_id',array('eq' => $rule_id));
			foreach ($couponEmailCollection->getData() as $key => $value) {
				$alreadyAssignedCodes[] = $value['coupon_code'];
			}

			// Get Coupons Code of Cart price rule which are not assigned to email address 
			$salesRuleCouponModel = $this->_modelCouponFactory->create();
			$salesRuleCouponCollection = $salesRuleCouponModel->getCollection()->addRuleToFilter($rule_id);
			foreach($salesRuleCouponCollection->getData() as $k => $salesRuleCoupon) {
				if(!in_array($salesRuleCoupon['code'], $alreadyAssignedCodes)) {
					$emailArray2[] = array('code'=>$salesRuleCoupon['code'],'rule_id'=>$rule_id);  //Database coupon code for friends and family
				}
			}
			
		}
		
		
		// Merge Email and Coupon Code 
		if(count($emailArray2) > count($emailArray1)) {
			for($k=0; $k <= count($emailArray1); $k++) {	
				if(isset($emailArray1[$k])) {
				$emailAndCode[] = array('code' => $emailArray2[$k]['code'],'email' => $emailArray1[$k][0],'rule_id' => $emailArray2[$k]['rule_id']);
				}
			}
		}	
		
		if(count($emailArray1) > count($emailArray2)) {
			for($k=0; $k <= count($emailArray2); $k++) {	
				if(isset($emailArray2[$k])) {
				$emailAndCode[] = array('code' => $emailArray2[$k]['code'],'email' => $emailArray1[$k][0],'rule_id' => $emailArray2[$k]['rule_id']);
				}
			}
		}	
		
		if(count($emailArray1) == count($emailArray2)) {
			for($k=0; $k <= count($emailArray2); $k++) {	
				if(isset($emailArray2[$k])) {
				$emailAndCode[] = array('code' => $emailArray2[$k]['code'],'email' => $emailArray1[$k][0],'rule_id' => $emailArray2[$k]['rule_id']);
				}
			}
		}	
		
		
		if(!empty($emailAndCode)) {
			//Save Email and Coupon Code
			try {
				$couponEmailModel = $this->_modelCouponemailFactory->create();
				foreach($emailAndCode as $eandC) {
					$couponEmailModel->setCouponCode($eandC['code']);
					$couponEmailModel->setEmail($eandC['email']);
					$couponEmailModel->setRuleId($eandC['rule_id']);
					$couponEmailModel->setCreated(date('Y-m-d H:i:s'));
					$couponEmailModel->save();
					$couponEmailModel->unsetData();
				}
				$result = ['success' => 'File data uploaded Successfully', 'error' => ''];
			} catch (\Exception $e) {
				$result = ['error' => $e->getMessage(), 'errorcode' => $e->getCode()];
			}
		} else {
			$result = ['error' => 'Coupon Codes are already assigned', 'errorcode' => ''];
		}
		
		return $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData($result);
    }

}

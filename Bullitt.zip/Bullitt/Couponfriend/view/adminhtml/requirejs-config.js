var config = {
    map: {
        '*': {
            couponfr: 'Bullitt_Couponfriend/js/couponfr'
        }
    }
};
define([

	'Magento_Ui/js/form/element/file-uploader',
    'jquery'
], function (Element) {
    'use strict';

    return Element.extend({
        defaults: {
            file_uploader: ''
        },

        /**
         * Handler of the file upload complete event.
         *
         * @param {Event} e
         * @param {Object} data
         */
        onFileUploaded: function (e, data) { 
            this._super(e, data);            
            var response = data.result; // Here the response data are stored
            jQuery('.successMessage').remove();
			if(data.result.error == '') {
				jQuery(".file-uploader-spinner").parent().append('<span class="successMessage">'+data.result.success+'</span>');
			} else {
                jQuery(".file-uploader-spinner").parent().append('<span class="successMessage">'+data.result.error+'</span>');
			}
			
        }
    });
});
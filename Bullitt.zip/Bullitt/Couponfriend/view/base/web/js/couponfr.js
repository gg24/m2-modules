define([
        'jquery','couponfr'
	    ],
    function($,couponfr){
            'use strict';
    return {
        exampleData:function(ajaxurl,ajaxid){ 
        $(document).on('click','.couponfr',function (event){ 
                event.preventDefault();
                var id=ajaxid;
                $("body").append("<iframe src='" + ajaxurl +  "' style='display: none;' ></iframe>");
                // $.ajax({
                //     url:ajaxurl,
                //     type:'POST',
                //     showLoader: true,
                //     dataType:'json',
                //     data: {id:id},                                      
                //     success:function(response){ alert(response);
                //         //put your code
                //         alert(response.success);
                //         if(respose.success == 'File data uploaded Successfully') {
                //             jQuery('.file-uploader-spinner').html(respose.success);
                //         }
                //     }
                // });
            });



     
  
        }
    }

    

});


<?php

namespace Bullitt\Setcart\Model\Magento\Persistent;


class QuoteManager extends \Magento\Persistent\Model\QuoteManager
{
	
	public function expire()
    {
        $quote = $this->checkoutSession->setLoadInactive()->getQuote();
        $this->checkoutSession->setLoadInactive(false);
        if ($quote->getIsActive() && $quote->getCustomerId()) {
            $this->checkoutSession->setCustomerData(null)->clearQuote()->clearStorage();
        } else {
            $quote->setIsActive(true)
                ->setIsPersistent(false)
                ->setCustomerId(null)
                ->setCustomerGroupId(\Magento\Customer\Api\Data\GroupInterface::NOT_LOGGED_IN_ID);
        }
    }
}
	
	
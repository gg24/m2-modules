<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Bullitt\Placeholder\Plugin\Checkout\Block\Checkout;

use Magento\Checkout\Helper\Data;
use Magento\Framework\App\ObjectManager;
use Magento\Store\Api\StoreResolverInterface;

/**
 * Class LayoutProcessor
 */
class LayoutProcessorPlugin {

    /**
     * Process js Layout of block
     *
     * @param array $jsLayout
     * @return array
     */
    public function afterProcess(\Magento\Checkout\Block\Checkout\LayoutProcessor $subject,   array  $jsLayout)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
        
        $storeCode = $storeManager->getStore()->getCode();
        if($storeCode == "en_gb"){
            $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
            ['shippingAddress']['children']['shipping-address-fieldset']['children']['telephone']['validation']['phoneUK'] = 'true'; 

            $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']['payment']['children']['payments-list']
            ['children']['free-form']['children']['form-fields']['children']['telephone']['validation']['phoneUK'] = 'true';


           $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']['payment']['children']['payments-list']
            ['children']['loviitcc-form']['children']['form-fields']['children']['telephone']['validation']['phoneUK'] = 'true';

            $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']['payment']['children']['payments-list']
            ['children']['loviitdc-form']['children']['form-fields']['children']['telephone']['validation']['phoneUK'] = 'true';

            $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']['payment']['children']['payments-list']
            ['children']['loviitppal-form']['children']['form-fields']['children']['telephone']['validation']['phoneUK'] = 'true';

        
        }
     
        // echo '<pre>'; print_r($jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']['payment']['children']['payments-list']['children']['loviitcc-form']['children']['form-fields']['children']['telephone']);echo '</pre>';
      // echo '<pre>'; print_r($jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']['payment']['children']['payments-list']['children']);echo '</pre>';
        return $jsLayout;
    }

   
}

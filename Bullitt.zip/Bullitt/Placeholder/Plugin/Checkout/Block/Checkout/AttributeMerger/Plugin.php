<?php
namespace Bullitt\Placeholder\Plugin\Checkout\Block\Checkout\AttributeMerger;

class Plugin
{
  public function afterMerge(\Magento\Checkout\Block\Checkout\AttributeMerger $subject, $result)
  {

    if (array_key_exists('prefix', $result)) {
      if($result['prefix']['options'][0]['label'] != 'Select Title') {
        if(isset($result['prefix']['options'][1]['label']) && $result['prefix']['options'][1]['label'] == 'Mr') {
          $result['prefix']['options'][1]['label'] = __($result['prefix']['options'][1]['label']);
        }
        if(isset($result['prefix']['options'][2]['label']) && $result['prefix']['options'][2]['label'] == 'Mrs') {
         $result['prefix']['options'][2]['label'] =  __($result['prefix']['options'][2]['label']);
        }
        if(isset($result['prefix']['options'][3]['label']) && $result['prefix']['options'][3]['label'] == 'Ms') {
         $result['prefix']['options'][3]['label'] = __($result['prefix']['options'][3]['label']);
        }
        $title = __('Select Title');
        array_unshift($result['prefix']['options'] , array('value'=>'','label'=> $title));
      } 
    }

    if (array_key_exists('company', $result)) {
      $result['company']['placeholder'] = __('Enter company name');
    } 
    if (array_key_exists('telephone', $result)) {
      $result['telephone']['placeholder'] = __('Enter contact number');
    }
    if (array_key_exists('firstname', $result)) {
      $result['firstname']['placeholder'] = __('Enter first name');
    }
    if (array_key_exists('lastname', $result)) {
      $result['lastname']['placeholder'] = __('Enter last name');
    }
    if (array_key_exists('street', $result)) {
      $result['street']['children'][0]['placeholder'] = __('Enter street address');
    }
    if (array_key_exists('city', $result)) {
      $result['city']['placeholder'] = __('Enter city');
    }
    if (array_key_exists('region', $result)) {
      $result['region']['placeholder'] = __('Enter state');
    }   
    if (array_key_exists('postcode', $result)) {
      $result['postcode']['placeholder'] = __('Enter postcode');
    }
    if (array_key_exists('fax', $result)) {
      $result['fax']['placeholder'] = __('Enter fax');
    }
    
    

    return $result;
  }
}
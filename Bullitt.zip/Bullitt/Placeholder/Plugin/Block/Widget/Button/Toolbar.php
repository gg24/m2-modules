<?php

namespace Bullitt\Placeholder\Plugin\Block\Widget\Button;

use Magento\Backend\Block\Widget\Button\Toolbar as ToolbarContext;
use Magento\Framework\View\Element\AbstractBlock;
use Magento\Backend\Block\Widget\Button\ButtonList;

class Toolbar
{
    public function beforePushButtons(
        ToolbarContext $toolbar,
        \Magento\Framework\View\Element\AbstractBlock $context,
        \Magento\Backend\Block\Widget\Button\ButtonList $buttonList
    ) {

        if (!$context instanceof \Magento\Sales\Block\Adminhtml\Order\View) {
            return [$context, $buttonList];
        }

        $order          = $context->getOrder();

        $objectManager  = \Magento\Framework\App\ObjectManager::getInstance();
        $timeZoneObj    = $objectManager->create('Magento\Framework\Stdlib\DateTime\Timezone');
        $currentTime    = $timeZoneObj->date()->format('H:i:s');
        $europeTimeCondition    = "13:59:00";
        $naTimeCondition        = "15:59:00";


        $firstTime  = strtotime($order->getData('created_at'));
        $lastTime   = strtotime($currentTime);
        $timeDiff   = $lastTime-$firstTime;
        $timeDiff   = ($timeDiff/60)/60;           
        $timeDiff   = (int)($timeDiff);

        $showCancel = false;

        if($order->getData('store_id') == 8 || $order->getData('store_id') == 10 || $order->getData('store_id') == 11){
            if (strtotime($naTimeCondition) > strtotime($currentTime)) {
                if (($timeDiff < 24) && ($order->getState() == "new" || $order->getState() == "pending_payment" || $order->getStatusLabel() == "Received")){
                        $showCancel = true;
                }
            }
        }else{
            if (strtotime($europeTimeCondition) > strtotime($currentTime)) { 
                if (($timeDiff < 24) && ($order->getState() == "new" || $order->getState() == "pending_payment" || $order->getStatusLabel() == "Received")){
                    $showCancel = true;
                }
            }
        }

        if(!$showCancel){
           $buttonList->remove('order_cancel');
        }

        return [$context, $buttonList];
    }
}
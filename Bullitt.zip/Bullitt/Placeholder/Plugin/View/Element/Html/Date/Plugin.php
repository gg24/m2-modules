<?php
namespace Bullitt\Placeholder\Plugin\View\Element\Html\Date;

class Plugin
{
  public function afterGetHtml(\Magento\Framework\View\Element\Html\Date $subject, $result)
  {
    $pos = strpos($result,"/>");

  	$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
	$storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
	
	$storeCode = $storeManager->getStore()->getCode();
	if($storeCode == "de_de"){
		$placeholder = __('dd.mm.yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "en_us"){
	    $replacement = "placeholder='mm/dd/yyyy'";
	}elseif($storeCode == "en_ca"){
	    $replacement = "placeholder='yyyy-mm-dd'";
	}elseif($storeCode == "es_es"){
		$placeholder = __('dd/mm/yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "fr_ca"){
		$placeholder = __('yyyy-mm-dd');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "fr_fr"){
		$placeholder = __('dd/mm/yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "it_it"){
		$placeholder = __('dd/mm/yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "it_ch"){
		$placeholder = __('dd/mm/yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "de_ch"){
		$placeholder = __('dd/mm/yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "fr_ch"){
		$placeholder = __('dd/mm/yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "nl_nl"){
		$placeholder = __('dd/mm/yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "pt_pt"){
		$placeholder = __('dd/mm/yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "pt_pt"){
		$placeholder = __('dd/mm/yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "nl_be"){
		$placeholder = __('dd/mm/yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}elseif($storeCode == "fr_be"){
		$placeholder = __('dd/mm/yyyy');
	    $replacement = "placeholder='".$placeholder."'";
	}else{
		$replacement = "placeholder='dd/mm/yyyy'";
	}

    $result = substr_replace($result, $replacement, $pos, 0);
    return $result;  
  }
  
}
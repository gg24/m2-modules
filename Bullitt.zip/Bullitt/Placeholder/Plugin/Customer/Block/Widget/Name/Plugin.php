<?php
namespace Bullitt\Placeholder\Plugin\Customer\Block\Widget\Name;

class Plugin
{
  public function afterGetPrefixOptions(\Magento\Customer\Block\Widget\Name $subject, $result)
  {

  	foreach($result as $key => $value) {
 		if($key == '') {
  			$result[$key] = _('Select Title');
  		}
  	}
  	ksort($result);
    return $result;
  }

}
<?php
namespace Bullitt\Placeholder\Plugin\Customer\Block\Widget\Dob;

class Plugin
{
  public function aroundGetFormFilter(\Magento\Customer\Block\Widget\Dob $subject, $result)
  {
	  //echo $result->text; 
    //$result->placeholder = 'dd/mm/yyyy';
    echo '<pre>'; print_r($result); die('here');
   // return $result;
	
  
  }
  

}
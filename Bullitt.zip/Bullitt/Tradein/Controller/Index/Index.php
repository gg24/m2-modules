<?php

namespace Bullitt\Tradein\Controller\Index;
use Magento\Framework\App\Action\Context;
use Bullitt\Customdesign\Helper\Data;
use Magento\Framework\Controller\Result\Redirect;

class Index extends \Magento\Framework\App\Action\Action
{

	/**
     * @param Context $context
     * @param Data $customhelperdata
     * @param Redirect $resultRedirect
     */

    public function __construct(
    Data $customhelperdata, Context $context, Redirect $resultRedirect
    ) {
        $this->customhelperdata  = $customhelperdata;
        $this->resultRedirect  = $resultRedirect;
        parent::__construct($context);
    }

    public function execute()
    {
    	$storecode = $this->customhelperdata->getStoreViewCode();
    	if(($storecode == 'cn_cn') || ($storecode == 'en_ca') || ($storecode == 'fr_ca') || ($storecode == 'en_no') || ($storecode == 'en_se') || ($storecode == 'es_ar') || ($storecode == 'en_za') || ($storecode == 'en_dk')) {
    		
    		$resultRedirect = $this->resultRedirectFactory->create();
        	$resultRedirect->setPath('');
        	return $resultRedirect;
    	}else{
	        $this->_view->loadLayout();
	        $this->_view->getLayout()->initMessages();
	        $this->_view->renderLayout();
    	}	
    }
}
<?php

namespace Bullitt\Tradein\Controller\Upload;

use Magento\Framework\Filesystem\Io\Sftp;
use Bullitt\Tradein\Helper\SftpDetails;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;

class Image extends \Magento\Framework\App\Action\Action
{

	/**
     * @param Context $context
     * @param Sftp $sftp
     * @param SftpDetails $sftpDetails
     */
    public function __construct(
    Sftp $sftp, SftpDetails $sftpDetails, \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory, Context $context, DirectoryList $directoryList
    ) {
        $this->_sftp = $sftp;
        $this->_sftpDetails = $sftpDetails;
        $this->resultJsonFactory  = $resultJsonFactory;
        $this->directoryList  = $directoryList;
        parent::__construct($context);
    }

    public function execute()
    {   
    	
    	if (isset($_FILES['upload-image']) && ($_FILES['upload-image']['tmp_name'] !=null && $_FILES['upload-image']['name'] !=null)) {

	        $params = $this->_sftpDetails->getSFTPConfig();

	        $this->_sftp->open($params);
	        $baseurl = $this->directoryList->getRoot();
	        $mediapath = $this->directoryList->getPath('media');

			$remotepath 	= '/data/www.catphones.com/pub/media/sf';

			$filep 		= $_FILES['upload-image']['tmp_name'];//$_FILES["image1"]["tmp_name"];
			$name 			= $_FILES['upload-image']['name'];//$_FILES['image1']['name'];
			$ext 			= pathinfo($name, PATHINFO_EXTENSION);

			$currentTime 	= time();

		 	$fileName = 'tradein' . $currentTime .'.'. $ext;

			 $upload = $this->_sftp->write($remotepath.'/'.$fileName, $filep, 'NET_SFTP_LOCAL_FILE');

		 	if (!$upload) {
		       echo "SFTP upload has encountered an error!";
		   } else {
		   		$resp = ltrim('https://catphones.com/pub/media/sf/'.$fileName);
		       echo $resp;

		   }
		   
		}else{
			echo 'false';
		}
        
    }
}
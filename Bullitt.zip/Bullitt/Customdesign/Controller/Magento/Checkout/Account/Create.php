<?php

namespace Bullitt\Customdesign\Controller\Magento\Checkout\Account;


class Create extends \Magento\Checkout\Controller\Account\Create
{
	
	 public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->_objectManager->get(\Magento\Framework\Controller\Result\JsonFactory::class)->create();

        if ($this->customerSession->isLoggedIn()) {
            return $resultJson->setData(
                [
                    'errors' => true,
                    'message' => __('Customer is already registered')
                ]
            );
        }
        $orderId = $this->checkoutSession->getLastOrderId();
        if (!$orderId) {
            return $resultJson->setData(
                [
                    'errors' => true,
                    'message' => __('Your session has expired')
                ]
            );
        }
        try {
            $this->orderCustomerService->create($orderId);
            return $resultJson->setData(
                [
                    'errors' => false,
                    'message' => __('Instructions for creating an account will be sent to the email address you supplied during your purchase')
                ]
            );
        } catch (\Exception $e) {
            $this->messageManager->addException($e, $e->getMessage());
            throw $e;
        }
    }
}
	
	
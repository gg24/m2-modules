<?php

namespace Bullitt\Customdesign\Controller\Index;

use Magento\Framework\App\Request\Http;

class Basket extends \Magento\Framework\App\Action\Action
{
    protected $resultPageFactory;
    protected $jsonHelper;
    protected $_dhelper;
    protected $_request;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param \Bullitt\Customdesign\Helper\Data $dhelper
     * @param Http $request
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Bullitt\Customdesign\Helper\Data $dhelper,
        Http $request
    )
    {
        $this->resultPageFactory    = $resultPageFactory;
        $this->jsonHelper           = $jsonHelper;
        $this->_dhelper             = $dhelper;
        $this->_request             = $request;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $action = '';
        $action = $this->_request->getParam('action');
        $cData  = $this->_dhelper->getQuoteInfoForCheckout($action);

        $result = [];
        if ($cData) {
            $result['type'] = 'success';
            $result['data'] = $cData;
        }else{
            $result['type'] = 'error';
            $result['data'] = false;
        }
        return $this->jsonResponse($result);
    }

    /**
     * Create json response
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function jsonResponse($response = '')
    {
        return $this->getResponse()->representJson(
            $this->jsonHelper->jsonEncode($response)
        );
    }
}
<?php

namespace Bullitt\Customdesign\Controller\Index;

class Ga extends \Magento\Framework\App\Action\Action
{
    protected $resultPageFactory;
    protected $jsonHelper;
    protected $_lhelper;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param \Bullitt\Checklogin\Helper\Data $lhelper
     * @param \StoreManagerInterface $storeManager
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Bullitt\Checklogin\Helper\Data $lhelper
    )
    {
        $this->resultPageFactory    = $resultPageFactory;
        $this->jsonHelper           = $jsonHelper;
        $this->_lhelper             = $lhelper;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $cData  = $this->_lhelper->getCustomerData();
        $result = [];
        if ($cData) {
            $result['type'] = 'success';
            $result['data'] = $cData;
        }else{
            $result['type'] = 'error';
            $result['data'] = false;
        }
        return $this->jsonResponse($result);
    }

    /**
     * Create json response
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function jsonResponse($response = '')
    {
        return $this->getResponse()->representJson(
            $this->jsonHelper->jsonEncode($response)
        );
    }
}
<?php
namespace Bullitt\Customdesign\Helper;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Helper\Context;
use Magento\Catalog\Model\Category;
use FishPig\WordPress\Model\Post;
use DCKAP\Wpsearch\Block\Wordpress;

class Paginate extends \Magento\Framework\App\Helper\AbstractHelper{

    protected $_cat;
    protected $_post;
    protected $_postData;
    protected $_storeManager;

    /**
     * @param Context $context
     * @param ResourceConnection $resource
     */
    public function __construct(
      Context $context, Category $cat, Post $post, Wordpress $postData, StoreManagerInterface $storeManager
    ) {
        $this->_cat = $cat;
        $this->_post = $post;
        $this->_postData = $postData;
        $this->_storeManager = $storeManager;
        parent::__construct($context);
    }

    /**
       * array_to_xml conversion from array
       * @param array $array
       * @param object $xml_order_info
       * @param string $rootNode
       * 
       * @return boolean
    */
    public function arrangeData($_productCollection, $post, $post_length=5) {
        $i = 0;
        $j = 0;
        $allItems = [];
        $category = [];
        $k = 0;


      if(count($_productCollection) > 0){
          
        foreach ($_productCollection as $_product){
          $catId = 0;
          //echo '<pre>'; print_r(array_keys($_product->getData())); die('===');

          $allItems[$i]['id'] = $_product->getData('entity_id'); 
          $allItems[$i]['type'] = 'product'; 
          $allItems[$i]['title'] = $_product->getData('name'); 
          $allItems[$i]['is_salable'] = $_product->getData('is_salable'); 
          $allItems[$i]['url'] = $this->_storeManager->getStore()->getBaseUrl().$_product->getData('url_key').'.html'; 
          $allItems[$i]['description'] = $_product->getData('short_description');
          $allItems[$i]['category_ids'] = $_product->getData('category_ids');
          $allItems[$i]['image'] = '';

          if(isset($allItems[$i]['category_ids'])){
            foreach ($allItems[$i]['category_ids'] as $val) {
              if($val != 2){
                $catId = $val;
              }else{
                $catId = 0;
              }
            }
            if(isset($catId)){
                $allItems[$i]['category_ids'] = $catId;
            }
          }
          $i++;
        }


        foreach ($allItems as $prod){
          $category[$prod['category_ids']][$j] = $prod; 
          $j++;
        }
        
        // 4 7 5 8
        
        if(isset($category[4]) && count($category[4]) > 0){
          $categoryObj  = $this->_cat->load(4);
          $catName      = $categoryObj->getName();
          foreach($category[4] as $itemData){
            $finalProductData[$k][$catName]  = $itemData;
            $k++;
          }
        }
        if(isset($category[7]) && count($category[7]) > 0){
          $categoryObj  = $this->_cat->load(7);
          $catName      = $categoryObj->getName();
          foreach($category[7] as $itemData){
            $finalProductData[$k][$catName]  = $itemData;
            $k++;
          }
        }
        if(isset($category[5]) && count($category[5]) > 0){
          $categoryObj  = $this->_cat->load(5);
          $catName      = $categoryObj->getName();
          foreach($category[5] as $itemData){
            $finalProductData[$k][$catName]  = $itemData;
            $k++;
          }
        }
        if(isset($category[8]) && count($category[8]) > 0){
          $categoryObj  = $this->_cat->load(8);
          $catName      = $categoryObj->getName();
          foreach($category[8] as $itemData){
            $finalProductData[$k][$catName]  = $itemData;
            $k++;
          }
        }
      }

      if(count($post) > 0){
        foreach ($post as $postDetail) {
          //echo '<pre>'; print_r(array_keys($postDetail)); die('===');
          //echo '<pre>'; print_r($postDetail); die('===');
          $postItems[$i]['title'] = $postDetail['post_title']; 
          $html=$this->_postData->convertHtml($postDetail['post_content']);
          $desc=$html;
          $description = '';
          $description = $this->_postData->getContent($postDetail['post_content'],$desc,$post_length);
          $postItems[$i]['id'] = $postDetail['ID']; 
          $postItems[$i]['type'] = $postDetail['post_type']; 
          $postItems[$i]['title'] = $postDetail['post_title']; 
          $postItems[$i]['is_salable'] = false; 
          $postItems[$i]['url'] = $postDetail['perma_link']; 
          $postItems[$i]['description'] = $description;
          $postItems[$i]['category_ids'] = $postDetail['post_parent'];
          $postItems[$i]['image'] = $postDetail['featured'];
          $i++;
        }

        foreach ($postItems as $singlePost){
          $postCategory[$singlePost['category_ids']][$j] = $singlePost; 
          $j++;
        }
        
        krsort($postCategory);
        
        foreach ($postCategory as $nProd => $val){
          if($nProd == 0){
            foreach($val as $itemData){
              $finalPostData[$k]['Others']  = $itemData;
              $k++;
            }
          }else{
            if ($this->_post->load($nProd)){
              $postCategoryObj  = $this->_post->load($nProd);
              foreach($val as $itemData){
                $finalPostData[$k][$postCategoryObj->getData('post_title')]  = $itemData;
                $k++;
              }
            }
          }
        }
      }

      $finalData = [];
      
      if(isset($finalProductData) && isset($finalPostData)){
        $finalData = array_merge($finalProductData,$finalPostData);
      }elseif(isset($finalProductData) && (!isset($finalPostData))){
        $finalData = $finalProductData;
      }elseif((!isset($finalProductData)) && (isset($finalPostData))){
        $finalData = $finalPostData;
      }
        
        /*
        echo '<pre>'; print_r($finalData);  die('===');*/
        /*echo '<pre>'; print_r($finalProductData); 
        echo '<pre>'; print_r($finalPostData);
        die('===');*/
        return $finalData;
    }
}
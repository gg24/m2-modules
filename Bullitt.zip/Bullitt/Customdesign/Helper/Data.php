<?php
namespace Bullitt\Customdesign\Helper;

use Bullitt\Customdesign\Helper\DeviceTypeInfo;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\Request\Http;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Api\CountryInformationAcquirerInterface;
use Magento\Catalog\Model\Category;
use Magento\Checkout\Model\Cart;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\View\Page\Config;
use FishPig\WordPress\Model\Post;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const XML_GA_ACCOUNT_NO = 'ga_section/ga_group/account_no';
    const XML_GA_ENVIRONMENT = 'ga_section/ga_group/env_type';
    const GA_SECTION_GA_GROUP_WEB_GAINS_EVENT_ID = 'ga_section/ga_group/web_gains_event_id';

    protected $_deviceType;
    protected $_request;
    protected $_scopeConfig;
    protected $_countryInformation;
    protected $_cat;
    protected $_cart;
    protected $_post;
    protected $_pageConfig;

    /**
     * @var Session
     */
    private $checkoutSession;

    /**
     * Data constructor.
     *
     * @param Context                                                    $context
     * @param \Bullitt\Customdesign\Helper\DeviceTypeInfo                $deviceType
     * @param Http                                                       $request
     * @param StoreManagerInterface                                      $storeManager
     * @param CountryInformationAcquirerInterface                        $countryInformation
     * @param Category                                                   $cat
     * @param Cart                                                       $cart
     * @param ProductRepository                                          $repository
     * @param Config                                                     $pageConfig
     * @param Post                                                       $post
     * @param Session                            $checkoutSession
     */
    public function __construct(
        Context $context,
        DeviceTypeInfo $deviceType,
        Http $request,
        StoreManagerInterface $storeManager,
        CountryInformationAcquirerInterface $countryInformation,
        Category $cat,
        Cart $cart,
        ProductRepository $repository,
        Config $pageConfig,
        Post $post,
        Session $checkoutSession
    ) {
        $this->_deviceType      = $deviceType;
        $this->_request         = $request;
        $this->_storeManager    = $storeManager;
        $this->_countryInformation = $countryInformation;
        $this->_cat             = $cat;
        $this->_cart            = $cart;
        $this->_repository      = $repository;
        $this->_scopeConfig     = $context->getScopeConfig();
        $this->_request         = $context->getRequest();
        $this->_post            = $post;
        $this->_pageConfig      = $pageConfig;
        parent::__construct($context);
        $this->checkoutSession = $checkoutSession;
    }

    public function getEnvironmentType($store = null) {
        return $this->getConfigValue(self::XML_GA_ENVIRONMENT, $store);
    }

    public function getGaAccountNo($store = null) {
        return $this->getConfigValue(self::XML_GA_ACCOUNT_NO, $store);
    }


    public function getConfigValue($path, $storeId = null) {
        $configValue = $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE, 0);
        return $configValue;
    }

    /**
     * @param string $actionName
     *
     * @return array|bool
     */
    public function getQuoteInfoForCheckout($actionName='')
    {
        if ($actionName == 'checkout_onepage_success') {
            $order = $this->checkoutSession->getLastRealOrder();
            $products = [];
            $shipping = $order->getShippingMethod(true);
            $result = [
                'transaction_reference' => $order->getIncrementId(),
                'transaction_amount_aci' => $order->getGrandTotal(),
                'transaction_amount' => $order->getSubtotal(),
                'transaction_voucher_code' => (string)$order->getCouponCode(),
                'transaction_currency' => $order->getOrderCurrencyCode(),
                'transaction_payment_method' => $order->getPayment()->getMethod(),
                'transaction_shipping_method' => $this->scopeConfig->getValue(sprintf('carriers/%s/title', $shipping->getCarrierCode())),
                'transaction_shipping_amount' => $order->getShippingInclTax()
            ];

            foreach ($order->getAllVisibleItems() as $item) {
                $category = $item->getProduct()->getCategoryCollection()->getFirstItem();
                $item = [
                    'product_name' => $item->getName(),
                    'product_unitprice_tf' => $item->getPrice(),
                    'product_unitprice_ati' => $item->getProduct()->getFinalPrice(),
                    'product_number' => $item->getQtyOrdered(),
                    'product_currency' => $order->getOrderCurrencyCode()
                ];

                if ($category->getId()) {
                    $item['product_category'] = $category->getName();
                }

                $products[] = $item;
            }

            $result['transaction_product_list'] = $products;
            $eventId = $this->scopeConfig->getValue(self::GA_SECTION_GA_GROUP_WEB_GAINS_EVENT_ID) ?: 220; //default value can be changed in admin

            $result['Items'] = implode('|', array_map(function($item) use ($eventId, $result) {
                return implode('::', [
                    $eventId,
                    $item['product_unitprice_ati'],
                    $item['product_name'],
                    '',
                    $result['transaction_voucher_code']
                ]);
            }, $products));

            return $result;
        }

        if($actionName == 'checkout_cart_index'){
            $i                              = 0;
            $gaItemInfo                     = [];
            $items                          = $this->_cart->getQuote()->getAllItems();
            foreach($items as $item) {
                $gaItemInfo[$i]['id']       = $item->getSKU();
                $gaItemInfo[$i]['name']     = $item->getName();
                if($item->getData('row_total_incl_tax')!=='') {
                    $gaItemInfo[$i]['price']= sprintf('%0.2f', $item->getData('row_total_incl_tax'));
                }else{
                    $gaItemInfo[$i]['price']= sprintf('%0.2f', $item->getData('price')*$item->getQty());
                }
                $gaItemInfo[$i]['category'] = $this->getCategoryBySKU($item->getSKU());
                $gaItemInfo[$i]['quantity'] = round($item->getQty());
                $i++;           
            }
            $ecommData                           = [];
            $ecommData['checkout']['actionField']= array('step'=>1);
            $ecommData['checkout']['products']   = $gaItemInfo;
            $ecommData['promoView']              = array('promotions'=>[array('id'=>'','name'=>'')]);

            $fullInfo                       = [];
            $fullInfo['event']              = 'checkout';
            $fullInfo['ecommerce']          = $ecommData;

            //$jsonData                       = json_encode($fullInfo);
            //return "<script>dataLayer.push($jsonData);</script>";
            return $fullInfo;
            
        }elseif($actionName == 'checkout_index_index'){
            $i                              = 0;
            $gaItemInfo                     = [];
            $items                          = $this->_cart->getQuote()->getAllItems();
            foreach($items as $item) {
                $gaItemInfo[$i]['id']       = $item->getSKU();
                $gaItemInfo[$i]['name']     = $item->getName();
                if($item->getData('row_total_incl_tax')!=='') {
                    $gaItemInfo[$i]['price']= sprintf('%0.2f', $item->getData('row_total_incl_tax'));
                }else{
                    $gaItemInfo[$i]['price']= sprintf('%0.2f', $item->getData('price')*$item->getQty());
                }
                $gaItemInfo[$i]['category'] = $this->getCategoryBySKU($item->getSKU());
                $gaItemInfo[$i]['quantity'] = round($item->getQty());
                $i++;           
            }
            $ecommData                           = [];
            $ecommData['checkout']['actionField']= array('step'=>2);
            $ecommData['checkout']['products']   = $gaItemInfo;
            $ecommData['promoView']              = array('promotions'=>[array('id'=>'','name'=>'')]);

            $fullInfo                       = [];
            $fullInfo['event']              = 'checkout';
            $fullInfo['ecommerce']          = $ecommData;

            //$jsonData                       = json_encode($fullInfo);
            //return "<script>dataLayer.push($jsonData);</script>";
            return $fullInfo;

        }elseif($actionName == 'loviit_payment_finish'){
            $i                              = 0;
            $gaItemInfo                     = [];
            $items                          = $this->_cart->getQuote()->getAllItems();

            $promoName                      = '';
            $promoName                      = $this->_cart->getQuote()->getData('coupon_code');
            foreach($items as $item) {
                $gaItemInfo[$i]['id']       = $item->getSKU();
                $gaItemInfo[$i]['name']     = $item->getName();
                if($item->getData('row_total_incl_tax')!=='') {
                    $gaItemInfo[$i]['price']= sprintf('%0.2f', $item->getData('row_total_incl_tax'));
                }else{
                    $gaItemInfo[$i]['price']= sprintf('%0.2f', $item->getData('price')*$item->getQty());
                }
                $gaItemInfo[$i]['category'] = $this->getCategoryBySKU($item->getSKU());
                $gaItemInfo[$i]['quantity'] = round($item->getQty());
                $i++;           
            }
            $ecommData                           = [];
            $ecommData['checkout']['actionField']= array('step'=>3);
            $ecommData['checkout']['products']   = $gaItemInfo;
            $ecommData['promoView']              = array('promotions'=>[array('id'=>'','name'=>$promoName)]);

            $fullInfo                       = [];
            $fullInfo['event']              = 'checkout';
            $fullInfo['ecommerce']          = $ecommData;
            $jsonData                       = json_encode($fullInfo);

            $actionData                     = [];
            $actionData['id']               = $this->_cart->getQuote()->getId();
            $actionData['revenue']          = sprintf('%0.2f', $this->_cart->getQuote()->getGrandTotal());
            $actionData['tax']              = sprintf('%0.2f', $this->_cart->getQuote()->getShippingAddress()->getTaxAmount());
            $actionData['shipping']         = sprintf('%0.2f', $this->_cart->getQuote()->getShippingAddress()->getShippingAmount());

            //$fullInfo2                      = [];
            //$fullInfo2['event']             = 'transaction';            
            //$fullInfo2['ecommerce']['purchase']['actionField']  = $actionData;
            //$fullInfo2['ecommerce']['purchase']['products']     = $gaItemInfo;
            //$jsonData2                      = json_encode($fullInfo2);
            //return "<script>dataLayer.push($jsonData);</script>";
            return $fullInfo;

        }elseif($this->_cart->getQuote()->getAllItems()){
            //sprintf('%0.2f', )
            $i                              = 0;
            $gaItemInfo                     = [];
            $basketTotal                    = [];
            $items                          = $this->_cart->getQuote()->getAllItems();
            foreach($items as $item) {
                $gaItemInfo[$i]['name']     = $item->getName();
                $gaItemInfo[$i]['sku']      = $item->getData('sku');
                $gaItemInfo[$i]['category'] = $this->getCategoryBySKU($item->getSKU());
                if($item->getData('row_total_incl_tax')!=='') {
                    $gaItemInfo[$i]['price']= sprintf('%0.2f', $item->getData('row_total_incl_tax'));
                }else{
                    $gaItemInfo[$i]['price']= sprintf('%0.2f', $item->getData('price')*$item->getQty());
                }
                $gaItemInfo[$i]['tax']      = '';
                $gaItemInfo[$i]['basket_id']= $this->_cart->getQuote()->getId();
                $gaItemInfo[$i]['revenue']  = sprintf('%0.2f', $gaItemInfo[$i]['price']);
                $gaItemInfo[$i]['quantity'] = round($item->getQty());
                $i++;           
            }

            $basketTotal['basket_id']       = $this->_cart->getQuote()->getId();
            $basketTotal['basket_revenue']  = sprintf('%0.2f', $this->_cart->getQuote()->getGrandTotal());
            $basketTotal['basket_quantity'] = round($this->_cart->getQuote()->getItemsQty());
            //$basketTotal['basket_count']    = round($this->_cart->getQuote()->getItemsCount());


            $ecommData                      = [];
            $ecommData['currencyCode']      = $this->getCurrencyCode();
            $ecommData['add']['products']   = $gaItemInfo;
            $ecommData['add']['baskettotal']= $basketTotal;


            $fullInfo                       = [];
            $fullInfo['event']              = 'addToCart';
            $fullInfo['ecommerce']          = $ecommData;

            //$fullInfo2                      = [];
            //$fullInfo2['event']             = 'removeFromCart';
            //$fullInfo2['ecommerce']         = $ecommData;
            //$jsonData                       = json_encode($fullInfo);
            //$jsonData2                      = json_encode($fullInfo2);
            //return "<script>dataLayer.push($jsonData);</script><script>dataLayer.push($jsonData2);</script>";
            return $fullInfo;

        }else{
            return false; 
        }
    }

    public function getCategoryBySKU($sku)
    {
        $product    = $this->_repository->get($sku);
        $categories = $product->getData('category_ids');
        $catId      = 0;
        $currencyName = '';
        if(isset($categories)){
            foreach ($categories as $cat) {
                if($cat != 2){
                    $catId = $cat;
                }
            }
        }

        if($catId > 0){
            $currencyName = $this->getProductCategory($catId);
        }
        return $currencyName;
    }

    public function getProductCategory($catId)
    {
        $catName      = '';
        $categoryObj  = $this->_cat->load($catId);
        if($categoryObj){
            $catName      = $categoryObj->getName();
        }
        return $catName;
    }

    public function getCategoryName()
    {
        $categoryName = '';
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $category = $objectManager->get('Magento\Framework\Registry')->registry('current_category');

        if($category){
            $categoryName = $category->getName();
            return $categoryName;
        }else{
            $baseUrl = '';
            $baseUrl = $this->_storeManager->getStore()->getBaseUrl();
            $currentUrl = '';
            $currentUrl = $this->_storeManager->getStore()->getCurrentUrl(false);
            $actionName = '';
            $actionName = $this->_request->getFullActionName();
            $storecode = $this->_storeManager->getStore()->getCode();
            $exacturl = explode($baseUrl, $currentUrl);
            $exacturl = $exacturl[1];

            switch($actionName){
                 case 'wordpress_post_view': 
                    if($currentUrl==$baseUrl){
                        return 'homepage';
                    }else{
                        $pageCatName = $this->getWordpressPageName();
                         if($storecode == 'cn_cn' && (($exacturl =='cat-s60-smartphone/') || ($exacturl =='cat-s60-smartphone'))){
                            return 'smartphones';
                        }
                        else if($pageCatName == 'trade in' || 'trade-in'){
                        return 'support';
                        }else{
                            return $pageCatName;
                        }
                    }
                    break;
                case 'contact_index_index': 
                    return 'support';
                    break;
                case 'contact_thanks_index': 
                    return 'support';
                    break;
                case 'checkout_cart_index': 
                    return 'basket';
                    break;
                case 'checkout_index_index': 
                    return 'checkout';
                    break;
                case 'checkout_onepage_success': 
                    return 'checkout';
                    break;
                case 'catalogsearch_result_index': 
                    return 'search';
                    break;
                 case 'loviit_payment_finish': 
                    return 'checkout';
                    break;
                 case 'customer_account_login': 
                    return 'customer_account';
                    break;
                 case 'customer_account_index': 
                    return 'customer_account';
                    break;
                 case 'customer_account_edit': 
                    return 'customer_account';
                    break;
                 case 'customer_account_create': 
                    return 'customer_account';
                    break;
                 case 'customer_account_logoutSuccess': 
                    return 'customer_account';
                    break;
                case 'tradein_index_index': 
                    return 'support';
                    break;
                case 'catalog_product_view': 
                    $pageCatName = $this->getCurrentProductCategory();
                    return $pageCatName;
                    break;
                default:
                    return '';
                    break;
            }
        }
    }

    public function getCurrentProductCategory()
    {
        $cat        = '';
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $product    = $objectManager->get('Magento\Framework\Registry')->registry('current_product');
        $cat        = $this->getCategoryBySKU($product->getSKU());
        return $cat;
    }

    public function getCountryFullName()
    {
        $countryid      = '';
        $websiteId      = $this->_request->getParam(\Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE);
        $countryid      = $this->_scopeConfig->getValue('general/store_information/country_id', \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE, $websiteId);
        
        if($countryid == ''){
            return 'United Kingdom';
        }
        $country        = $this->_countryInformation->getCountryInfo($countryid);
        $countryname    = $country->getFullNameEnglish();
        return $countryname;
    }

    public function getPageTitle() {
        $metaTitle    = '';
        $metaTitle    = strip_tags(__($this->_pageConfig->getTitle()->getShort()));
        return $metaTitle;
    }

    public function getDeviceInfo()
    {
        $deviceType = '';
        $deviceType = ($this->_deviceType->isMobile() ? ($this->_deviceType->isTablet() ? 't' : 'm') : 'd');

        return $deviceType;
    }

    public function getCurrencyCode()
    {
        $currencyCode = '';
        $currencyCode = $this->_storeManager->getStore()->getCurrentCurrencyCode();
        return $currencyCode;
    }

    public function getStoreViewCode()
    {
        $storeViewCode = '';
        $storeViewCode = $this->_storeManager->getStore()->getCode();
        return $storeViewCode;
    }

    public function getSearchedData()
    {
        $actionName = '';
        $searchedWord = '';
        
        $actionName = $this->_request->getFullActionName();
        if($actionName == 'catalogsearch_result_index'){
            $searchedWord = $this->_request->getParam('q');            
        }
        return $searchedWord;
    }

    public function getPageName()
    {
        $baseUrl = '';
        $baseUrl = $this->_storeManager->getStore()->getBaseUrl();
        $currentUrl = '';
        $currentUrl = $this->_storeManager->getStore()->getCurrentUrl(false);
        $actionName = '';
        $actionName = $this->_request->getFullActionName();
        $storecode = $this->_storeManager->getStore()->getCode();
        $exacturl = explode($baseUrl, $currentUrl);
        $exacturl = $exacturl[1];

        switch($actionName){
            case 'wordpress_post_view': 
                if($currentUrl==$baseUrl){
                    return 'homepage';
                }else{
                    $pageCatName = $this->getWordpressPageName();
                    if($storecode == 'cn_cn' && (($exacturl =='cat-s60-smartphone/') || ($exacturl =='cat-s60-smartphone'))){
                            return 'smartphones';
                        }
                    else if($pageCatName == 'trade in' || 'trade-in'){
                        return 'support';
                    }else{
                        return $pageCatName;
                    }
                    
                }
                break;
            case 'customer_account_login': 
                return 'customer_login';
                break;
            case 'customer_account_logoutSuccess': 
                return 'customer_logout';
                break;
            case 'customer_account_create': 
                return 'registration_form';
                break;
            case 'catalog_category_view':
                return $this->getCatTemplateName();
                break;
            case 'catalog_product_view': 
                return 'product';
                break;
            case 'contact_index_index': 
                return 'contact_support';
                break;
            case 'contact_thanks_index': 
                return 'support_contact_confirmation';
                break;
            case 'customer_account_index': 
                return 'customer_account';
                break;
            case 'sales_order_history': 
                return 'customer_orders';
                break;
            case 'sales_order_view': 
                return 'customer_order_view';
                break;
            case 'customer_address_index': 
                return 'customer_address_listing';
                break;
            case 'customer_address_form': 
                return 'customer_address_edit';
                break;
            case 'customer_account_edit': 
                return 'customer_account_edit';
                break;
            case 'checkout_cart_index': 
                return 'funnel_basket';
                break;
            case 'checkout_index_index': 
                return 'funnel_delivery';
                break;
            case 'loviit_payment_finish': 
                return 'funnel_payment';
                break;
            case 'checkout_onepage_success': 
                return 'funnel_confirmation';
                break;
            case 'catalogsearch_result_index': 
                return 'search';
                break;
            case 'tradein_index_index': 
                    return 'support';
                    break;
            default:
                return 'article';
                break;
        }

        return $this->_request->getFullActionName();
    }

    public function getCatTemplateName()
    {
        $objectManager  = \Magento\Framework\App\ObjectManager::getInstance();
        $category       = $objectManager->get('Magento\Framework\Registry')->registry('current_category');
        if($category){
            $catID = $category->getId();
            if($catID == 4 || $catID == 5 || $catID == 7 || $catID == 8){
                return 'product_list';
            }elseif($catID == 11){
                return 'main_support';
            }else{
                return 'article';
            }
        }
        return 'article';
    }

    public function getWordpressPageName()
    {
        $parentTitle = 'article';
        if(($this->_request->getParam('id') !='') && ($this->_request->getParam('id') > 0)) {
            if ($this->_post->load($this->_request->getParam('id'))) {
                $postObj  = $this->_post->load($this->_request->getParam('id'));
                $parentID = $postObj->getPostParent();
                if($parentID && $this->_post->load($parentID)){
                    $parentPostObj  = $this->_post->load($parentID);
                    $parentTitle    = strtolower($parentPostObj->getPostTitle());
                }
            }
        }
        return $parentTitle;
    }

    public function getRootUrl(){
        $baseUrl = '';
        $baseUrl = $this->_storeManager->getStore()->getBaseUrl();
        return $baseUrl;
    }

    public function getActionName(){
        $actionName = '';
        $actionName = $this->_request->getFullActionName();
        return $actionName;
    }
}
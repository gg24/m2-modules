var config = {
    map: {
        '*': {
            bss_cancel_order_popup: 'Bss_CancelOrder/js/slick.min'
        }
    },
    shim: {
        popup: {
            deps: ['jquery']
        }
    }
};

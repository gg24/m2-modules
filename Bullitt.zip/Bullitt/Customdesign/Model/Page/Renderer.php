<?php

namespace Bullitt\Customdesign\Model\Page;
class Renderer extends \Magento\Framework\View\Page\Config\Renderer {
/**
* @return string
*/
public function renderTitle()
{
return '<title>' . $this->escaper->escapeHtml(__($this->pageConfig->getTitle()->get())) . '</title>' . "\n";
}
}
<?php

namespace Bullitt\Customdesign\Model\Magento\Reminder;


class Rule extends \Magento\Reminder\Model\Rule
{
	/**
     * Send reminder emails
     *
     * @return $this
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function sendReminderEmails()
    {
        

        $identity = $this->_reminderData->getEmailIdentity();

        $this->_matchCustomers();
        $limit = $this->_reminderData->getOneRunLimit();

        $recipients = $this->_getResource()->getCustomersForNotification($limit, $this->getRuleId());

        foreach ($recipients as $recipient) {
            /* @var $customer \Magento\Customer\Model\Customer */
            $customer = $this->customerFactory->create()->load($recipient['customer_id']);
            if (!$customer || !$customer->getId()) {
                continue;
            }

            if ($customer->getStoreId()) {
                $store = $customer->getStore();
            } else {
                $store = $this->storeManager->getWebsite($customer->getWebsiteId())->getDefaultStore();
            }

            $storeData = $this->getStoreData($recipient['rule_id'], $store->getId());
            if (!$storeData) {
                continue;
            }

            /* @var $coupon \Magento\SalesRule\Model\Coupon */
            $coupon = $this->couponFactory->create()->load($recipient['coupon_id']);

            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/mylogfile.log');
$logger = new \Zend\Log\Logger();
$logger->addWriter($writer);
$logger->info($customer->getEmail());
$logger->info($storeData['template_id']);
$logger->info($identity);
$logger->info($store->getId());

            $templateVars = [
                'store' => $store,
                'coupon' => $coupon,
                'customer' => $customer,
                'promotion_name' => $storeData['label'] ?: $this->getDefaultLabel(),
                'promotion_description' => $storeData['description'] ?: $this->getDefaultDescription(),
            ];

            $transport = $this->_transportBuilder->setTemplateIdentifier(
                $storeData['template_id']
            )->setTemplateOptions(
                ['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $store->getId()]
            )->setTemplateVars(
                $templateVars
            )->setFrom(
                $identity
            )->addTo(
                $customer->getEmail()
            )->getTransport();

            try {
                $transport->sendMessage();
                $this->_getResource()->addNotificationLog($recipient['rule_id'], $customer->getId());
            } catch (\Magento\Framework\Exception\MailException $e) {
                $this->_getResource()->updateFailedEmailsCounter($recipient['rule_id'], $customer->getId());
            }
        }

       

        return $this;
    }
	
}
	
	
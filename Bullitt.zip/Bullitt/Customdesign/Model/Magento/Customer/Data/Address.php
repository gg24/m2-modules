<?php

namespace Bullitt\Customdesign\Model\Magento\Customer\Data;


class Address extends \Magento\Customer\Model\Data\Address
{
	
	public function getPrefix() { 
		return __($this->_get(self::PREFIX)); 
	}
}
	
	
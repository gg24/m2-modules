<?php

namespace Bullitt\Customdesign\Model\Magento\Sales\Order;


class Address extends \Magento\Sales\Model\Order\Address
{
	
	/**
     * Get full customer name
     *
     * @return string
     */
    public function getName()
    { 
        $name = '';
        if ($this->getPrefix()) {
            $name .= __($this->getPrefix()) . ' ';
        }
        $name .= $this->getFirstname();
        if ($this->getMiddlename()) {
            $name .= ' ' . $this->getMiddlename();
        }
        $name .= ' ' . $this->getLastname();
        if ($this->getSuffix()) {
            $name .= ' ' . $this->getSuffix();
        }
        return $name;
    }
}
	
	
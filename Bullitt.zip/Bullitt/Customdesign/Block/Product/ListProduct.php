<?php

namespace Bullitt\Customdesign\Block\Product;

class ListProduct extends \Magento\Catalog\Block\Product\ListProduct
{

    public function getIsGridView()
    {
        $isGrid = false;
        $category = $this->getLayer()->getCurrentCategory();
        $isGrid = $category->getData('is_grid');
        return $isGrid;
    }

    public function getCompareUrl()
    {
        $url = '';
        $category = $this->getLayer()->getCurrentCategory();
        $url = $category->getData('compare_url');

        if(!empty($url)){
        	return $url;
        }else{
        	return false;
        }
    }

}
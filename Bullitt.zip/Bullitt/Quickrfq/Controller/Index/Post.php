<?php
namespace Bullitt\Quickrfq\Controller\Index;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Controller\ResultFactory; 

class Post extends \Bullitt\Quickrfq\Controller\Index
{
        
    const CONFIG_CAPTCHA_ENABLE = 'quickrfq/google_options/captchastatus';
    const CONFIG_CAPTCHA_PRIVATE_KEY = 'quickrfq/google_options/googleprivatekey';
    private static $_siteVerifyUrl = "https://www.google.com/recaptcha/api/siteverify?";
    private static $_version = "php_1.0";

    public function execute(){
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        
        $post = $this->getRequest()->getPostValue();
        $remoteAddress = new \Magento\Framework\Http\PhpEnvironment\RemoteAddress($this->getRequest());
        $visitorIp = $remoteAddress->getRemoteAddress();

        if (!$post) {
            return $resultRedirect;
        }
                
        $this->inlineTranslation->suspend();
        $postObject = new \Magento\Framework\DataObject();
        $postObject->setData($post);
                
        $error = false;
        $captcha_enable = false;
        //$captcha_enable = $this->scopeConfig->getValue(self::CONFIG_CAPTCHA_ENABLE);
                        
        if ($captcha_enable) {
            if (!\Zend_Validate::is(trim($post["g-recaptcha-response"]), 'NotEmpty')) {
                $error = true;
            }
        }
       
        if (!\Zend_Validate::is(trim($post['name']), 'NotEmpty')) {
            $error = true;
        }
        if (!\Zend_Validate::is(trim($post['email']), 'EmailAddress')) {
            $error = true;
        }
        if ($error) {
            throw new \Exception();
        }               
                        
        /*Captcha Process*/
                        
        if ($captcha_enable) {
            $captcha =   $post["g-recaptcha-response"];
            $secret =  $this->scopeConfig->getValue(self::CONFIG_CAPTCHA_PRIVATE_KEY);
                                    
            $response = null;
            $path = self::$_siteVerifyUrl;
            $dataC =  [
            'secret' => $secret,
            'remoteip' => $visitorIp,
            'v' => self::$_version,
            'response' => $captcha
            ];
            $req = "";
            foreach ($dataC as $key => $value) {
                 $req .= $key . '=' . urlencode(stripslashes($value)) . '&';
            }
            // Cut the last '&'
            $req = substr($req, 0, strlen($req)-1);
            $response = file_get_contents($path . $req);
            $answers = json_decode($response, true);
            if (trim($answers ['success']) == true) {
                $error = false;
            }else {
                // Dispay Captcha Error
                $error = true;
                throw new \Exception();
            }
        }
                        
        /*Captcha Process*/            
        /*Email Sending Start*/
        if ($error == false) {
            try {
                $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
                $transport = $this->_transportBuilder
                ->setTemplateIdentifier($this->scopeConfig->getValue(self::XML_PATH_EMAIL_TEMPLATE, $storeScope))
                ->setTemplateOptions(
                    [
                    'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                    'store' => $this->storeManager->getStore()->getId(),
                    ]
                )
                ->setTemplateVars(['data' => $postObject])
                ->setFrom($this->scopeConfig->getValue(self::XML_PATH_EMAIL_SENDER, $storeScope))
                ->addTo($this->scopeConfig->getValue(self::XML_PATH_EMAIL_RECIPIENT, $storeScope))
                ->setReplyTo($post['email'])
                ->getTransport();

                //createAttachment();
                $transport->sendMessage();
                        
                //$message = $this->message;
                        
                /*Email Sending End*/
                $this->inlineTranslation->resume();
                $this->messageManager->addSuccess(
                    __('Thanks for contacting us. We\'ll respond to you very soon.')
                );
                        
                return $resultRedirect;
            } catch (\Exception $e) {
                $this->inlineTranslation->resume();
                $this->messageManager->addError(
                    __('Sorry We can\'t process your request right now.')
                );
                return $resultRedirect;
            }
        }else {
            $this->messageManager->addError(
                __(' Invalid captcha key.')
            );
            return $resultRedirect;
        }
    }
}
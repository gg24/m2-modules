<?php
namespace Bullitt\Quickrfq\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Registry;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	protected $_storeManager;
	public $_coreRegistry;

    public function __construct(
    	Context $context, StoreManagerInterface $storeManager, Registry $coreRegistry
    ) {
    	$this->_storeManager = $storeManager;
    	$this->_coreRegistry = $coreRegistry;
    	parent::__construct($context);
    	$this->_product = $this->_coreRegistry->registry('current_product');
	}

    public function getBrandstore(){
    	$getURL = $this->_storeManager->getStore()->getBaseUrl();
		
		if(strstr($getURL, '/en_no') || strstr($getURL, '/en_se') || strstr($getURL, '/en_dk') || strstr($getURL, '/es_ar') || strstr($getURL, '/de_ch') || strstr($getURL, '/it_ch') || strstr($getURL, '/fr_ch') || strstr($getURL, '/pt_pt')) {
		    return true;
		}elseif(strstr($getURL, '/en_za')){
			return 'en_za';
		}else{
			return false;
		}
    }

    public function getProductName(){
    	if($this->_product && $this->_product->getData('name')) {
		    return $this->_product->getData('name');
		}
    }
}
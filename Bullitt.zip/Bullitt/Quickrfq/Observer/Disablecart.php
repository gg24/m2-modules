<?php
namespace Bullitt\Quickrfq\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Request\Http;
use Magento\Store\Model\StoreManagerInterface;

class Disablecart implements ObserverInterface {

	protected $_storeManager;
	protected $_request;

    public function __construct(
    	StoreManagerInterface $storeManager, Http $request 
    ) {
        $this->_storeManager= $storeManager;
        $this->_request 	= $request;
    }

	public function execute(Observer $observer){
	 	$getURL 		= $this->_storeManager->getStore()->getBaseUrl();

	 	if(strstr($getURL, '/en_no') || strstr($getURL, '/en_se') || strstr($getURL, '/en_dk') || strstr($getURL, '/en_za') || strstr($getURL, '/es_ar') || strstr($getURL, '/fr_ch') || strstr($getURL, '/de_ch') || strstr($getURL, '/it_ch') || strstr($getURL, '/pt_pt') ) {
		    if ($this->_request->getFullActionName() == 'catalog_product_view') {
				$product = $observer->getEvent()->getProduct();
	            $product->setIsSalable(false);
	            if(strstr($getURL, '/en_za')){
	            	//echo  '<a class="rfq-modal-form">Request Quote</a>';
	            	$html1="<div class='button-set margin-top-36 al-center'><a class='rfq-modal-form button-yellowlink'>";
					$orderHere="Order here";
					$html2="</a></div>";

					echo $html1.__($orderHere).$html2;
	            }else{
	            	//if(!strstr($getURL, '/es_ar')){
		            	$html1="<div class='button-set margin-top-36 al-center'><a id='retailer-tab-open' class='button-yellowlink'>";
						$orderHere="Order here";
						$html2="</a></div>";

						echo $html1.__($orderHere).$html2;
					//}
	            }
			}
	    }else {
    		return $this;
        }
	}
}
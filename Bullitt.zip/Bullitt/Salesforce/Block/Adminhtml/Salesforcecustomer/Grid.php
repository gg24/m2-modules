<?php
namespace Bullitt\Salesforce\Block\Adminhtml\Salesforcecustomer;

class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    /**
     * @var \Magento\Framework\Module\Manager
     */
    protected $moduleManager;

    /**
     * @var \Bullitt\Salesforce\Model\salesforcecustomerFactory
     */
    protected $_salesforcecustomerFactory;

    /**
     * @var \Bullitt\Salesforce\Model\Status
     */
    protected $_status;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Bullitt\Salesforce\Model\salesforcecustomerFactory $salesforcecustomerFactory
     * @param \Bullitt\Salesforce\Model\Status $status
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param array $data
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Bullitt\Salesforce\Model\SalesforcecustomerFactory $SalesforcecustomerFactory,
        \Bullitt\Salesforce\Model\Status $status,
        \Magento\Framework\Module\Manager $moduleManager,
        array $data = []
    ) {
        $this->_salesforcecustomerFactory = $SalesforcecustomerFactory;
        $this->_status = $status;
        $this->moduleManager = $moduleManager;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('postGrid');
        $this->setDefaultSort('id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(false);
        $this->setVarNameFilter('post_filter');
    }

    /**
     * @return $this
     */
    protected function _prepareCollection()
    {
        $collection = $this->_salesforcecustomerFactory->create()->getCollection();
        $this->setCollection($collection);

        parent::_prepareCollection();

        return $this;
    }

    /**
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareColumns()
    {
        $this->addColumn(
            'id',
            [
                'header' => __('ID'),
                'type' => 'number',
                'index' => 'id',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id'
            ]
        );


		
				$this->addColumn(
					'customer_type',
					[
						'header' => __('Customer Type'),
						'index' => 'customer_type',
					]
				);
				
				$this->addColumn(
					'mid',
					[
						'header' => __('Contact Id'),
						'index' => 'mid',
					]
				);
				
				
				
				$this->addColumn(
					'prev_email',
					[
						'header' => __('Previous Email'),
						'index' => 'prev_email',
					]
				);
				
				$this->addColumn(
					'email',
					[
						'header' => __('Email'),
						'index' => 'email',
					]
				);

                $this->addColumn(
                    'orderid',
                    [
                        'header' => __('Order Id'),
                        'index' => 'orderid',
                    ]
                );
				
				$this->addColumn(
					'last_order',
					[
						'header' => __('Last Order'),
						'index' => 'last_order',
					]
				);
				
				$this->addColumn(
					'cust1',
					[
						'header' => __('Custom field1'),
						'index' => 'cust1',
					]
				);
				
				$this->addColumn(
					'cust2',
					[
						'header' => __('Custom field2'),
						'index' => 'cust2',
					]
				);
                $this->addColumn(
                    'sfid',
                    [
                        'header' => __('Custom field3'),
                        'index' => 'sfid',
                    ]
                );
				


		
        //$this->addColumn(
            //'edit',
            //[
                //'header' => __('Edit'),
                //'type' => 'action',
                //'getter' => 'getId',
                //'actions' => [
                    //[
                        //'caption' => __('Edit'),
                        //'url' => [
                            //'base' => '*/*/edit'
                        //],
                        //'field' => 'id'
                    //]
                //],
                //'filter' => false,
                //'sortable' => false,
                //'index' => 'stores',
                //'header_css_class' => 'col-action',
                //'column_css_class' => 'col-action'
            //]
        //);
		

		
		   $this->addExportType($this->getUrl('salesforce/*/exportCsv', ['_current' => true]),__('CSV'));
		   $this->addExportType($this->getUrl('salesforce/*/exportExcel', ['_current' => true]),__('Excel XML'));

        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }

        return parent::_prepareColumns();
    }

	
    /**
     * @return $this
     */
    protected function _prepareMassaction()
    {

        $this->setMassactionIdField('id');
        //$this->getMassactionBlock()->setTemplate('Bullitt_Salesforce::salesforcecustomer/grid/massaction_extended.phtml');
        $this->getMassactionBlock()->setFormFieldName('salesforcecustomer');

        $this->getMassactionBlock()->addItem(
            'delete',
            [
                'label' => __('Delete'),
                'url' => $this->getUrl('salesforce/*/massDelete'),
                'confirm' => __('Are you sure?')
            ]
        );

        $statuses = $this->_status->getOptionArray();

        $this->getMassactionBlock()->addItem(
            'status',
            [
                'label' => __('Change status'),
                'url' => $this->getUrl('salesforce/*/massStatus', ['_current' => true]),
                'additional' => [
                    'visibility' => [
                        'name' => 'status',
                        'type' => 'select',
                        'class' => 'required-entry',
                        'label' => __('Status'),
                        'values' => $statuses
                    ]
                ]
            ]
        );


        return $this;
    }
		

    /**
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('salesforce/*/index', ['_current' => true]);
    }

    /**
     * @param \Bullitt\Salesforce\Model\salesforcecustomer|\Magento\Framework\Object $row
     * @return string
     */
    public function getRowUrl($row)
    {
		
        return $this->getUrl(
            'salesforce/*/edit',
            ['id' => $row->getId()]
        );
		
    }

	

}
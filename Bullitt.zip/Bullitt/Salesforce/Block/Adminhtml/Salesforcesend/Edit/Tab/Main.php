<?php

namespace Bullitt\Salesforce\Block\Adminhtml\Salesforcesend\Edit\Tab;

/**
 * Salesforcesend edit form main tab
 */
class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @var \Bullitt\Salesforce\Model\Status
     */
    protected $_status;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Bullitt\Salesforce\Model\Status $status,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        /* @var $model \Bullitt\Salesforce\Model\BlogPosts */
        $model = $this->_coreRegistry->registry('salesforcesend');

        $isElementDisabled = false;

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Item Information')]);

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }

		
        $fieldset->addField(
            'od',
            'text',
            [
                'name' => 'od',
                'label' => __('Order data'),
                'title' => __('Order data'),
				
                'disabled' => $isElementDisabled
            ]
        );
					
        $fieldset->addField(
            'sfid',
            'text',
            [
                'name' => 'sfid',
                'label' => __('Salesforce Id'),
                'title' => __('Salesforce Id'),
				
                'disabled' => $isElementDisabled
            ]
        );
					
        $fieldset->addField(
            'rejson',
            'text',
            [
                'name' => 'rejson',
                'label' => __('Request Json'),
                'title' => __('Request Json'),
				
                'disabled' => $isElementDisabled
            ]
        );
					
        $fieldset->addField(
            'rsjson',
            'text',
            [
                'name' => 'rsjson',
                'label' => __('Response Json'),
                'title' => __('Response Json'),
				
                'disabled' => $isElementDisabled
            ]
        );
					

        $dateFormat = $this->_localeDate->getDateFormat(
            \IntlDateFormatter::MEDIUM
        );
        $timeFormat = $this->_localeDate->getTimeFormat(
            \IntlDateFormatter::MEDIUM
        );

        $fieldset->addField(
            'date',
            'date',
            [
                'name' => 'date',
                'label' => __('Date'),
                'title' => __('Date'),
                    'date_format' => $dateFormat,
                    //'time_format' => $timeFormat,
				
                'disabled' => $isElementDisabled
            ]
        );
						
						
						
        $fieldset->addField(
            'status',
            'text',
            [
                'name' => 'status',
                'label' => __('Status'),
                'title' => __('Status'),
				
                'disabled' => $isElementDisabled
            ]
        );
					
        $fieldset->addField(
            'message',
            'text',
            [
                'name' => 'message',
                'label' => __('Message'),
                'title' => __('Message'),
				
                'disabled' => $isElementDisabled
            ]
        );
					
        $fieldset->addField(
            'action',
            'text',
            [
                'name' => 'action',
                'label' => __('Action'),
                'title' => __('Action'),
				
                'disabled' => $isElementDisabled
            ]
        );
					
        $fieldset->addField(
            'cust1',
            'text',
            [
                'name' => 'cust1',
                'label' => __('Custom field1'),
                'title' => __('Custom field1'),
				
                'disabled' => $isElementDisabled
            ]
        );
					
        $fieldset->addField(
            'cust2',
            'text',
            [
                'name' => 'cust2',
                'label' => __('Custom Field2'),
                'title' => __('Custom Field2'),
				
                'disabled' => $isElementDisabled
            ]
        );
					

        if (!$model->getId()) {
            $model->setData('is_active', $isElementDisabled ? '0' : '1');
        }

        $form->setValues($model->getData());
        $this->setForm($form);
		
        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Item Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Item Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
    
    public function getTargetOptionArray(){
    	return array(
    				'_self' => "Self",
					'_blank' => "New Page",
    				);
    }
}

<?php
namespace Bullitt\Salesforce\Model;

class Salesforcesend extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Bullitt\Salesforce\Model\ResourceModel\Salesforcesend');
    }

}
?>
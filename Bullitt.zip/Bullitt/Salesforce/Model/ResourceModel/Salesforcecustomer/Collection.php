<?php

namespace Bullitt\Salesforce\Model\ResourceModel\Salesforcecustomer;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Bullitt\Salesforce\Model\Salesforcecustomer', 'Bullitt\Salesforce\Model\ResourceModel\Salesforcecustomer');
        $this->_map['fields']['page_id'] = 'main_table.page_id';
    }

}
?>
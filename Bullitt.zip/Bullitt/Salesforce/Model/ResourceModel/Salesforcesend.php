<?php
namespace Bullitt\Salesforce\Model\ResourceModel;

class Salesforcesend extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('salesforce_senddata', 'id');
    }
}
?>
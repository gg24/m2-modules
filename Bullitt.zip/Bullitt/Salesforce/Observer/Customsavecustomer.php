<?php
namespace Bullitt\Salesforce\Observer;

use Bullitt\Salesforce\Model\Salesforcecustomer;
use Bullitt\Salesforce\Model\SalesforcecustomerFactory;
use Magento\Customer\Model\Customer;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\ResourceConnection;
use Magento\Newsletter\Model\Subscriber;
use Bullitt\Salesforce\Helper\sfToken;
use Magento\Customer\Model\Session;
use Bullitt\Salesforce\Helper\sfContactid; 

class Customsavecustomer implements \Magento\Framework\Event\ObserverInterface
{
    protected $_customer;
    protected $_salesforcecustomer;
    protected $_salesforcecustomerFactory;
    protected $_context;
    protected $_resource;
    protected $_session;

    
    /**
     * @param OrderObj $orderObj
     */

    public function __construct(
    Customer $customer, Salesforcecustomer $salesforcecustomer, SalesforcecustomerFactory $salesforcecustomerFactory, Context $context, ResourceConnection $resource, Subscriber $subscriber ,sfToken $token, Session $Session, sfContactid $sfcontact
    ) {

        $this->_customer = $customer;
        $this->_salesforcecustomer = $salesforcecustomer;
        $this->_salesforcecustomerFactory = $salesforcecustomerFactory;
        $this->_context = $context;
        $this->_resource = $resource;
        $this->_subscriber = $subscriber;
        $this->_token = $token;
        $this->_session = $Session;
    }

    /**
     * @param Email $email
     * @param CustType $custtype
     * @return Mid $mid
     */

    public function getMid($email, $custtype, $custid,$callType='',$storid){
        
        $oldmail = $this->_session->getData('old_email');
        $custdata = array();        
        $connection = $this->_resource->getConnection();
        $tableName  = $this->_resource->getTableName('salesforce_customer');  

        //Check if MID exists on salesforce 
        if($callType=='editPost') {
                $sql = "SELECT id,mid,email,custid,customer_type,orderid FROM " . $tableName . " WHERE custid ='$custid'"; 
        }else{
            $sql = "SELECT id,mid,email,custid,customer_type,orderid FROM " . $tableName .
             " WHERE email ='$email' AND sfid ='$storid'"; 
        }
        $result = $connection->fetchAll($sql);
        
        if (isset($result) && (count($result) > 0)) {
            if($result[0]['customer_type'] == 'Guest' && $custtype == 'Registered' ) {
                $custtype ='Registered';
                $custdata = $result[0];
            }
        }else{
         $sql = "SELECT id,mid,email,custid,customer_type,orderid FROM " . $tableName .
         " WHERE custid ='$custid' OR email ='$oldmail' AND sfid ='$storid'"; 
            $result = $connection->fetchAll($sql);
        }

        if($custtype == 'Registered' && !empty($result)) 
        {   

            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/Sfctupdate.log');
            $logger = new \Zend\Log\Logger();
            $logger->addWriter($writer);

            $id = $result[0]['id'];
            if(!empty($result[0]['mid'])){
                $id = $result[0]['id'];
            }else if(!empty($result[1]['mid'])){
                $id = $result[1]['id'];
            }else{
                $logger->info('==== Sales Force  new case found for Customer ====');
                $logger->info('==== Sales Force  contact id not found ====');
                return $this; 
            }

            $sfCustomermodel = $this->_salesforcecustomer->load($id);
            $data = $sfCustomermodel->getData();

            $existEmail = $data['email'];
            $datcusttype = $data['customer_type'];
            $cusdatid = $data['custid'];
            $orderid = "";
            $last_order = "";
            $orderid = $data['orderid'];
            $last_order = $data['last_order'];

            if($datcusttype != $custtype && $cusdatid == null){
                $rcmctid = $data['mid'];

                if($oldmail != $email && !empty($oldmail)) {
                    $sfCustcretmodel = $this->_salesforcecustomerFactory->create();
                    $sfCustcretmodel->setCustid($custid);
                    $sfCustcretmodel->setCustomerType($custtype);
                    $sfCustcretmodel->setMid($rcmctid);
                    $sfCustcretmodel->setEmail($email);
                    $sfCustcretmodel->setSfid($storid);
                    $sfCustcretmodel->setOrderid($orderid);
                    $sfCustcretmodel->setLastOrder($last_order);
                    $sfCustcretmodel->setCreatedAt(date('Y-m-d H:i:s'));
                    $sfCustcretmodel->setUpdatedAt(date('Y-m-d H:i:s'));
                    $sfCustcretmodel->save();
                    $sfCustcretmodel->unsetData();
                    $logger->info('==== Sales Force  email changed and guest 
                        converted into registered ====');
                    return $rcmctid;


                }else{
                    $id = $result[0]['id'];
                    $sfCustomermodel = $this->_salesforcecustomer->load($id);
                    $data = $sfCustomermodel->getData();
                    $rcmctid = $data['mid'];
                    $sfCustomermodel->setCustid($custid);
                    $sfCustomermodel->setCustomerType($custtype);
                    $sfCustomermodel->setUpdatedAt(date('Y-m-d H:i:s'));
                    $sfCustomermodel->save();
                    $sfCustomermodel->unsetData();
                   
                    $logger->info('==== Sales Force  guest is converted into registered without email change ====');
                    return $rcmctid;    

                }


            }else if($datcusttype == $custtype && $cusdatid != null){
                    $id = $result[0]['id'];
                    $sfCustomermodel = $this->_salesforcecustomer->load($id);
                    $data = $sfCustomermodel->getData();
                    $cusdatid = $data['custid'];
                    $orderid = "";
                    $last_order = "";
                    $orderid = $data['orderid'];
                    $last_order = $data['last_order'];

                    $rcmctid = $data['mid'];
                if($email == $oldmail){
                    $sfCustomermodel->setCustid($custid);
                    $sfCustomermodel->setCustomerType($custtype);
                    $sfCustomermodel->setMid($rcmctid);
                    $sfCustomermodel->setEmail($email);
                    $sfCustomermodel->setSfid($storid);
                    $sfCustomermodel->setOrderid($orderid);
                    $sfCustomermodel->setLastOrder($last_order);
                    $sfCustomermodel->setUpdatedAt(date('Y-m-d H:i:s'));
                    $sfCustomermodel->save();
                    $sfCustomermodel->unsetData();

                    return $rcmctid;
                }else{

                    $sfCustcretmodel = $this->_salesforcecustomerFactory->create();
                    $sfCustcretmodel->setCustid($custid);
                    $sfCustcretmodel->setCustomerType($custtype);
                    $sfCustcretmodel->setMid($rcmctid);
                    $sfCustcretmodel->setEmail($email);
                    $sfCustcretmodel->setSfid($storid);
                    $sfCustcretmodel->setOrderid($orderid);
                    $sfCustcretmodel->setLastOrder($last_order);
                    $sfCustcretmodel->setCreatedAt(date('Y-m-d H:i:s'));
                    $sfCustcretmodel->setUpdatedAt(date('Y-m-d H:i:s'));
                    $sfCustcretmodel->save();
                    $sfCustcretmodel->unsetData();
                    $logger->info('==== Sales Force  email changed and Registered user changed email ====');
                    return $rcmctid;
                }

                }else{
                    $logger->info('==== Sales Force  ct new case ====');
                    return $this;
                }               
        }else{
            $logger->info('==== Sales Force info not found ====');
            return $this;
        }                
    }


    public function updateContact($token, $custdata){

       $endpoint = $this->_context->getScopeConfig()->getValue('salesforce_section/sf_mode/host');
        $url = $endpoint."/updateContact";
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER,
                array("Authorization: Bearer $token",
                    "Content-type: application/json"));
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $custdata);
        $json_response = curl_exec($curl);
        curl_close($curl);

        $response = json_decode($json_response, true);
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/sfcontact_update.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
         $logger->info('==== Sales Force  contact update ====');
            return $this;
    }


    public function execute(\Magento\Framework\Event\Observer $observer)
    { 
        $custdata = $this->_session->getCustomer()->getData();
        $storid = $this->_session->getCustomer()->getStoreId();
        $emailold =  $this->_session->getCustomer()->getEmail();
        $this->_session->setOldEmail($emailold);
        
        $request =  $this->_context->getRequest();
        $controller = $request->getControllerName();
        $action     = $request->getActionName();
        $customer  = $observer->getEvent()->getCustomer();
        $custid = $customer->getId();
        $customerdata = $this->_customer->load($custid);
        $email = $customer->getData('email');

        $newsl = "";
        $newsletter = $this->_subscriber->load($email, 'subscriber_email'); 
                            $emailExist =  $newsletter->getSubscriberStatus(); 
                            if($emailExist == 1){
                                $newsl = true;
                            }else{
                                $newsl = false;
                            } 

        if($controller == "account" && $action == "editPost")
        {  
            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/SalesforceorderSuccess.log');
            $logger = new \Zend\Log\Logger();
            $logger->addWriter($writer);
     
            if (empty($customerdata) || $email == null) {
                    $logger->info('==== Sales Force  Order Not Found ====');
                return $this;
            }
            else 
            {    
                try
                {    
                    $token = $this->_token->getToken();
                    if(!$token || empty($token) || $token == null){
                            $logger->info('==== Sales Force Access Token not found====');
                           return $this; 
                    }
                    else
                    {     
                        $CustomerType = "Registered";
                        $email = $customer->getData('email');
                        $fname = $customer->getData('firstname');
                        $lname = $customer->getData('lastname');
                        $magentoContactId = "";

                        $customerloginstatus = "Registered";
                        $magentoContactId = $this->getMid($email,$CustomerType,$custid,$callType='editPost', $storid);

                        $custarr = array("magentoContactId" => $magentoContactId,
                        "firstName" => $fname, "lastName" => $lname, "newsletter"
                         => $newsl, "email" => $email);

                        $sfcustupdt = array("orderInformation" => 
                            [array("cont" => $custarr)]);
                        
                        $custdata = json_encode($sfcustupdt, true);
                        $this->updateContact($token, $custdata);
                    }
                }
                catch (\Exception $e){
                    $this->messageManager->addError($e->getMessage());
                    return $this;
                }
            }
        }else if($controller == "index" && $action == "save"){ 

             $callType='admin';
             $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/SalesforceorderSuccessAdmin.log');
             $logger = new \Zend\Log\Logger();
             $logger->addWriter($writer);
         
             if (empty($customerdata) || $email == null) {
                $logger->info('==== Sales Force Order Not Found ====');
                return $this;
             }else { 
                 try
                { 
                     $token = $this->_token->getToken();
                     if(!$token || empty($token) || $token == null){
                     $logger->info('==== Sales Force Access Token not found====');
                     return $this; 
                     }else{ 
     
                        $customerType = "Registered";
                        $email = $customer->getData('email');
                        $fname = $customer->getData('firstname');
                        $lname = $customer->getData('lastname');
                        $storid = $customer->getData('store_id');
                        $custid = $customer->getData('id');
                         $magentoContactId = "";
                         
                         $magentoContactId = $this->getMid($email,$customerType,$custid,$callType='admin', $storid);
                         
                         $custarr = array("magentoContactId" => $magentoContactId,
                         "firstName" => $fname, "lastName" => $lname, "newsletter"
                         => $newsl, "email" => $email);
                         $sfcustupdt = array("orderInformation" => 
                         [array("cont" => $custarr)]);
                         
                         $custdata = json_encode($sfcustupdt, true);
                         $this->updateContact($token, $custdata);
                    }
                }
                 catch (\Exception $e){
                 $this->messageManager->addError($e->getMessage());
                 return $this;
                }
            }
        }else{
            return $this;       
        }
    }
}
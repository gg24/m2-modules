<?php
namespace Bullitt\Salesforce\Observer;
use Magento\Customer\Model\Session;
use Magento\Newsletter\Model\Subscriber;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\App\Helper\Context;
use Bullitt\Salesforce\Helper\sfToken;

class SFNewsletter implements \Magento\Framework\Event\ObserverInterface
{
    
    protected $_session;
    protected $_subscriber;
    protected $_context;
    protected $_resource;

  public function __construct(
    Session $Session, Subscriber $subscriber, ResourceConnection $resource, Context $context, sfToken $token
    ) {
        $this->_session = $Session;
        $this->_subscriber = $subscriber;
        $this->_context = $context;
        $this->_resource = $resource;
        $this->_token = $token;
    }


    /**
     * @param Email $email
     * @param CustType $custtype
     * @return Mid $mid
     */

    public function getMid($email, $custtype, $custid,$callType='',$storid){
        $oldmail = $this->_session->getData('old_email');
        $custdata = array();        
        $connection = $this->_resource->getConnection();
        $tableName  = $this->_resource->getTableName('salesforce_customer');  

        //Check if MID exists on salesforce 
        if($callType=='editPost') {
                $sql = "SELECT id,mid,email,custid,customer_type,orderid FROM " . $tableName .
             " WHERE email ='$email' AND sfid ='$storid'"; 
        }else{
            $sql = "SELECT id,mid,email,custid,customer_type,orderid FROM " . $tableName .
             " WHERE email ='$email' AND sfid ='$storid'"; 
        }

        $result = $connection->fetchAll($sql);
        
        if (isset($result) && (count($result) > 0)) {
            if($result[0]['customer_type'] == 'Guest' && $custtype == 'Registered' ) {
                $custtype ='Registered';
                $custdata = $result[0];
            }
        }else{
             $sql = "SELECT id,mid,email,custid,customer_type,orderid FROM " . $tableName .
         " WHERE custid ='$custid' OR email ='$oldmail' AND sfid ='$storid'"; 
            $result = $connection->fetchAll($sql);
            $custid = $result[0]['custid'];

        }

        //echo $sql;exit;
        if(!empty($result)){
           $mictid = $result[0]['mid'];
           return $mictid; 
        }else{
          return $this; 
        }
        
                      
    }


    public function updateContact($token, $custdata){

        $endpoint = $this->_context->getScopeConfig()->getValue('salesforce_section/sf_mode/host');
        $url = $endpoint."/updateContact";

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER,
                array("Authorization: Bearer $token",
                    "Content-type: application/json"));
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $custdata);
        $json_response = curl_exec($curl);
        curl_close($curl);

        $response = json_decode($json_response, true);
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/sfcontact_update.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
         $logger->info('==== Sales Force  contact update ====');
            return $this;
    }


  public function execute(\Magento\Framework\Event\Observer $observer)
  {

        $customer = $this->_session->getCustomer();
        $emailold =  $this->_session->getCustomer()->getEmail();
        $this->_session->setOldEmail($emailold);
  
        $newsletter = $this->_subscriber->load($emailold, 'subscriber_email'); 
                                  $emailExist =  $newsletter->getSubscriberStatus(); 
                                  if($emailExist == 1){
                                      $newsl = true;
                                  }else{
                                      $newsl = false;
                                  }
        if (empty($emailold) || $emailold == null) {
                $logger->info('==== Sales Force  Order Not Found ====');
            return $this;
        }
        else 
        {
            try
           {
                $token = $this->_token->getToken();

                if(!$token || empty($token) || $token == null){
                        $logger->info('==== Sales Force Access Token not found====');
                       return $this; 
                }
                else
                {
        
                        $CustomerType = "Registered";
                        $email = $emailold;
                        $fname = $customer->getData('firstname');
                        $lname = $customer->getData('lastname');
                        $custid = $customer->getData('entity_id');
                        $magentoContactId = "";

                        $storid = $customer->getData('store_id');
                        $custid = $customer->getData('id');
                         $magentoContactId = "";


                        $magentoContactId = $this->getMid($email,$CustomerType,$custid,$callType='editPost', $storid);

                        $custarr = array("magentoContactId" => $magentoContactId,
                        "firstName" => $fname, "lastName" => $lname, "newsletter"
                         => $newsl, "email" => $email);

                        $sfcustupdt = array("orderInformation" => 
                            [array("cont" => $custarr)]);
                        
                        $custdata = json_encode($sfcustupdt, true);
                        $this->updateContact($token, $custdata); 
                }
            }
            catch (\Exception $e) {
                echo $e->getMessage();
                $this->messageManager->addError($e->getMessage());
                return $this;
            }
        }
  }
}
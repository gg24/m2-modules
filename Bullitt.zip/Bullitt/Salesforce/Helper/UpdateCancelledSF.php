<?php
namespace Bullitt\Salesforce\Helper;

use Magento\Framework\App\ResourceConnection;
use Bullitt\Salesforce\Helper\sfToken;
use Bullitt\Salesforce\Helper\sfUpdateorder;


class UpdateCancelledSF {

    protected $_resource;

    /**
     * OrderObj 
     */
    public function __construct(
    ResourceConnection $resource, sfToken $token, sfUpdateorder $sfUpdateorder
    ) {
        $this->_resource = $resource;
        $this->_token = $token;
        $this->_sfUpdateorder = $sfUpdateorder;
    }

    public function updateCancelledInfoToSF($order, $logger)
    {
        $logger->info('---updateCancelledInfoToSF start---');
        if ($orderNr = $order->getIncrementId()) {

            /**************************/
            if (empty($orderNr) || $orderNr == null) {
                $logger->info('==== Sales Force  Order Not Found ====');
                return false;
            } else {
                try
                {
                    $token = $this->_token->getToken();

                    if(!$token || empty($token) || $token == null){
                            $logger->info('==== Sales Force Access Token not found====');
                            return false;
                    }else{
                        $connection         = $this->_resource->getConnection();
                        $status             = 'Cancelled';
                        $sendSfTable        = "salesforce_senddata";
                        $sendSfsql          = "SELECT * FROM " . $sendSfTable . " WHERE od = '$orderNr'"; 
                        $newSFResult        = $connection->fetchAll($sendSfsql);
                        
                        foreach ($newSFResult as $key => $value) {
                            if($value['od'] == $orderNr){
                                $ordjson    = $value['rejson'];
                                $ordjson    = json_decode($ordjson, true);
                            }
                        }

                        $rec                = $ordjson['OrderInformation'][0]['orders'];
                        $logger->info($rec);
                        $ordersg            = array();

                        foreach($rec as $val){
                            $ordersg[]      = array(
                                                "magentoContactId" => $val['magentoContactId'],
                                                "orderNr" => $val['orderNr'],
                                                "status" => $status,
                                                "trackingURL" => '',
                                                "trackingNumber" => '',
                                                "IMIENumber" => ''
                                            );
                        }

                        $sfordupdsatearray  = array(
                                                "OrderInformation" => [array("orders" => $ordersg)]
                                            );

                        $orddata            = json_encode($sfordupdsatearray, true);

                        $logger->info('--data send for salesforce---');
                        $logger->info($orddata);

                        $this->_sfUpdateorder->update_contactorder($token, $orddata);
                        return true;
                    }
                }
                catch (\Exception $e) {
                    $logger->info($e->getMessage());
                    return false;
                }
            }
        }else{
            /**************************/
            $logger->info('--Order Not Found--');
            return false;
        }
    }
}
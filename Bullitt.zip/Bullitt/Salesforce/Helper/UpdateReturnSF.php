<?php
namespace Bullitt\Salesforce\Helper;

use Magento\Framework\App\ResourceConnection;

class UpdateReturnSF {
    
    protected $_orderFactory;
    protected $_resource;

    /**
     * OrderObj 
     */
    public function __construct(
        \Magento\Sales\Model\OrderFactory $orderFactory,
        ResourceConnection $resource,
        sfToken $token,
        sfUpdateorder $sfUpdateorder
    ) {
        $this->_orderFactory = $orderFactory;
        $this->_resource = $resource;
        $this->_token = $token;
        $this->_sfUpdateorder = $sfUpdateorder;
    }

    public function updateReturnInfoToSF($logger)
    {
        $logger->info('---updateReturnInfoToSF start---');
        $connection = $this->_resource->getConnection();
        $tableName  = $this->_resource->getTableName('trigger_sf_after_dispatch');  

        //Update Data into table
        $sql        = '';
        $status     = 'Returned';
        $sql        = "SELECT order_id FROM " . $tableName . " WHERE send_sales_force =0 AND order_status = '$status'"; 
        $result     = $connection->fetchAll($sql);
        $logger->info($result);
        $result     = $connection->fetchAll($sql);
        if (isset($result) && (count($result) > 0)) {
            foreach ($result as $data) {
                if(isset($data['order_id'])) {
                    $order_id       = $data['order_id'];
                    if($order       = $this->_orderFactory->create()->loadByIncrementId($order_id)){
                        $orderNr    = $order->getData('increment_id');

                        /**************************/
                        if (empty($orderNr) || $orderNr == null) {
                                $logger->info('==== Sales Force  Order Not Found ====');
                            return $this;
                        } else {
                            try
                            {   
                                $token = $this->_token->getToken();
                                
                                if(!$token || empty($token) || $token == null){
                                        $logger->info('==== Sales Force Access Token not found====');
                                       return $this; 
                                }else{
                                    $status             = 'Returned';
                                    $sendSfTable        = "salesforce_senddata";
                                    $sendSfsql          = "SELECT * FROM " . $sendSfTable . " WHERE od = '$orderNr'"; 
                                    $newSFResult        = $connection->fetchAll($sendSfsql);

                                    foreach ($newSFResult as $key => $value) {
                                        $ordjson        = $value['cust1'];
                                        $ordjson        = json_decode($ordjson, true);
                                    }

                                    $rec                = $ordjson['OrderInformation'][0]['orders'];
                                    $ordersg            = array();

                                    foreach($rec as $val){
                                        $ordersg[]      = array(
                                                            "magentoContactId"  => $val['magentoContactId'],
                                                            "orderNr"           => $val['orderNr'],
                                                            "status"            => $status,
                                                            "shippingDate"      => $val['shippingDate'],
                                                            "trackingURL"       => $val['trackingURL'],
                                                            "trackingNumber"    => $val['trackingNumber'],
                                                            "IMIENumber"        => $val['IMIENumber'],
                                                        );
                                    }

                                    $sfordupdsatearray  = array(
                                                            "OrderInformation"  => [array("orders" => $ordersg)]
                                                        );

                                    $orddata            = json_encode($sfordupdsatearray, true);
                                    
                                    $this->_sfUpdateorder->update_contactorder($token, $orddata);

                                    $sql = "UPDATE " . $tableName . " SET send_sales_force=1 WHERE order_id='$orderNr' AND order_status = '$status'";
                                    $logger->info($sql);
                                    try {
                                        $connection->query($sql);
                                        $logger->info('----Returned flag on trigger_sf_after_dispatch table---');
                                    } catch (\Exception $e) {
                                        $logger->info($e->getMessage());
                                    }
                                }
                            }
                            catch (\Exception $e) {
                                $logger->info($e->getMessage());
                            }
                        }
                        /**************************/
                    }
                }else{
                    $logger->info('--Result is not proper--');
                }
            }
        }else{
            $logger->info('--No Result in select Query--');
        }
        return $this;
    }
}
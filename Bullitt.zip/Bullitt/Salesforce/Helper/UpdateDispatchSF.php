<?php
namespace Bullitt\Salesforce\Helper;

use Magento\Framework\App\ResourceConnection;

/**
 * Class updateDispatchSF
 *
 * @package Bullitt\Salesforce\Helper
 */
class UpdateDispatchSF {
    
    protected $_orderFactory;
    protected $_resource;

    /**
     * OrderObj 
     */
    public function __construct(
        \Magento\Sales\Model\OrderFactory $orderFactory,
        ResourceConnection $resource,
        sfToken $token,
        sfUpdateorder $sfUpdateorder
    ) {
        $this->_orderFactory = $orderFactory;
        $this->_resource = $resource;
        $this->_token = $token;
        $this->_sfUpdateorder = $sfUpdateorder;
    }

    //public function execute(\Magento\Framework\Event\Observer $observer)
    public function updateDispatchInfoToSF($logger)
    {   
        $logger->info('---updateDispatchInfoToSF start---');
        $connection = $this->_resource->getConnection();
        $tableName  = $this->_resource->getTableName('trigger_sf_after_dispatch');  

        //Update Data into table
        $sql        = '';
        $status     = 'Dispatched';
        $sql        = "SELECT order_id FROM " . $tableName . " WHERE send_sales_force =0 AND order_status = '$status'"; 
        $logger->info($sql);
        $result     = $connection->fetchAll($sql);
        $logger->info($result);
        if (isset($result) && (count($result) > 0)) {
            foreach ($result as $data) {
                if(isset($data['order_id'])) {
                    $order_id = $data['order_id'];
                    if($order = $this->_orderFactory->create()->loadByIncrementId($order_id)) {
                        $orderNr = $order->getData('increment_id');

                        $shipmentDate           = null; 
                        $shipmentsCollection    = $order->getShipmentsCollection();
                        if($shipmentsCollection){
                            $allColl    = $shipmentsCollection->getData();
                            foreach($allColl as $shipment){
                                $shipmentDate   = $shipment['created_at'];
                                $logger->info($shipmentDate);
                                $shipmentDate   = date("Y-m-d", strtotime($shipmentDate));
                            }
                        }

                        /**************************/
                        if (empty($orderNr) || $orderNr == null) {
                                $logger->info('==== Sales Force  Order Not Found ====');
                            return $this;
                        } else {  
                            try
                            {
                                $token = $this->_token->getToken();

                                if(!$token || empty($token) || $token == null){
                                        $logger->info('==== Sales Force Access Token not found====');
                                       return $this; 
                                }else{
                                    if($order->getData('status') == 'complete'){
                                        $status         = 'Dispatched';
                                    }else{
                                        $status         = 'Processed';
                                    }

                                    $trackingURL        = '';
                                    $trackingNumber     = '';
                                    $trackingURL        = $order->getData('custom_tracking_url');
                                    $trackingNumber     = $order->getData('custom_tracking_no');
                                    $items              = $order->getItemsCollection();

                                    $itemInfo           = [];
                                    $i                  = 0;
                                    foreach ($items as $item) {
                                        if($item->getData('imie_no') !=''){
                                            $sku        = $item->getData('sku');
                                            $sku        = str_replace("_CK","",$sku);
                                            $sku        = str_replace("_EB","",$sku);

                                            $imeiArray  = explode(",", $item->getData('imie_no'));
                                            if(is_array($imeiArray)){
                                                foreach($imeiArray as $value){
                                                    $itemInfo[$value] =  $sku;
                                                }
                                            }
                                        }
                                    }
                                    //echo '<pre>'; print_r($itemInfo); die('---112-----');
                                    $IMIENumber = "";
                                    
                                    $sendSfTable        = "salesforce_senddata";
                                    $sendSfsql          = "SELECT * FROM " . $sendSfTable . " WHERE od = '$orderNr'"; 
                                    $newSFResult        = $connection->fetchAll($sendSfsql);
                                    $logger->info($sendSfsql);
                                    $logger->info($newSFResult);
                                    foreach ($newSFResult as $key => $value) {
                                        $ordjson        = $value['rejson'];
                                        $ordjson        = json_decode($ordjson, true);
                                    }

                                    $rec                = $ordjson['OrderInformation'][0]['orders'];
                                    $ordersg            = array();

                                    
                                    foreach($rec as $val){
                                        $imeiNumberFirSF = '';
                                        if(isset($val['sku'])) {
                                            $currentSKU = $val['sku'];
                                            foreach($itemInfo as $_key=>$_val){
                                                if($val['sku'] == $_val){
                                                    $imeiNumberFirSF  =  $_key;
                                                    unset($itemInfo[$_key]);
                                                    break;
                                                }
                                            }
                                        }
                                        $ordersg[]  = array(
                                                        "magentoContactId"  => $val['magentoContactId'],
                                                        "orderNr"           => $val['orderNr'],
                                                        "status"            => $status,
                                                        "shippingDate"      => $shipmentDate,
                                                        "trackingURL"       => $trackingURL,
                                                        "trackingNumber"    => $trackingNumber,
                                                        "IMIENumber"        => $imeiNumberFirSF
                                                    );
                                    }

                                    $sfordupdsatearray  = array(
                                                            "OrderInformation" => [array("orders" => $ordersg)]
                                                        );

                                    $orddata            = json_encode($sfordupdsatearray, true);

                                    $logger->info('--data send for salesforce---');
                                    $logger->info($orddata);

                                    $this->_sfUpdateorder->update_contactorder($token, $orddata);

                                    //update salesforce_senddata table
                                    $sqlSFSendUpdate = "UPDATE " . $sendSfTable . " SET cust1='$orddata' WHERE od='$orderNr'";
                                    try {
                                        $connection->query($sqlSFSendUpdate);
                                        $logger->info($sqlSFSendUpdate);
                                        $logger->info('----update flag on trigger_sf_after_dispatch table---');
                                    } catch (\Exception $e) {
                                        $logger->info($e->getMessage());
                                    }
                                    
                                    //update salesforce_senddata table
                                    $sql = "UPDATE " . $tableName . " SET send_sales_force=1 WHERE order_id='$orderNr' AND order_status = '$status'";
                                    try {
                                        $connection->query($sql);
                                        $logger->info($sql);
                                        $logger->info('----update flag on trigger_sf_after_dispatch table---');
                                    } catch (\Exception $e) {
                                        $logger->info($e->getMessage());
                                    }
                                }
                            }
                            catch (\Exception $e) {
                                $logger->info($e->getMessage());
                            }
                        }
                        /**************************/
                    }
                }else{
                    $logger->info('--Result is not proper--');
                }
            }
        }else{
            $logger->info('--No Result in select Query--');
        }
        return $this;
    }
}
<?php
namespace Bullitt\Salesforce\Helper;

class sfsendMail extends \Magento\Framework\App\Helper\AbstractHelper {

    public function sendMailsf(){
       $to = "hlatifi@bullitt-group.com";
        $subject = "Magento Salesforce Connection";

            $message = "
            <html>
            <head>
            <title>Magento Salesforce Connection Issue </title>
            </head>
            <body>
            <p>Magento Salesforce Connection Issue ".date("Y-m-d H:m:s", time())."</p>
            </body>
            </html>
            ";

            // Always set content-type when sending HTML email
           $headers = 'MIME-Version: 1.0' . "\r\n";
            $headers='From: support@catphones.com \r\n';
            $headers.='Reply-To: support@catphones.com\r\n';
            $headers.='X-Mailer: PHP/' . phpversion().'\r\n';
            $headers.= 'MIME-Version: 1.0' . "\r\n";
            $headers.= 'Content-type: text/html; charset=iso-8859-1 \r\n';
            $headers .= 'From: <support@catphones.com>' . "\r\n";
            if (mail($to,$subject,$message,$headers)) {
                echo "mail sent";
            } else {
                echo "failed";
            }
            
    }
 
    public function execute()
    { 
            $this->sendMailsf();
        
    }

    
}
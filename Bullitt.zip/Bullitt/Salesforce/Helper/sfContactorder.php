<?php
namespace Bullitt\Salesforce\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Bullitt\Salesforce\Model\SalesforcesendFactory;

class sfContactorder extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_scopeConfig;
    protected $_resource;

    /**
     * @param OrderObj $orderObj
     */
    public function __construct(
    ScopeConfigInterface $scopeConfig, SalesforcesendFactory $salesforcesendFactory
    )
    {
        $this->_scopeConfig = $scopeConfig;
        $this->_salesforcesendFactory = $salesforcesendFactory;
    }

    /**
     * send data to Sales Force API for Create contact Order
     */

    public function create_contactorder($access_token, $Order, $_orderId) {

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/SalesforceorderSuccess.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $endpoint = $this->_scopeConfig->getValue('salesforce_section/sf_mode/host');

        $url = $endpoint."/createContactOrder";
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER,
                array("Authorization: Bearer $access_token",
                    "Content-type: application/json"));
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $Order);
        $json_response = curl_exec($curl);
        curl_close($curl);

        $response = json_decode($json_response, true);
        $keys = array_keys($response['OrderInformation']);
        $sfvalue = array_values($response['OrderInformation'][0]);
        $sfvalu = array_values($sfvalue[0]);
        $sfidm = $sfvalu[0];

        if($response['responseCode'] == 10001 && $response['responseStatus'] ==1 ){
            $logger->info('==== Order created successfully on Sales Force ====');
            $logger->info('responseCode= ' . $response['responseCode']);

            $sfsendmodel = $this->_salesforcesendFactory->create();
                
                    $sfid = $response['OrderInformation'][0];
                    $sfsendmodel->setOd($_orderId);
                    $sfsendmodel->setSfid($sfidm);
                    $sfsendmodel->setRejson($Order);
                    $sfsendmodel->setRsjson($json_response);
                    $sfsendmodel->setCreatedAt(date('Y-m-d H:i:s'));
                    $sfsendmodel->setStatus('1');
                    $sfsendmodel->setMessage($response['responseMsg']);
                    $sfsendmodel->setAction('Order created');
                    $sfsendmodel->save();
                    $sfsendmodel->unsetData();

            return $this;
        }else{
            $logger->info('==== Api hit but Order not created successfully on Sales Force ====');
            $logger->info('responseCode= ' . $response['responseCode']);
            $sfsendmodel = $this->_salesforcesendFactory->create();
                
                    $sfid = $response['OrderInformation']['SalesforceId'];
                    $sfsendmodel->setOd('1');
                    $sfsendmodel->setRejson($Order);
                    
                    $sfsendmodel->setRsjson($json_response);
                    $sfsendmodel->setCreatedAt(date('Y-m-d H:i:s'));
                    $sfsendmodel->setStatus('1');
                    $sfsendmodel->setMessage($response['responseMsg']);
                    $sfsendmodel->setAction('1');
                    $sfsendmodel->save();
                    $sfsendmodel->unsetData();
            return $this;
        }
    }
}
<?php
namespace Bullitt\Salesforce\Helper;
use Bullitt\Salesforce\Helper\sfsendMail;
use Magento\Framework\App\Config\ScopeConfigInterface;


class sfToken extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_scopeConfig;

    /**
     * @param OrderObj $orderObj
     */

    public function __construct(
    sfsendMail $sfsendmail, ScopeConfigInterface $scopeConfig
    ) {
        $this->_sfsendmail = $sfsendmail;
        $this->_scopeConfig = $scopeConfig;
    }

    public function getToken(){

        $endpoint = $this->_scopeConfig->getValue('salesforce_section/sf_mode/host');
        $acivestatus = $this->_scopeConfig->getValue('salesforce_section/sf_mode/active');
        $tokenurl = $this->_scopeConfig->getValue('salesforce_section/sf_mode/authorizeurl');

        $curl = curl_init($tokenurl);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER,
        array("Content-type: application/json"));
        curl_setopt($curl, CURLOPT_POST, true);
     
        $json_res = curl_exec($curl);
        curl_close($curl);
        $response = json_decode($json_res, true);
        $access_token = $response['access_token'];
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/SFtoken.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        if(!empty($access_token)){
            return $access_token;
        }else{
            $logger->info('==== Access Token not found ====');
            return $this->_sfsendmail->sendMailsf();
        } 
    }   
}
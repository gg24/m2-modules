<?php

namespace Bullitt\Salesforce\Controller\Adminhtml\salesforcesend;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPagee;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Index action
     *
     * @return void
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Bullitt_Salesforce::salesforcesend');
        $resultPage->addBreadcrumb(__('Bullitt'), __('Bullitt'));
        $resultPage->addBreadcrumb(__('Manage item'), __('Manage Salesforcesend'));
        $resultPage->getConfig()->getTitle()->prepend(__('Manage Salesforcesend'));

        return $resultPage;
    }
}
?>
<?php

namespace Bullitt\ThreePL\Model;

use Magento\Framework\Xml\Parser;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Sales\Model\Order;
use Bullitt\ThreePL\Helper\DownloadSftp;
use Bullitt\ThreePL\Helper\XmlValidator;
use Bullitt\ThreePL\Helper\UpdateImie;
use Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Sales\Model\Order\ShipmentFactory;
use Magento\Framework\DB\TransactionFactory;
use Magento\Sales\Model\Order\Shipment\TrackFactory;
use Magento\Framework\App\ResourceConnection;
use Magento\Sales\Api\OrderManagementInterface;
use Magento\Sales\Api\OrderRepositoryInterface;

use Loviit\Loviit\Helper\Payment;

class OrderDocomo {

    const ORDER_DISPATCH_LOCAL_DIR_CK = '3PL/charleskendall/Order/Dispatched';
    const ORDER_DISPATCH_SFTP_DIR_CK = 'charleskendall/Order/Dispatched';
    const ORDER_DISPATCH_XMLREAD_SFTP_DIR_CK = 'charleskendall/Order/XMLRead';
    const XML_VALIDATOR_PATH = '3PL/validator/OrderDispatched.xsd';

    protected $_directory_list;
    protected $_downloadSftp;
    protected $_parser;
    protected $_date;
    protected $_xmlValidator;
    protected $_order;
    protected $_payment;
    protected $_updateImie;
    protected $_resource;

    /* @var \Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory */
    protected $invoiceCollectionFactory;

    /* @var \Magento\Sales\Model\Service\InvoiceService */
    protected $invoiceService;

    /* @var \Magento\Sales\Model\Order\ShipmentFactory */
    protected $shipmentFactory;

    /* @var \Magento\Framework\DB\TransactionFactory */
    protected $transactionFactory;

    /* @var \Magento\Sales\Model\Order\Shipment\TrackFactory */
    protected $trackFactory;
    
    /* @var \Loviit\Loviit\Helper\Payment */
    protected $payment;
    

    /**
     * @var OrderManagementInterface
     */
    protected $orderManagement;

    /**
     * @var OrderRepositoryInterface
     */
    protected $orderRepository;

    /**
     * @param Parser $parser,
     * @param DirectoryList $directory_list
     * @param DownloadSftp $downloadSftp
     * @param DateTime $date
     * @param Order $orderObject 
     * @param XmlValidator $xmlValidator
     * @param CollectionFactory $invoiceCollectionFactory
     * @param InvoiceService $invoiceService
     * @param ShipmentFactory $shipmentFactory
     * @param TransactionFactory $transactionFactory
     * @param TrackFactory $trackFactory
     * @param OrderManagementInterface $orderManagement
     * @param OrderRepositoryInterface $orderRepository
     */
    public function __construct(
    Parser $parser, DirectoryList $directory_list, DateTime $date, Order $orderObject,
            DownloadSftp $downloadSftp, XmlValidator $xmlValidator, CollectionFactory $invoiceCollectionFactory,
            ShipmentFactory $shipmentFactory, InvoiceService $invoiceService, TransactionFactory $transactionFactory,
            TrackFactory $trackFactory, Payment $payment, UpdateImie $updateImie,  ResourceConnection $resource,OrderManagementInterface $orderManagement, OrderRepositoryInterface $orderRepository
    ) {
        $this->_parser = $parser;
        $this->_directory_list = $directory_list;
        $this->_date = $date;
        $this->_order = $orderObject;
        $this->_downloadSftp = $downloadSftp;
        $this->_xmlValidator = $xmlValidator;
        $this->invoiceCollectionFactory = $invoiceCollectionFactory;
        $this->invoiceService = $invoiceService;
        $this->shipmentFactory = $shipmentFactory;
        $this->transactionFactory = $transactionFactory;
        $this->trackFactory = $trackFactory;
        $this->_payment = $payment;
        $this->_updateImie = $updateImie;
        $this->_resource = $resource;
        $this->orderManagement = $orderManagement;
        $this->orderRepository = $orderRepository;
    }

    public function orderDispatchXML($logger, $earlBrown) {
        $earlBrown = false;
        $currentDateTime = date(DATE_ATOM, strtotime($this->_date->date()));
        $pubDir = $this->_directory_list->getPath('var');
        $xsdLocalPath = $pubDir . '/' . self::XML_VALIDATOR_PATH;
        
        $xmlLocalPath = $pubDir . '/' . self::ORDER_DISPATCH_LOCAL_DIR_CK . '/';
        $sftpPath = self::ORDER_DISPATCH_SFTP_DIR_CK . '/';
        $mvSftpFilePath = self::ORDER_DISPATCH_XMLREAD_SFTP_DIR_CK . '/';

        $fileDownloaded = $this->_downloadSftp->downloadFileSftp($xmlLocalPath, $sftpPath, $mvSftpFilePath, $logger, $earlBrown);
        $logger->info(print_r($fileDownloaded,1).'==== Order Success ====');
        if (is_array($fileDownloaded) && !empty($fileDownloaded)) {
            foreach ($fileDownloaded as $fileName) {
                $logger->info($fileName.'==== filename ===='); 
                $logger->info($fileName . ' : Downloaded');
                //$validated = true;
                $validated = $this->_xmlValidator->validateXmlFile($xsdLocalPath, $xmlLocalPath. $fileName, $logger);
                if ($validated == true) {
                    $parsedArray = $this->_parser->load($xmlLocalPath . $fileName)->xmlToArray();
                    
                    if($this->updateStatusUpdate($parsedArray['order_ship'], $logger)){
                        $logger->info($parsedArray['order_ship']['service']);
                        $logger->info($parsedArray['order_ship']['tracking_no']);
                    }
                } else {
                    $logger->info('==== Order dispatch Fail ====');
                }
            }
        } else {
            $logger->info( ' Order dispatch : NOT Downloaded');
            //echo 'File is not downloaded';
            return false;
        }
        return true;
    }

    /**
     * reindexData : reindex everything after new import
     */
    public function updateStatusUpdate($xmlInfo, $logger) {
        //echo '<pre>'; print_r($xmlInfo); die('=======sdfsdf');        
        if (count($xmlInfo) > 0) {
            $logger->info('==== Order Processed Start ====');
            if($order = $this->_order->loadByIncrementId($xmlInfo['order_no'])){
                $order_id = $order->getId();
                try {
                    $order = $this->orderRepository->get($order_id);
                } catch (NoSuchEntityException $e) {
                    $logger->info($e->getMessage());
                    return false;
                } catch (InputException $e) {
                    $logger->info($e->getMessage());
                    return false;
                }
                if(isset($xmlInfo['tracking_no']) && !empty($xmlInfo['tracking_no'])){
                    $result = $this->_payment->doDeliveryRequest($order,$xmlInfo['tracking_no']);
                    $logger->info(print_r($result,1).'==== Order Success ====');

                    if($result['success'] && isset($xmlInfo['service'])) {
                        $logger->info('==== Order Captured by Docomo Success ====');
                        
                        try {
                                $order->setCustomTrackingNo($xmlInfo['tracking_no']);
                                $order->setCustomTrackingUrl($xmlInfo['service']);
                                $order->save();
                            } catch (\Exception $e) {
                                $logger->info($e->getMessage());
                            }

                        $items = $order->getItemsCollection();
                        if($this->_updateImie->updatePhoneImie($items, $xmlInfo['shipped_items'], $logger)){
                            $xml = true;
                        }else{
                            return false;
                        }

                        $connection = $this->_resource->getConnection();
                        $tableName  = $this->_resource->getTableName('trigger_sf_after_dispatch');
                        $order_id   = $xmlInfo['order_no'];
                        $orderStatus   = 'Dispatched';

                        $sql = "INSERT INTO " . $tableName . " (`order_status`,`send_sales_force`,`order_id`) VALUES ('$orderStatus',0,'$order_id')";
                        
                        try {
                            $connection->query($sql);
                            $logger->info('----insert flag on trigger_sf_after_dispatch table---');
                        } catch (\Exception $e) {
                            $logger->info($e->getMessage());
                        }

                    }else{
                        $logger->info('==== Order Capture Issue Docomo ====');
                        $logger->info($result['message']);
                        return false;
                    }
                }
            }else{
                $logger->info($xmlInfo['order_no'].'=== not found');
                return false;
            }
            return true;
        }else{
            return false;
        }
    }

}
<?php

namespace Bullitt\ThreePL\Model;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Xml\Parser;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Catalog\Model\Product;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Indexer\Model\IndexerFactory;
//use Magento\Indexer\Model\Indexer\CollectionFactory;
use Bullitt\ThreePL\Helper\DownloadSftp;
use Bullitt\ThreePL\Helper\XmlValidator;

class Updateinventorym {

    const INVENTORY_NEW_LOCAL_DIR_EB = '3PL/earlbrown/Inventory/New';
    const INVENTORY_NEW_SFTP_DIR_EB = 'earlbrown/Inventory/New';
    const INVENTORY_XMLREAD_SFTP_DIR_EB = 'earlbrown/Inventory/XMLRead';
    const INVENTORY_NEW_LOCAL_DIR_CK = '3PL/charleskendall/Inventory/New';
    const INVENTORY_NEW_SFTP_DIR_CK = 'charleskendall/Inventory/New';
    const INVENTORY_XMLREAD_SFTP_DIR_CK = 'charleskendall/Inventory/XMLRead';
    const XML_VALIDATOR_PATH = '3PL/validator/Inventory.xsd';
    const INVENTORY_FILE_NAME_SFTP = 'Inventory_new.xml';
    const INVENTORY_INDEXER_ID = 'cataloginventory_stock';
    const CONFIG_FILE_SCHEMA = 'Inv.xsd';

    protected $_directory_list;
    protected $_downloadSftp;
    protected $_parser;
    protected $_date;
    protected $_product;
    protected $_stock;
    protected $_indexerFactory;
    protected $_xmlValidator;

    //protected $_indexerCollectionFactory;

    /**
     * @param Context $context
     * @param Parser $parser,
     * @param DirectoryList $directory_list
     * @param DownloadSftp $downloadSftp
     * @param DateTime $date
     * @param Product $product
     * @param StockRegistryInterface $stock
     * @param IndexerFactory $indexerFactory
     * @param XmlValidator $xmlValidator
     */
    public function __construct(
    Parser $parser, DirectoryList $directory_list, DownloadSftp $downloadSftp, DateTime $date, Product $product, StockRegistryInterface $stock, IndexerFactory $indexerFactory, XmlValidator $xmlValidator
    ) {
        $this->_directory_list = $directory_list;
        $this->_downloadSftp = $downloadSftp;
        $this->_parser = $parser;
        $this->_date = $date;
        $this->_product = $product;
        $this->_stock = $stock;
        $this->_indexerFactory = $indexerFactory;
        $this->_xmlValidator = $xmlValidator;
        //$this->_indexerCollectionFactory = $indexerCollectionFactory;
    }

    public function updateInventoryXML($logger, $earlBrown) {
        $currentDateTime = date(DATE_ATOM, strtotime($this->_date->date()));

        $pubDir = $this->_directory_list->getPath('var');
        $xsdLocalPath = $pubDir . '/' . self::XML_VALIDATOR_PATH;

        if ($earlBrown) {
            $xmlLocalPath = $pubDir . '/' . self::INVENTORY_NEW_LOCAL_DIR_EB . '/';
            $sftpPath = self::INVENTORY_NEW_SFTP_DIR_EB . '/';
            $mvSftpFilePath = self::INVENTORY_XMLREAD_SFTP_DIR_EB . '/';
        } else {
            $xmlLocalPath = $pubDir . '/' . self::INVENTORY_NEW_LOCAL_DIR_CK . '/';
            $sftpPath = self::INVENTORY_NEW_SFTP_DIR_CK . '/';
            $mvSftpFilePath = self::INVENTORY_XMLREAD_SFTP_DIR_CK . '/';
        }

        $fileDownloaded = $this->_downloadSftp->downloadFileSftp($xmlLocalPath, $sftpPath, $mvSftpFilePath, $logger, $earlBrown);

        if (is_array($fileDownloaded) && !empty($fileDownloaded)) {
            foreach ($fileDownloaded as $fileName) {
                $validated = $this->_xmlValidator->validateXmlFile($xsdLocalPath, $xmlLocalPath.$fileName, $logger);
                if ($validated == true) {
                    $parsedArray = $this->_parser->load($xmlLocalPath. $fileName)->xmlToArray();
                    $this->InventoryUpdate($parsedArray['items']['item'], $earlBrown, $logger);
                } else {
                    $logger->info('==== Inventory Validation Fail ====');
                    return false;
                }
            }
        }else {
            $logger->info( 'Inventory File : NOT Downloaded');
            //echo 'File is not downloaded';
            return false;
        }
        return true;
    }

    public function InventoryUpdate($items,$earlBrown, $logger) {
        if (count($items) > 0) {
            $logger->info('==== SKU Update Start ====');
            foreach ($items as $item) {
                $sku = '';
                if($earlBrown){
                    $sku = $item['sku_global'].'_EB';
                }else{
                    $sku = $item['sku_global'].'_CK';
                }
                
                $productId = $this->_product->getIdBySku($sku);
                //echo '<br/> product ID :' . $productId;
                if($productId){
                    $stockItem = $this->_stock->getStockItem($productId);
                    $stockItem->setQty($item['qty']);
                    $stockItem->setIsInStock(1);
                    $stockItem->setManageStock(1);
                    $stockItem->setUseConfigNotifyStockQty(1);
                    $stockItem->save();
                    $logger->info($item['sku_global']);
                }
            }
            $logger->info('==== Update End ====');
            $reindexDone = $this->reindexData();
            if ($reindexDone == true) {
                $logger->info('==== Re-Indexing Done ====');
            } else {
                $logger->info('==== Re-Index Fails ====');
            }
        }
    }

    /**
     * reindexData : reindex everything after new import
     */
    public function reindexData() {
        try {
            $idx = $this->_indexerFactory->create()->load(self::INVENTORY_INDEXER_ID);
            $idx->reindexRow(self::INVENTORY_INDEXER_ID);
        } catch (\Exception $e) {
            return false;
        }
        return true;
    }

}

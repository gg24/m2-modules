<?php

namespace Bullitt\ThreePL\Model;

use Magento\Framework\Xml\Parser;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Sales\Model\Order;
use Bullitt\ThreePL\Helper\DownloadSftp;
use Bullitt\ThreePL\Helper\XmlValidator;
use Magento\Framework\App\ResourceConnection; 

class Orderreturnm {
    
    const ORDER_RETURN_LOCAL_DIR_EB = '3PL/earlbrown/Return/New';
    const ORDER_RETURN_SFTP_DIR_EB = 'earlbrown/Return/New';
    const ORDER_RETURN_XMLREAD_SFTP_DIR_EB = 'earlbrown/Return/XMLRead';
    const ORDER_RETURN_LOCAL_DIR_CK = '3PL/charleskendall/Return/New';
    const ORDER_RETURN_SFTP_DIR_CK = 'charleskendall/Return/New';
    const ORDER_RETURN_XMLREAD_SFTP_DIR_CK = 'charleskendall/Return/XMLRead';
    
    const XML_VALIDATOR_PATH = '3PL/validator/OrderReturn.xsd';

    protected $_parser;
    protected $_directory_list;
    protected $_date;
    protected $_order;
    protected $_resource;
    protected $_downloadSftp;
    protected $_xmlValidator;

    /**
     * @param Parser $parser,
     * @param DirectoryList $directory_list
     * @param DownloadSftp $downloadSftp
     * @param DateTime $date
     * @param Order $orderObject 
     * @param XmlValidator $xmlValidator
     */
    public function __construct(
    Parser $parser, DirectoryList $directory_list, DateTime $date, Order $orderObject, DownloadSftp $downloadSftp, XmlValidator $xmlValidator, ResourceConnection $resource
    ) {
        $this->_parser = $parser;
        $this->_directory_list = $directory_list;
        $this->_date = $date;
        $this->_order = $orderObject;
        $this->_resource = $resource;
        $this->_downloadSftp = $downloadSftp;
        $this->_xmlValidator = $xmlValidator;
    }

    public function orderReturnXML($logger, $earlBrown) {
        $currentDateTime = date(DATE_ATOM, strtotime($this->_date->date()));

        $pubDir = $this->_directory_list->getPath('var');
        $xsdLocalPath = $pubDir . '/' . self::XML_VALIDATOR_PATH;

        if ($earlBrown) {
            $xmlLocalPath = $pubDir . '/' . self::ORDER_RETURN_LOCAL_DIR_EB . '/';
            $sftpPath = self::ORDER_RETURN_SFTP_DIR_EB. '/';
            $mvSftpFilePath = self::ORDER_RETURN_XMLREAD_SFTP_DIR_EB . '/';
        } else {
            $xmlLocalPath = $pubDir . '/' . self::ORDER_RETURN_LOCAL_DIR_CK . '/';
            $sftpPath = self::ORDER_RETURN_SFTP_DIR_CK. '/';
            $mvSftpFilePath = self::ORDER_RETURN_XMLREAD_SFTP_DIR_CK . '/';
        }

        $fileDownloaded = $this->_downloadSftp->downloadFileSftp($xmlLocalPath, $sftpPath, $mvSftpFilePath, $logger, $earlBrown);
        if (is_array($fileDownloaded) && !empty($fileDownloaded)) {
            foreach ($fileDownloaded as $fileName) {
                $logger->info($fileName . ' : Downloaded');
                $validated = $this->_xmlValidator->validateXmlFile($xsdLocalPath, $xmlLocalPath.$fileName, $logger);
                if ($validated == true) {
                    $parsedArray = $this->_parser->load($xmlLocalPath.$fileName)->xmlToArray();

                    $logger->info($parsedArray['order_return']['order_no']);
                    if(!$this->updateStatusUpdate($parsedArray['order_return'], $logger)){
                        $logger->info($fileName.'==== Order Return Fail ====');
                    }
                } else {
                    $logger->info($fileName.'==== Validation Fail ====');
                }
            }
        }else {
            $logger->info('Order Return Files : NOT Downloaded');
            //echo 'File is not downloaded';
            return false;
        }
        return true;
    }

    /**
     * reindexData : reindex everything after new import
     */
    public function updateStatusUpdate($items, $logger) {
        //echo '<pre>'; print_r($items); die('sdfsdf');        
        if (count($items) > 0) {
            $logger->info('==== Order Return update Start ====');

            $order = $this->_order->loadByIncrementId($items['order_no']);
            $logger->info('orderId= ' . $order->getIncrementId());
            $orderState = Order::STATE_COMPLETE;
            $order->setState($orderState)->setStatus('returned');
            try {
                $order->save();

                $connection = $this->_resource->getConnection();
                $tableName  = $this->_resource->getTableName('trigger_sf_after_dispatch');

                $order_id   = $items['order_no'];
                $orderStatus= 'Returned';

                $sql = "INSERT INTO " . $tableName . " (`order_status`,`send_sales_force`,`order_id`) VALUES ('$orderStatus',0,'$order_id')";

                try {
                    $connection->query($sql);
                    $logger->info('----insert Returned as 0 on trigger_sf_after_dispatch ----');
                } catch (\Exception $e) {
                    $logger->info($e->getMessage());
                }
            } catch (\Exception $e) {
                echo $e->getMessage();
                $logger->info($e->getMessage());
            }
            $logger->info('==== Order Return End ====');
        }
    }

}

<?php

namespace Bullitt\ThreePL\Model;

use Magento\Framework\App\Filesystem\DirectoryList;
//use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Framework\Stdlib\DateTime\Timezone;
use Bullitt\ThreePL\Helper\UploadSftp;
use Bullitt\ThreePL\Helper\ArrayToXml;

class OrderFrontendCancel {

    const CANCEL_ORDER_LOCAL_DIR_CK = '3PL/charleskendall/Cancel/New';
    const CANCEL_ORDER_LOCAL_DIR_EB = '3PL/earlbrown/Cancel/New';
    const XML_UPLOAD_PATH_ON_SFTP_CK = 'charleskendall/Cancel/New';
    const XML_UPLOAD_PATH_ON_SFTP_EB = 'earlbrown/Cancel/New';
    const US_STORE_ID = 8;
    const CANADA_EN_STORE_ID = 11;
    const CANADA_FR_STORE_ID = 10;
    const ROOT_NODE = "<order_cancel></order_cancel>";

    protected $_directory_list;
    protected $_date;
    protected $_arrayToXml;
    protected $_uploadSftp;

    /**
     * Constructor
     * @param DirectoryList $directory_list
     * @param UploadSftp $uploadSftp
     * @param ArrayToXml $arrayToXml
     */
    public function __construct(
    DirectoryList $directory_list, Timezone $date, UploadSftp $uploadSftp, ArrayToXml $arrayToXml
    ) {
        $this->_directory_list = $directory_list;
        $this->_date = $date;
        $this->_uploadSftp = $uploadSftp;
        $this->_arrayToXml = $arrayToXml;
    }

    /**
     * define execution of observer
     */
    public function xmlGeneration($order) {        
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/orderCancel.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Order Cancel');

        $logger->info($order->getData('store_id'));
        
        $earlBrown = false;
        $currentTime = $this->_date->date()->format('H:i:s');
        
        $currentDateTime = date(DATE_ATOM, strtotime($currentTime));
        $fileName = 'order_cancel_' . $order->getIncrementId() . '_' . $currentDateTime . '.xml';
        $pubDir = $this->_directory_list->getPath('var');
        $earlBrownStoreIDs = [self::US_STORE_ID, self::CANADA_EN_STORE_ID, self::CANADA_FR_STORE_ID];
        $fileNameOnSftp = $fileName;

        if (in_array($order->getData('store_id'), $earlBrownStoreIDs)) {
            $earlBrown = true;
            $xmlLocalPath = $pubDir . '/' . self::CANCEL_ORDER_LOCAL_DIR_EB . '/' . $fileName;
            $sftpPath = self::XML_UPLOAD_PATH_ON_SFTP_EB . '/';
        } else {
            $earlBrown = false;
            $xmlLocalPath = $pubDir . '/' . self::CANCEL_ORDER_LOCAL_DIR_CK . '/' . $fileName;
            $sftpPath = self::XML_UPLOAD_PATH_ON_SFTP_CK . '/';
        }

        $orderDetail = array();
        $orderDetail['order_no'] = $order->getData('increment_id');
        $orderDetail['creation_date'] = date(DATE_ATOM, strtotime($order->getData('created_at')));
        $orderDetail['cancel_date'] = date(DATE_ATOM, strtotime($order->getData('updated_at')));
        $orderDetail['cancel_remarks'] = "";

        $logger->info($orderDetail);
        $fileCreated = $this->_arrayToXml->generteXml($orderDetail, $xmlLocalPath, self::ROOT_NODE);

        $logger->info("fileCreated=========");
        $logger->info($fileCreated);
        
        if ($fileCreated) {
            $logger->info($xmlLocalPath);
            $logger->info( $sftpPath);
            $logger->info( $fileNameOnSftp);
            $fileUploaded = $this->_uploadSftp->uploadFileSftp($xmlLocalPath, $sftpPath, $fileNameOnSftp, $earlBrown, $logger);
        }
        
        if ($fileUploaded) {
            $logger->info(' ==== fileUploaded ====');
        }
        
        return true;
    }

}
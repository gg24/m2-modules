<?php
namespace Bullitt\ThreePL\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * sales order update
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $setup->startSetup();

        $version = $context->getVersion();
        $connection = $setup->getConnection();
     
        if (version_compare($version, '1.1.0') < 0) {
            $connection->addColumn(
                $setup->getTable('sales_order'),
                'custom_tracking_url',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 255,
                    'nullable' => true,
                    'comment' => 'Custom Tracking Url',
                ]
            );
        }
        
        if (version_compare($version, '1.2.0') < 0) {
            $connection->addColumn(
                $setup->getTable('sales_order_item'),
                'imie_no',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 255,
                    'nullable' => true,
                    'comment' => 'Imie No for Phone',
                ]
            );
        }

        if (version_compare($version, '1.3.0', '<')) {
            $connection->addColumn(
                $setup->getTable('sales_order'),
                'custom_tracking_no',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 100,
                    'nullable' => true,
                    'comment' => 'custom tracking no',
                ]
            );
        }
		
        $setup->endSetup();
    }
}
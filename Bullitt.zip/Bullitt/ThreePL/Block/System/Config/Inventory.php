<?php

namespace Bullitt\ThreePL\Block\System\Config;

use Magento\Backend\Block\Template\Context;
use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;

class Inventory extends Field {

    /**
     * @var $_template
     */
    protected $_template = 'Bullitt_ThreePL::system/config/inventory.phtml';

    /**
     * @param Context $context
     * @param array $data
     */
    public function __construct(
    Context $context, array $data = []
    ) {
        parent::__construct($context, $data);
    }

    /**
     * Remove scope label
     *
     * @param  AbstractElement $element
     * @return string
     */
    public function render(AbstractElement $element) {
        $element->unsScope()->unsCanUseWebsiteValue()->unsCanUseDefaultValue();
        return parent::render($element);
    }

    /**
     * Return element html
     * @param  AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element) {
        return $this->_toHtml();
    }

    /**
     * Return ajax url for collect button
     *
     * @return string
     */
    public function getAjaxUrlEB() {
        return $this->getUrl('bullitt_threepl/system_config/inventoryeb');
    }

    /**
     * Return ajax url for collect button
     *
     * @return string
     */
    public function getAjaxUrlCK() {
        return $this->getUrl('bullitt_threepl/system_config/inventoryck');
    }

    /**
     * Generate collect button html
     *
     * @return string
     */
    public function getButtonHtmlEB() {
        $button = $this->getLayout()->createBlock(
                        'Magento\Backend\Block\Widget\Button'
                )->setData(
                [
                    'id' => 'inventory_button_eb',
                    'label' => __('Earl Brown'),
                ]
        );
        return $button->toHtml();
    }

    /**
     * Generate collect button html
     *
     * @return string
     */
    public function getButtonHtmlCK() {
        $button = $this->getLayout()->createBlock(
                        'Magento\Backend\Block\Widget\Button'
                )->setData(
                [
                    'id' => 'inventory_button_ck',
                    'label' => __('Charles Kendall'),
                ]
        );
        return $button->toHtml();
    }

}

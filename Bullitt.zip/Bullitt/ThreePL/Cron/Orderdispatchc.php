<?php
namespace Bullitt\ThreePL\Cron;

use Bullitt\ThreePL\Model\OrderDocomo;
use Bullitt\Salesforce\Helper\UpdateDispatchSF;

class Orderdispatchc {

    protected $_dispatch;
    protected $_dispatchHelper;

    public function __construct(
        OrderDocomo $dispatch, UpdateDispatchSF $dispatchHelper
    ) {
        $this->_dispatch = $dispatch;
        $this->_dispatchHelper = $dispatchHelper;
    }

    /**
     * execute run via cronsetup
     */

    public function execute() {
        $earlBrown = false;
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/OrderDispatchedCK.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Cron Auto Run');
        $response = $this->_dispatch->orderDispatchXML($logger, $earlBrown);

        if ($response) {
            if($this->_dispatchHelper->updateDispatchInfoToSF($logger)){
                $logger->info('--Dispatch SF Done --');
            }else{
                $logger->info('--Dispatch SF Not Done--');
            }
            
            $logger->info('Order Dispatch Success CK');            
        } else {
            $logger->info('Order Dispatch Fails CK');
        }
    }

}

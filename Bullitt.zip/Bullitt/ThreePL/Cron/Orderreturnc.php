<?php
namespace Bullitt\ThreePL\Cron;

use Bullitt\ThreePL\Model\Orderreturnm;
use Bullitt\Salesforce\Helper\UpdateReturnSF;

class Orderreturnc {

    protected $_return;
    protected $_returnHelper;

    /**
     * @param Orderreturnm $return
     */
    public function __construct(
        Orderreturnm $return, UpdateReturnSF $returnHelper
    ) {
        $this->_return = $return;
        $this->_returnHelper    = $returnHelper;
    }

    /**
     * execute run via cronsetup
     */

    public function execute() {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/OrderReturnedCK.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Cron Auto Run---');

        $earlBrown = false;
        $response = $this->_return->orderReturnXML($logger, $earlBrown);

        if ($response) {
            if($this->_returnHelper->updateReturnInfoToSF($logger)){
                $logger->info('--Return SF Done --');
            }else{
                $logger->info('--Return SF Not Done--');
            }
            
            $logger->info('Order return Success CK');            
        } else {
            $logger->info('Order return Fails CK');
        }
    }

}
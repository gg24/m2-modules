<?php

namespace Bullitt\ThreePL\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Bullitt\ThreePL\Helper\UploadSftp;
use Bullitt\ThreePL\Helper\ArrayToXml;

class Index extends Action {

    const CANCEL_ORDER_LOCAL_DIR_CK = '3PL/charleskendall/Cancel/New';
    const CANCEL_ORDER_LOCAL_DIR_EB = '3PL/earlbrown/Cancel/New';
    const XML_UPLOAD_PATH_ON_SFTP_CK = 'charleskendall/Cancel/New';
    const XML_UPLOAD_PATH_ON_SFTP_EB = 'earlbrown/Cancel/New';
    const US_STORE_ID = 8;
    const CANADA_EN_STORE_ID = 11;
    const CANADA_FR_STORE_ID = 10;
    const ROOT_NODE = "<order_cancel></order_cancel>";

    protected $_directory_list;
    protected $_date;
    protected $_arrayToXml;
    protected $_uploadSftp;
    /**
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
    Context $context, DirectoryList $directory_list, DateTime $date, UploadSftp $uploadSftp, ArrayToXml $arrayToXml
    ) {
        $this->_directory_list = $directory_list;
        $this->_date = $date;
        $this->_uploadSftp = $uploadSftp;
        $this->_arrayToXml = $arrayToXml;
        parent::__construct($context);
    }

    /**
     * define execution of observer
     */
    public function execute() {

        // Test script for testing only will remove after this

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/orderCancel.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Order Cancel');

        
        $logger->info('----');
        
        $earlBrown = false;
        $currentDateTime = date(DATE_ATOM, strtotime($this->_date->date()));
        $fileName = 'order_cancel_' .  '_' . $currentDateTime . '.xml';
        $pubDir = $this->_directory_list->getPath('var');
        $earlBrownStoreIDs = [self::US_STORE_ID, self::CANADA_EN_STORE_ID, self::CANADA_FR_STORE_ID];
        $fileNameOnSftp = $fileName;

        $earlBrown = false;
        $xmlLocalPath = $pubDir . '/' . self::CANCEL_ORDER_LOCAL_DIR_CK . '/' . $fileName;
        $sftpPath = self::XML_UPLOAD_PATH_ON_SFTP_CK . '/';

        $orderDetail = array();
        $orderDetail['order_no'] = "11111111111";
        $orderDetail['creation_date'] = "";
        $orderDetail['cancel_date'] = "";
        $orderDetail['cancel_remarks'] = "";

        $logger->info($orderDetail);
        $fileCreated = $this->_arrayToXml->generteXml($orderDetail, $xmlLocalPath, self::ROOT_NODE);

        $logger->info("fileCreated=========");
        $logger->info($fileCreated);
        
        if ($fileCreated) {
            $logger->info($xmlLocalPath);
            $logger->info( $sftpPath);
            $logger->info( $fileNameOnSftp);
            $fileUploaded = $this->_uploadSftp->uploadFileSftp($xmlLocalPath, $sftpPath, $fileNameOnSftp, $earlBrown, $logger);
        }

        if ($fileUploaded) {
            echo '----fileUploaded---';
            $logger->info(' ==== fileUploaded ====');
        }else{
             echo '----file not Uploaded---';
        }

        echo '----done---';

    }
    
}

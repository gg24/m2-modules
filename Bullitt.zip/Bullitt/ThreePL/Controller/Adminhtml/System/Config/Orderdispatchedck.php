<?php

namespace Bullitt\ThreePL\Controller\Adminhtml\System\Config;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Bullitt\ThreePL\Model\OrderDocomo;
use Bullitt\Salesforce\Helper\UpdateDispatchSF;

class Orderdispatchedck extends Action {

    protected $resultJsonFactory;
    protected $_dispatch;
    protected $_dispatchHelper;

    /**
     * @param Context $context
     * @param JsonFactory $resultJsonFactory
     */
    public function __construct(
        Context $context, JsonFactory $resultJsonFactory, OrderDocomo $dispatch, UpdateDispatchSF $dispatchHelper
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_dispatch = $dispatch;
        $this->_dispatchHelper = $dispatchHelper;
        parent::__construct($context);
    }

    /**
     * Collect relations data
     *
     * @return \Magento\Framework\Controller\Result\Json
     */
    public function execute() {
        $earlBrown = false;
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/OrderDispatchedCK.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Cron Excuted By Manual Run');
        $response = $this->_dispatch->orderDispatchXML($logger, $earlBrown);

        $result = $this->resultJsonFactory->create();
        $logger->info('--threePL done now Dispatch salesforce--');
        if ($response) {
            if($this->_dispatchHelper->updateDispatchInfoToSF($logger)){
                $logger->info('--Dispatch SF Done --');
            }else{
                $logger->info('--Dispatch SF Not Done--');
            }
            return $result->setData(['success' => true, 'msg' => 'Order Dispatch Success']);
        } else {
            return $result->setData(['success' => false, 'msg' => 'Order Dispatch Fails']);
        }
    }

    protected function _isAllowed() {
        return $this->_authorization->isAllowed('Bullitt_ThreePL::config');
    }

}
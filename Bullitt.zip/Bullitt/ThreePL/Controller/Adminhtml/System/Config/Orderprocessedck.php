<?php

namespace Bullitt\ThreePL\Controller\Adminhtml\System\Config;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Bullitt\ThreePL\Model\Orderprocessm;
use Bullitt\Salesforce\Helper\UpdateProcessedSF;

class Orderprocessedck extends Action {

    protected $resultJsonFactory;
    protected $_processed;
    protected $_processedHelper;

    /**
     * @param Context $context
     * @param JsonFactory $resultJsonFactory
     */
    public function __construct(
        Context $context, JsonFactory $resultJsonFactory, Orderprocessm $processed, UpdateProcessedSF $processedHelper
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_processed = $processed;
        $this->_processedHelper = $processedHelper;
        parent::__construct($context);
    }

    /**
     * execute
     * @return \Magento\Framework\Controller\Result\Json
     */
    public function execute() {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/OrderProcessedCK.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Cron Excuted By Manual Run');
        $result = $this->resultJsonFactory->create();
        $earlBrown = false;
        $response = $this->_processed->orderProcessedXML($logger, $earlBrown);
        
        if($response){
            if($this->_processedHelper->updateProcessedInfoToSF($logger)){
                $logger->info('--Processed SF Done --');
            }else{
                $logger->info('--Processed Not Done--');
            }
            
            return $result->setData(['success' => true, 'msg' => 'Order Processed Success']);
        }else{
            return $result->setData(['success' => false, 'msg' => 'Order Processed Fails']);
        }        
    }

    protected function _isAllowed() {
        return $this->_authorization->isAllowed('Bullitt_ThreePL::config');
    }

}
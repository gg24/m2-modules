<?php

namespace Bullitt\ThreePL\Controller\Adminhtml\System\Config;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Bullitt\ThreePL\Model\Updateinventorym;

class Inventoryeb extends Action {

    /* @var \Magento\Framework\Controller\Result\JsonFactory */
    protected $resultJsonFactory;
    
    /* @var \Bullitt\ThreePL\Model\Updateinventorym */
    protected $_inventory;

    /**
     * @param Context $context
     * @param JsonFactory $resultJsonFactory
     */
    public function __construct(
    Context $context, JsonFactory $resultJsonFactory, Updateinventorym $inventory
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_inventory = $inventory;
        parent::__construct($context);
    }

    /**
     * execute
     *
     * @return \Magento\Framework\Controller\Result\Json
     */
    public function execute() {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/InventoryUpdate.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Cron Excuted By Manual Run');
        $result = $this->resultJsonFactory->create();
        $earlBrown = true;
        $response = $this->_inventory->updateInventoryXML($logger, $earlBrown);

        if ($response) {
            return $result->setData(['success' => true, 'msg' => 'Inventory Update Success']);
        } else {
            return $result->setData(['success' => false, 'msg' => 'Inventory Update Fails']);
        }
    }

    protected function _isAllowed() {
        return $this->_authorization->isAllowed('Bullitt_ThreePL::config');
    }

}
<?php

namespace Bullitt\ThreePL\Helper;

use Magento\Store\Model\Store;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Filesystem\Io\Sftp;
use Bullitt\ThreePL\Helper\SftpDetails;

class UploadSftp extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_sftp;
    protected $_sftpDetails;

    /**
     * @param Context $context
     * @param Sftp $sftp
     * @param SftpDetails $sftpDetails
     */
    public function __construct(
    Context $context, Sftp $sftp, SftpDetails $sftpDetails
    ) {
        $this->_sftp = $sftp;
        $this->_sftpDetails = $sftpDetails;
        parent::__construct($context);
    }

    /**
     * Upload File to Sftp
     * @param string $xmlLocalPath
     * @param string $sftpPath
     * @param string $fileNameOnSftp
     * 
     * @return boolean
     */
    public function uploadFileSftp($xmlLocalPath, $sftpPath, $fileNameOnSftp, $earlBrown, $logger) {
        if (!$earlBrown) {
            $details = $this->_sftpDetails->getCKConfig();
        } else {
            $details = $this->_sftpDetails->getEBConfig();
        }
        try {
            $this->_sftp->open($details);
            $this->_sftp->cd($sftpPath);
//          print_r($this->_sftp->ls()); die('sss');
            $content = file_get_contents($xmlLocalPath);
            if (!$this->_sftp->write($fileNameOnSftp, $content)) {
                $logger->info($fileNameOnSftp);
                $logger->info('XML File Not uploaded on, SFTP');
            } else {
                $logger->info($fileNameOnSftp);
                $logger->info('XML File uploaded on, SFTP');
            }
            $this->_sftp->close();
        } catch (\Exception $e) {
            echo $e->getMessage();
        }
        return true;
    }

}

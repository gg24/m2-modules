<?php

namespace Bullitt\ThreePL\Helper;

use Magento\Store\Model\Store;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\ResourceConnection;

class UpdateImie extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_resource;

    /**
     * @param Context $context
     * @param ResourceConnection $resource
     */
    public function __construct(
    Context $context, ResourceConnection $resource
    ) {
        $this->_resource = $resource;
        parent::__construct($context);
    }

    /**
     * Upload File to Sftp
     * @param object $ordersItem
     * @param ayyar $xmlItem
     * @param object $logger
     * 
     * @return boolean
     */
    public function updatePhoneImie($orderItemObj, $xmlItemArray, $logger) {
        //required earlbowwn for sku condition
        $orderItems = [];
        $xmlItems = [];
        $imieNumbers = [];
        //echo '<pre>'; print_r($xmlItemArray);
        //echo '<pre>'; print_r($orderItemObj->getData());
        //die('sdfsdf');
        
        if (!empty($xmlItemArray)) {
            if (isset($xmlItemArray['item']['product_name'])) {
                $singleItem = $xmlItemArray['item'];
                if (isset($singleItem['sku']) && isset($singleItem['imei_no'])) {
                    $xmlItems[$singleItem['imei_no']] = $singleItem['sku'];
                }
            } else {
                foreach ($xmlItemArray['item'] as $item) {
                    if (isset($item['sku']) && isset($item['imei_no'])) {
                        $xmlItems[$item['imei_no']] = $item['sku'];
                    }
                }
            }
            
            if (!empty($xmlItems)) {
                foreach ($orderItemObj as $item) {
                    $sku = $item->getData('sku');
                    $sku = str_replace("_CK","",$sku);
                    $sku = str_replace("_EB","",$sku);
                    $orderItems[$item->getData('item_id')] = $sku;
                }
                //echo '<pre>'; print_r($orderItems); die('sdfsdf');
                foreach ($xmlItems as $xmlImieNo => $xmlSku) {
                    foreach ($orderItems as $orderItemId => $orderItemSku) {
                        if ($xmlSku == $orderItemSku) {
                            if(!isset($imieNumbers[$orderItemId])){
                                $imieNumbers[$orderItemId] = $xmlImieNo;
                            }else{
                                $t = $imieNumbers[$orderItemId];
                                $imieNumbers[$orderItemId] = $xmlImieNo.','.$t;
                            }
                        }
                    }
                }
            }
        }
        //echo '<pre>'; print_r($imieNumbers); die('sdfsdf');        
        if (!empty($imieNumbers)) {
            $connection = $this->_resource->getConnection();
            $tableName = $this->_resource->getTableName('sales_order_item');
            foreach ($imieNumbers as $itemID => $imieNo) {
                $sql = "Update " . $tableName . " Set `imie_no` = '$imieNo' where `item_id` = '$itemID'";
                $logger->info($sql);
                try {
                    $connection->query($sql);
                    $logger->info("success : " . $itemID . " : item no, imie no : " . $imieNo);
                } catch (\Exception $e) {
                    $e->getMessage();
                    $logger->info("Fails : " . $itemID . " : item no, imie no : " . $imieNo);
                }
            }
        }
        return true;
    }

}

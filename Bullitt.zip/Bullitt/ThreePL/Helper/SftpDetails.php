<?php

namespace Bullitt\ThreePL\Helper;

use Magento\Store\Model\Store;
use Magento\Framework\App\Helper\Context;

class SftpDetails extends \Magento\Framework\App\Helper\AbstractHelper {

    const XML_PATH_CK_ACTIVE = 'bullitt_section/sftp_data_group_ck/active';
    const XML_PATH_CK_HOST = 'bullitt_section/sftp_data_group_ck/host';
    const XML_PATH_CK_USERNAME = 'bullitt_section/sftp_data_group_ck/user';
    const XML_PATH_CK_PASSWORD = 'bullitt_section/sftp_data_group_ck/pass';
    const XML_PATH_EB_ACTIVE = 'bullitt_section/sftp_data_group_eb/active';
    const XML_PATH_EB_HOST = 'bullitt_section/sftp_data_group_eb/host';
    const XML_PATH_EB_USERNAME = 'bullitt_section/sftp_data_group_eb/user';
    const XML_PATH_EB_PASSWORD = 'bullitt_section/sftp_data_group_eb/pass';

    protected $_scopeConfig;
    protected $_request;

    /**
     * @param Context $context
     */
    public function __construct(
    Context $context
    ) {
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_request = $context->getRequest();
        parent::__construct($context);
    }

    /**
     * get EarlBrown configuration details
     * @return $params array 
     */
    public function getEBConfig() {
        if ($this->isEBEnable()) {
            $host = $this->getEBHost();
            $username = $this->getEBUser();
            $password = $this->getEBPassword();

            $params = array(
                'host' => $host,
                'username' => $username,
                'password' => $password,
                'timeout' => 40
            );

            return $params;
        }
    }

    /**
     * get Charles Kendall configuration details
     * @return $params array 
     */
    public function getCKConfig() {
        if ($this->isCKEnable()) {
            $host = $this->getCKHost();
            $username = $this->getCKUser();
            $password = $this->getCKPassword();
            $params = array(
                'host' => $host,
                'username' => $username,
                'password' => $password,
                'timeout' => 40
            );
            return $params;
        }
    }

    /* CK config */

    public function isCKEnable($store = null) {
        return $this->getConfigValue(self::XML_PATH_CK_ACTIVE, $store);
    }

    public function getCKHost($store = null) {
        return $this->getConfigValue(self::XML_PATH_CK_HOST, $store);
    }

    public function getCKUser($store = null) {
        return $this->getConfigValue(self::XML_PATH_CK_USERNAME, $store);
    }

    public function getCKPassword($store = null) {
        return $this->getConfigValue(self::XML_PATH_CK_PASSWORD, $store);
    }

    /* EB config */

    public function isEBEnable($store = null) {
        return $this->getConfigValue(self::XML_PATH_EB_ACTIVE, $store);
    }

    public function getEBHost($store = null) {
        return $this->getConfigValue(self::XML_PATH_EB_HOST, $store);
    }

    public function getEBUser($store = null) {
        return $this->getConfigValue(self::XML_PATH_EB_USERNAME, $store);
    }

    public function getEBPassword($store = null) {
        return $this->getConfigValue(self::XML_PATH_EB_PASSWORD, $store);
    }

    public function getConfigValue($path, $storeId = null) {
        $storeId = $this->_request->getParam(\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $websiteId = $this->_request->getParam(\Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE);

        if (!empty($websiteId)) {
            $configValue = $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE, $websiteId);
        } else {
            $configValue = $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE, 0);
        }

        return $configValue;
    }

}

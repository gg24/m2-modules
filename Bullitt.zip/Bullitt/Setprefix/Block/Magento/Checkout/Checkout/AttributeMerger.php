<?php

namespace Bullitt\Setprefix\Block\Magento\Checkout\Checkout;


class AttributeMerger extends \Magento\Checkout\Block\Checkout\AttributeMerger
{
	
	protected function getDefaultValue($attributeCode)
    {
        switch ($attributeCode) {
            case 'prefix':
                if ($this->getCustomer()) {
                    return $this->getCustomer()->getPrefix();
                }
                break;
            case 'firstname':
                if ($this->getCustomer()) {
                    return $this->getCustomer()->getFirstname();
                }
                break;
            case 'lastname':
                if ($this->getCustomer()) {
                    return $this->getCustomer()->getLastname();
                }
                break;
            
        }
        return null;
    }
}
	
	
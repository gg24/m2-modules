<?php
/**
 * Puma_Customerrule extension
 * @category  Puma
 * @package   Puma_Customerrule
 * @copyright Copyright (c) 2018
 * @author    Nikesh
 */
?>
<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Puma_Customerrule',
    __DIR__
);
<?php
namespace Puma\Customdashboard\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Sales\Model\Order;

class Customdashboard extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_scopeConfig;
    protected $authSession;
	protected $_resource;

    public function __construct(
    ScopeConfigInterface $scopeConfig,
    \Magento\Backend\Model\Auth\Session $authSession,
	\Magento\Framework\App\ResourceConnection $resource,
	Order $Order
    )
    {
        $this->_scopeConfig = $scopeConfig;
        $this->authSession = $authSession;
		$this->_resource = $resource;
		$this->_order = $Order;
    }



    public function getOutstandingQuote()
    { 
      
        $sqlSelect = $this->_resource->getConnection()->select();
        $comparr = $this->getCompanybySalesrepresentative();
        $compid = $comparr[0];

        $custemail = $this->getCustomerbyCompany($compid);
        $custid = $this->getCustomerbyemail($custemail);
        
        $sqlSelect->from($this->_resource->getTableName('negotiable_quote'))
                ->where('creator_id IN (?)', $custid)
                ->where('status NOT IN (?)', 'submitted_by_admin');

        $resourceArr = $this->_resource->getConnection()->fetchcol($sqlSelect);

        if(count($resourceArr) == 0){
            return 0;
        }else{
            return count($resourceArr);
        }
    }

    public function getOrdersbyDay($day)
    { 
        $timezone = $this->_scopeConfig->getValue('general/locale/timezone', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        date_default_timezone_set($timezone);
        $ordershippeddays = $day; // number of days you want
        $fromDate         = gmdate("Y-m-d H:i:s", gmmktime(0, 0, 0, gmdate("m"), gmdate("d") - $ordershippeddays, gmdate("Y")));
        $toDate           = gmdate("Y-m-d H:i:s", gmmktime(23, 59, 59, gmdate("m"), gmdate("d"), gmdate("Y")));

        $ordercollection = $this->_order->getCollection();
        $ordercollection->addAttributeToFilter('created_at', array('from' => $fromDate, 'to' => $toDate));
        $count = count($ordercollection);
        
        return $count;
    }

    public function getCompanybySalesrepresentative()
    { 
        $sqlSelect = $this->_resource->getConnection()->select();
        $sqlSelect->from($this->_resource->getTableName('company'), ['entity_id'])
                ->where('sales_representative_id IN (?)', $this->authSession->getUser()->getId());

        $resourceArr = $this->_resource->getConnection()->fetchcol($sqlSelect);
        return $resourceArr;

        
    }

    public function getCustomerbyCompany($companyid)
    { 
        $sqlSelect = $this->_resource->getConnection()->select();
        $sqlSelect->from($this->_resource->getTableName('company'), ['company_email'])
                ->where('entity_id IN (?)', $companyid);

        $resourceArr = $this->_resource->getConnection()->fetchcol($sqlSelect);
        return $resourceArr;
    }

    public function getCustomerbyemail($email)
    { 
        $sqlSelect = $this->_resource->getConnection()->select();
        $sqlSelect->from($this->_resource->getTableName('customer_entity'), ['entity_id'])
                ->where('email IN (?)', $email);
       $resourceArr = $this->_resource->getConnection()->fetchcol($sqlSelect);

       if(count($resourceArr) == 0){
            return '';
        }else{
            return $resourceArr;
        }
    }
}
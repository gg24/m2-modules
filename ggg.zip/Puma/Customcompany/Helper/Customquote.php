<?php
namespace Puma\Customcompany\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Pricing\Helper\Data;
use Magento\Authorization\Model\Acl\AclRetriever;
use Magento\Sales\Model\Order;

class Customquote extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_scopeConfig;
    protected $authSession;
	protected $_resource;

    public function __construct(
    ScopeConfigInterface $scopeConfig,
    \Magento\Backend\Model\Auth\Session $authSession,
	\Magento\Framework\App\ResourceConnection $resource,
	\Magento\Company\Model\ResourceModel\Company\Collection $Collection,
    Data $pricehelper,
    AclRetriever $aclRetriever,
    Order $order
    )
    {
        $this->_scopeConfig = $scopeConfig;
        $this->authSession = $authSession;
		$this->_resource = $resource;
		$this->_collection = $Collection;
        $this->_pricehelper = $pricehelper;
        $this->_aclRetriever = $aclRetriever;
        $this->_order = $order;

    }

    public function isSuperadmin(){
        $superadmin = false;

        $user = $this->authSession->getUser();
        $role = $user->getRole();
        $resources = $this->_aclRetriever->getAllowedResourcesByRole($role->getId());
        
        if(count($resources == 1) && $resources[0] == 'Magento_Backend::all'){
            $superadmin = true;
        }else{
            $superadmin = false;
        }
        return $superadmin;
    }

    public function getCompanyColl()
    { 
        $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();
		$sqlSelect = $this->_resource->getConnection()->select();
        $comparr = $this->getCompanybySalesrepresentative();
        
        if($this->isSuperadmin()){
            $sqlSelect->from($this->_resource->getTableName('company_order_entity'), ['order_id']);
        }else{
            $sqlSelect->from($this->_resource->getTableName('company_order_entity'), ['order_id'])
                ->where('company_id IN (?)', $comparr);
        }

        $resourceArr = $this->_resource->getConnection()->fetchcol($sqlSelect);

        $companytotal = 0.00;
        $ordtotal     = 0.00;
        
        if(count($resourceArr) > 0){
        	foreach ($resourceArr as $key => $ordid) {
                $orderData = $this->_order->load($ordid);
                $ordtotal = $orderData->getGrandTotal();
			    $companytotal = number_format($companytotal,2)  + number_format($ordtotal,2);   
        	}
        }
        
        return $this->_pricehelper->currency($companytotal,true,false);
    }

    public function getAvailablebalance()
    { 
      
		$sqlSelect = $this->_resource->getConnection()->select();
        $comparr = $this->getCompanybySalesrepresentative();

        if($this->isSuperadmin()){
            $sqlSelect->from($this->_resource->getTableName('company_credit'), ['balance']);
        }else{
            $sqlSelect->from($this->_resource->getTableName('company_credit'), ['balance'])
                ->where('company_id IN (?)', $comparr);
        }
        

        $resourceArr = $this->_resource->getConnection()->fetchcol($sqlSelect);

        $baltotal = (float) 0.0000;

        if(count($resourceArr) >1){
            foreach ($resourceArr as $key => $avlbal) {
                $baltotal = (float) $baltotal + (float) $avlbal;
            }
            $baltotal = $this->_pricehelper->currency($baltotal,true,false);
            return $baltotal;
        }else if($resourceArr[0] == '') {
            $retval = $this->_pricehelper->currency(number_format(0,2),true,false);
            return $retval;
        }else{
            $retval = $resourceArr[0];
            $retval = $this->_pricehelper->currency($retval,true,false);
            return $retval;
        }
    }

    public function getAvailablecredit()
    { 
      
        $sqlSelect = $this->_resource->getConnection()->select();
        $comparr = $this->getCompanybySalesrepresentative();

        if($this->isSuperadmin()){
            $sqlSelect->from($this->_resource->getTableName('company_credit'), ['credit_limit']);
        }else{
            $sqlSelect->from($this->_resource->getTableName('company_credit'), ['credit_limit'])
                ->where('company_id IN (?)', $comparr);
        }

        $resourceArr = $this->_resource->getConnection()->fetchcol($sqlSelect);
        $credittotal = (float) 0.0000;

        if(count($resourceArr) >1){
            foreach ($resourceArr as $key => $creditlimit) {
                $credittotal = (float) $credittotal + (float) $creditlimit;
            }
            $credittotal = $this->_pricehelper->currency($credittotal,true,false);
            return $credittotal;
        }else if($resourceArr[0] == '') {
            $retval = $this->_pricehelper->currency(number_format(0,2),true,false);
            return $retval;
        }else{
             $retval = $resourceArr[0];
             $retval = $this->_pricehelper->currency($retval,true,false);
            return $retval;
        }
    }

    public function getCompanybySalesrepresentative()
    { 
      
        $sqlSelect = $this->_resource->getConnection()->select();
        $sqlSelect->from($this->_resource->getTableName('company'), ['entity_id'])
                ->where('sales_representative_id IN (?)', $this->authSession->getUser()->getId());

        $resourceArr = $this->_resource->getConnection()->fetchcol($sqlSelect);
        return $resourceArr;

        
    }

    public function getCurrencycode()
    {
        $sqlSelect = $this->_resource->getConnection()->select();
        $comparr = $this->getCompanybySalesrepresentative();
        $sqlSelect->from($this->_resource->getTableName('company_credit'), ['currency_code'])
                ->where('company_id IN (?)', $comparr);
        $resourceArr = $this->_resource->getConnection()->fetchcol($sqlSelect);
            return $resourceArr[0];
    }
}
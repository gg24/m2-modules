<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Source;

class Udcustomerrecord implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * UD Customer Record repository
     *
     * @var \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface
     */
    protected $udcustomerrecordRepository;

    /**
     * Search Criteria Builder
     *
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * Filter Builder
     *
     * @var \Magento\Framework\Api\FilterBuilder
     */
    protected $filterBuilder;

    /**
     * Options
     *
     * @var array
     */
    protected $options;

    /**
     * constructor
     *
     * @param \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface $udcustomerrecordRepository
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
     * @param \Magento\Framework\Api\FilterBuilder $filterBuilder
     */
    public function __construct(
        \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface $udcustomerrecordRepository,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Api\FilterBuilder $filterBuilder
    ) {
    
        $this->udcustomerrecordRepository = $udcustomerrecordRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
    }

    /**
     * Retrieve all UD Customer Records as an option array
     *
     * @return array
     * @throws StateException
     */
    public function getAllOptions()
    {
        if (empty($this->options)) {
            $options = [];
            $searchCriteria = $this->searchCriteriaBuilder->create();
            $searchResults = $this->udcustomerrecordRepository->getList($searchCriteria);
            foreach ($searchResults->getItems() as $udcustomerrecord) {
                $options[] = [
                    'value' => $udcustomerrecord->getUdcustomerrecordId(),
                    'label' => $udcustomerrecord->getCustomer_id(),
                ];
            }
            $this->options = $options;
        }

        return $this->options;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return $this->getAllOptions();
    }
}

<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Source;

class Precartrecord implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Pre Cart Record repository
     *
     * @var \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface
     */
    protected $precartrecordRepository;

    /**
     * Search Criteria Builder
     *
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * Filter Builder
     *
     * @var \Magento\Framework\Api\FilterBuilder
     */
    protected $filterBuilder;

    /**
     * Options
     *
     * @var array
     */
    protected $options;

    /**
     * constructor
     *
     * @param \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
     * @param \Magento\Framework\Api\FilterBuilder $filterBuilder
     */
    public function __construct(
        \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Api\FilterBuilder $filterBuilder
    ) {
        $this->precartrecordRepository = $precartrecordRepository;
        $this->searchCriteriaBuilder   = $searchCriteriaBuilder;
        $this->filterBuilder           = $filterBuilder;
    }

    /**
     * Retrieve all Pre Cart Record as an option array
     *
     * @return array
     * @throws StateException
     */
    public function getAllOptions()
    {
        if (empty($this->options)) {
            $options = [];
            $searchCriteria = $this->searchCriteriaBuilder->create();
            $searchResults = $this->precartrecordRepository->getList($searchCriteria);
            foreach ($searchResults->getItems() as $precartrecord) {
                $options[] = [
                    'value' => $precartrecord->getPrecartrecordId(),
                    'label' => $precartrecord->getUser_id(),
                ];
            }
            $this->options = $options;
        }

        return $this->options;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return $this->getAllOptions();
    }
}

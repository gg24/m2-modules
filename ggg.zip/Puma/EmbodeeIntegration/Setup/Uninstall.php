<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Setup;

class Uninstall implements \Magento\Framework\Setup\UninstallInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.Generic.CodeAnalysis.UnusedFunctionParameter)
     */
    public function uninstall(
        \Magento\Framework\Setup\SchemaSetupInterface $setup,
        \Magento\Framework\Setup\ModuleContextInterface $context
    ) {
    
        if ($setup->tableExists('puma_embodeeintegration_udcustomerrecord')) {
            $setup->getConnection()->dropTable('puma_embodeeintegration_udcustomerrecord');
        }
        if ($setup->tableExists('puma_embodeeintegration_precartrecord')) {
            $setup->getConnection()->dropTable('puma_embodeeintegration_precartrecord');
        }
    }
}

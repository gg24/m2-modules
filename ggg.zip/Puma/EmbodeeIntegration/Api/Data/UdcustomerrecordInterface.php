<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Api\Data;

/**
 * @api
 */
interface UdcustomerrecordInterface
{
    /**
     * ID
     *
     * @var string
     */
    const UDCUSTOMERRECORD_ID = 'udcustomerrecord_id';

    /**
     * Customer Id attribute constant
     *
     * @var string
     */
    const CUSTOMER_ID = 'customer_id';

    /**
     * User Design Id attribute constant
     *
     * @var string
     */
    const UD_ID = 'ud_id';

    /**
     * Product Code attribute constant
     *
     * @var string
     */
    const PRODUCT_CODE = 'product_code';

    /**
     * Extra Field 1 attribute constant
     *
     * @var string
     */
    const EXTRA_FIELD_ONE = 'extra_field_one';

    /**
     * Extra Field 2 attribute constant
     *
     * @var string
     */
    const EXTRA_FIELD_TWO = 'extra_field_two';

    /**
     * Extra Field 3 attribute constant
     *
     * @var string
     */
    const EXTRA_FIELD_THREE = 'extra_field_three';

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getUdcustomerrecordId();

    /**
     * Set ID
     *
     * @param int $udcustomerrecordId
     * @return UdcustomerrecordInterface
     */
    public function setUdcustomerrecordId($udcustomerrecordId);

    /**
     * Get Customer Id
     *
     * @return mixed
     */
    public function getCustomerId();

    /**
     * Set Customer Id
     *
     * @param mixed $customerId
     * @return UdcustomerrecordInterface
     */
    public function setCustomerId($customerId);

    /**
     * Get User Design Id
     *
     * @return mixed
     */
    public function getUdId();

    /**
     * Set User Design Id
     *
     * @param mixed $udId
     * @return UdcustomerrecordInterface
     */
    public function setUdId($udId);

    /**
     * Get Product Code
     *
     * @return mixed
     */
    public function getProductCode();

    /**
     * Set Product Code
     *
     * @param mixed $productCode
     * @return UdcustomerrecordInterface
     */
    public function setProductCode($productCode);

    /**
     * Get Extra Field 1
     *
     * @return mixed
     */
    public function getExtraFieldOne();

    /**
     * Set Extra Field 1
     *
     * @param mixed $extraFieldOne
     * @return UdcustomerrecordInterface
     */
    public function setExtraFieldOne($extraFieldOne);

    /**
     * Get Extra Field 2
     *
     * @return mixed
     */
    public function getExtraFieldTwo();

    /**
     * Set Extra Field 2
     *
     * @param mixed $extraFieldTwo
     * @return UdcustomerrecordInterface
     */
    public function setExtraFieldTwo($extraFieldTwo);

    /**
     * Get Extra Field 3
     *
     * @return mixed
     */
    public function getExtraFieldThree();

    /**
     * Set Extra Field 3
     *
     * @param mixed $extraFieldThree
     * @return UdcustomerrecordInterface
     */
    public function setExtraFieldThree($extraFieldThree);
}

<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Api\Data;

/**
 * @api
 */
interface UdcustomerrecordSearchResultInterface
{
    /**
     * Get UD Customer Records list.
     *
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface[]
     */
    public function getItems();

    /**
     * Set UD Customer Records list.
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

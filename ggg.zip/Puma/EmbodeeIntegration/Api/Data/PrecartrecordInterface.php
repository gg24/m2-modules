<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Api\Data;

/**
 * @api
 */
interface PrecartrecordInterface
{
    /**
     * ID
     *
     * @var string
     */
    const PRECARTRECORD_ID = 'precartrecord_id';

    /**
     * User Id attribute constant
     *
     * @var string
     */
    const USER_ID = 'user_id';

    /**
     * Sku attribute constant
     *
     * @var string
     */
    const SKU = 'sku';

    /**
     * Udname attribute constant
     *
     * @var string
     */
    const UD_NAME = 'ud_name';

    /**
     * UD Id attribute constant
     *
     * @var string
     */
    const UD_ID = 'ud_id';

    /**
     * Ud Image attribute constant
     *
     * @var string
     */
    const UD_IMAGE = 'ud_image';

    /**
     * Data One attribute constant
     *
     * @var string
     */
    const DATA_ONE = 'data_one';

    /**
     * Data Two attribute constant
     *
     * @var string
     */
    const DATA_TWO = 'data_two';

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getPrecartrecordId();

    /**
     * Set ID
     *
     * @param int $precartrecordId
     * @return PrecartrecordInterface
     */
    public function setPrecartrecordId($precartrecordId);

    /**
     * Get User Id
     *
     * @return mixed
     */
    public function getUserId();

    /**
     * Set User Id
     *
     * @param mixed $userId
     * @return PrecartrecordInterface
     */
    public function setUserId($userId);

    /**
     * Get Sku
     *
     * @return mixed
     */
    public function getSku();

    /**
     * Set Sku
     *
     * @param mixed $sku
     * @return PrecartrecordInterface
     */
    public function setSku($sku);

    /**
     * Get Udname
     *
     * @return mixed
     */
    public function getUdName();

    /**
     * Set Udname
     *
     * @param mixed $udName
     * @return PrecartrecordInterface
     */
    public function setUdName($udName);

    /**
     * Get UD Id
     *
     * @return mixed
     */
    public function getUdId();

    /**
     * Set UD Id
     *
     * @param mixed $udId
     * @return PrecartrecordInterface
     */
    public function setUdId($udId);

    /**
     * Get Ud Image
     *
     * @return mixed
     */
    public function getUdImage();

    /**
     * Set Ud Image
     *
     * @param mixed $udImage
     * @return PrecartrecordInterface
     */
    public function setUdImage($udImage);

    /**
     * Get Data One
     *
     * @return mixed
     */
    public function getDataOne();

    /**
     * Set Data One
     *
     * @param mixed $dataOne
     * @return PrecartrecordInterface
     */
    public function setDataOne($dataOne);

    /**
     * Get Data Two
     *
     * @return mixed
     */
    public function getDataTwo();

    /**
     * Set Data Two
     *
     * @param mixed $dataTwo
     * @return PrecartrecordInterface
     */
    public function setDataTwo($dataTwo);
}

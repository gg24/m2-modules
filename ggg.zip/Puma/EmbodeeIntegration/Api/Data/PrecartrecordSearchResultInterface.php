<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Api\Data;

/**
 * @api
 */
interface PrecartrecordSearchResultInterface
{
    /**
     * Get Pre Cart Record list.
     *
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface[]
     */
    public function getItems();

    /**
     * Set Pre Cart Record list.
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

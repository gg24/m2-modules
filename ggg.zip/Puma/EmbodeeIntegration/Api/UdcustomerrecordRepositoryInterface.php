<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Api;

/**
 * @api
 */
interface UdcustomerrecordRepositoryInterface
{
    /**
     * Save UD Customer Record.
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord);

    /**
     * Retrieve UD Customer Record
     *
     * @param int $udcustomerrecordId
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($udcustomerrecordId);

    /**
     * Retrieve UD Customer Records matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordSearchResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    /**
     * Delete UD Customer Record.
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord);

    /**
     * Delete UD Customer Record by ID.
     *
     * @param int $udcustomerrecordId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($udcustomerrecordId);
}

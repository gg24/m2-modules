<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Api;

/**
 * @api
 */
interface PrecartrecordRepositoryInterface
{
    /**
     * Save Pre Cart Record.
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord);

    /**
     * Retrieve Pre Cart Record
     *
     * @param int $precartrecordId
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($precartrecordId);

    /**
     * Retrieve Pre Cart Record matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordSearchResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    /**
     * Delete Pre Cart Record.
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord);

    /**
     * Delete Pre Cart Record by ID.
     *
     * @param int $precartrecordId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($precartrecordId);
}

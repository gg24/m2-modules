<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Model\Udcustomerrecord;

class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * Loaded data cache
     *
     * @var array
     */
    protected $loadedData;

    /**
     * Data persistor
     *
     * @var \Magento\Framework\App\Request\DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * constructor
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord\CollectionFactory $collectionFactory
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord\CollectionFactory $collectionFactory,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    ) {
    
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        /** @var \Puma\EmbodeeIntegration\Model\Udcustomerrecord $udcustomerrecord */
        foreach ($items as $udcustomerrecord) {
            $this->loadedData[$udcustomerrecord->getId()] = $udcustomerrecord->getData();
        }
        $data = $this->dataPersistor->get('puma_embodeeintegration_udcustomerrecord');
        if (!empty($data)) {
            $udcustomerrecord = $this->collection->getNewEmptyItem();
            $udcustomerrecord->setData($data);
            $this->loadedData[$udcustomerrecord->getId()] = $udcustomerrecord->getData();
            $this->dataPersistor->clear('puma_embodeeintegration_udcustomerrecord');
        }
        return $this->loadedData;
    }
}

<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Model;

class PrecartrecordRepository implements \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface
{
    /**
     * Cached instances
     *
     * @var array
     */
    protected $instances = [];

    /**
     * Pre Cart Record resource model
     *
     * @var \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord
     */
    protected $resource;

    /**
     * Pre Cart Record collection factory
     *
     * @var \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\CollectionFactory
     */
    protected $precartrecordCollectionFactory;

    /**
     * Pre Cart Record interface factory
     *
     * @var \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterfaceFactory
     */
    protected $precartrecordInterfaceFactory;

    /**
     * Data Object Helper
     *
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * Search result factory
     *
     * @var \Puma\EmbodeeIntegration\Api\Data\PrecartrecordSearchResultInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * constructor
     *
     * @param \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord $resource
     * @param \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\CollectionFactory $precartrecordCollectionFactory
     * @param \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterfaceFactory $precartrecordInterfaceFactory
     * @param \Magento\Framework\Api\DataObjectHelper $dataObjectHelper
     * @param \Puma\EmbodeeIntegration\Api\Data\PrecartrecordSearchResultInterfaceFactory $searchResultsFactory
     */
    public function __construct(
        \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord $resource,
        \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\CollectionFactory $precartrecordCollectionFactory,
        \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterfaceFactory $precartrecordInterfaceFactory,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        \Puma\EmbodeeIntegration\Api\Data\PrecartrecordSearchResultInterfaceFactory $searchResultsFactory
    ) {
        $this->resource                       = $resource;
        $this->precartrecordCollectionFactory = $precartrecordCollectionFactory;
        $this->precartrecordInterfaceFactory  = $precartrecordInterfaceFactory;
        $this->dataObjectHelper               = $dataObjectHelper;
        $this->searchResultsFactory           = $searchResultsFactory;
    }

    /**
     * Save Pre Cart Record.
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord)
    {
        /** @var \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface|\Magento\Framework\Model\AbstractModel $precartrecord */
        try {
            $this->resource->save($precartrecord);
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\CouldNotSaveException(__(
                'Could not save the Pre&#x20;Cart&#x20;Record: %1',
                $exception->getMessage()
            ));
        }
        return $precartrecord;
    }

    /**
     * Retrieve Pre Cart Record.
     *
     * @param int $precartrecordId
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($precartrecordId)
    {
        if (!isset($this->instances[$precartrecordId])) {
            /** @var \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface|\Magento\Framework\Model\AbstractModel $precartrecord */
            $precartrecord = $this->precartrecordInterfaceFactory->create();
            $this->resource->load($precartrecord, $precartrecordId);
            if (!$precartrecord->getId()) {
                throw new \Magento\Framework\Exception\NoSuchEntityException(__('Requested Pre&#x20;Cart&#x20;Record doesn\'t exist'));
            }
            $this->instances[$precartrecordId] = $precartrecord;
        }
        return $this->instances[$precartrecordId];
    }

    /**
     * Retrieve Pre Cart Record matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordSearchResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        /** @var \Puma\EmbodeeIntegration\Api\Data\PrecartrecordSearchResultInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);

        /** @var \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\Collection $collection */
        $collection = $this->precartrecordCollectionFactory->create();

        //Add filters from root filter group to the collection
        /** @var \Magento\Framework\Api\Search\FilterGroup $group */
        foreach ($searchCriteria->getFilterGroups() as $group) {
            $this->addFilterGroupToCollection($group, $collection);
        }
        $sortOrders = $searchCriteria->getSortOrders();
        /** @var \Magento\Framework\Api\SortOrder $sortOrder */
        if ($sortOrders) {
            foreach ($searchCriteria->getSortOrders() as $sortOrder) {
                $field = $sortOrder->getField();
                $collection->addOrder(
                    $field,
                    ($sortOrder->getDirection() == \Magento\Framework\Api\SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        } else {
            // set a default sorting order since this method is used constantly in many
            // different blocks
            $field = 'precartrecord_id';
            $collection->addOrder($field, 'ASC');
        }
        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());

        /** @var \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface[] $precartrecords */
        $precartrecords = [];
        /** @var \Puma\EmbodeeIntegration\Model\Precartrecord $precartrecord */
        foreach ($collection as $precartrecord) {
            /** @var \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecordDataObject */
            $precartrecordDataObject = $this->precartrecordInterfaceFactory->create();
            $this->dataObjectHelper->populateWithArray(
                $precartrecordDataObject,
                $precartrecord->getData(),
                \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::class
            );
            $precartrecords[] = $precartrecordDataObject;
        }
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults->setItems($precartrecords);
    }

    /**
     * Delete Pre Cart Record.
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord)
    {
        /** @var \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface|\Magento\Framework\Model\AbstractModel $precartrecord */
        $id = $precartrecord->getId();
        try {
            unset($this->instances[$id]);
            $this->resource->delete($precartrecord);
        } catch (\Magento\Framework\Exception\ValidatorException $e) {
            throw new \Magento\Framework\Exception\CouldNotSaveException(__($e->getMessage()));
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\StateException(
                __('Unable to remove Pre&#x20;Cart&#x20;Record %1', $id)
            );
        }
        unset($this->instances[$id]);
        return true;
    }

    /**
     * Delete Pre Cart Record by ID.
     *
     * @param int $precartrecordId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($precartrecordId)
    {
        $precartrecord = $this->getById($precartrecordId);
        return $this->delete($precartrecord);
    }

    /**
     * Helper function that adds a FilterGroup to the collection.
     *
     * @param \Magento\Framework\Api\Search\FilterGroup $filterGroup
     * @param \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\Collection $collection
     * @return $this
     * @throws \Magento\Framework\Exception\InputException
     */
    protected function addFilterGroupToCollection(
        \Magento\Framework\Api\Search\FilterGroup $filterGroup,
        \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\Collection $collection
    ) {
        $fields = [];
        $conditions = [];
        foreach ($filterGroup->getFilters() as $filter) {
            $condition = $filter->getConditionType() ? $filter->getConditionType() : 'eq';
            $fields[] = $filter->getField();
            $conditions[] = [$condition => $filter->getValue()];
        }
        if ($fields) {
            $collection->addFieldToFilter($fields, $conditions);
        }
        return $this;
    }
}

<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Model;

/**
 * @method \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord _getResource()
 * @method \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord getResource()
 */
class Precartrecord extends \Magento\Framework\Model\AbstractModel implements \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
{
    /**
     * Cache tag
     *
     * @var string
     */
    const CACHE_TAG = 'puma_embodeeintegration_precartrecord';

    /**
     * Cache tag
     *
     * @var string
     */
    protected $_cacheTag = self::CACHE_TAG;

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'puma_embodeeintegration_precartrecord';

    /**
     * Event object
     *
     * @var string
     */
    protected $_eventObject = 'precartrecord';

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord::class);
    }

    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Get Pre Cart Record id
     *
     * @return array
     */
    public function getPrecartrecordId()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::PRECARTRECORD_ID);
    }

    /**
     * set Pre Cart Record id
     *
     * @param int $precartrecordId
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     */
    public function setPrecartrecordId($precartrecordId)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::PRECARTRECORD_ID, $precartrecordId);
    }

    /**
     * set User Id
     *
     * @param mixed $userId
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     */
    public function setUserId($userId)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::USER_ID, $userId);
    }

    /**
     * get User Id
     *
     * @return string
     */
    public function getUserId()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::USER_ID);
    }

    /**
     * set Sku
     *
     * @param mixed $sku
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     */
    public function setSku($sku)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::SKU, $sku);
    }

    /**
     * get Sku
     *
     * @return string
     */
    public function getSku()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::SKU);
    }

    /**
     * set Udname
     *
     * @param mixed $udName
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     */
    public function setUdName($udName)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::UD_NAME, $udName);
    }

    /**
     * get Udname
     *
     * @return string
     */
    public function getUdName()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::UD_NAME);
    }

    /**
     * set UD Id
     *
     * @param mixed $udId
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     */
    public function setUdId($udId)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::UD_ID, $udId);
    }

    /**
     * get UD Id
     *
     * @return string
     */
    public function getUdId()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::UD_ID);
    }

    /**
     * set Ud Image
     *
     * @param mixed $udImage
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     */
    public function setUdImage($udImage)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::UD_IMAGE, $udImage);
    }

    /**
     * get Ud Image
     *
     * @return string
     */
    public function getUdImage()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::UD_IMAGE);
    }

    /**
     * set Data One
     *
     * @param mixed $dataOne
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     */
    public function setDataOne($dataOne)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::DATA_ONE, $dataOne);
    }

    /**
     * get Data One
     *
     * @return string
     */
    public function getDataOne()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::DATA_ONE);
    }

    /**
     * set Data Two
     *
     * @param mixed $dataTwo
     * @return \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface
     */
    public function setDataTwo($dataTwo)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::DATA_TWO, $dataTwo);
    }

    /**
     * get Data Two
     *
     * @return string
     */
    public function getDataTwo()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::DATA_TWO);
    }
}

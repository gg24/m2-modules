<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Model;

class UdcustomerrecordRepository implements \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface
{
    /**
     * Cached instances
     *
     * @var array
     */
    protected $instances = [];

    /**
     * UD Customer Record resource model
     *
     * @var \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord
     */
    protected $resource;

    /**
     * UD Customer Record collection factory
     *
     * @var \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord\CollectionFactory
     */
    protected $udcustomerrecordCollectionFactory;

    /**
     * UD Customer Record interface factory
     *
     * @var \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterfaceFactory
     */
    protected $udcustomerrecordInterfaceFactory;

    /**
     * Data Object Helper
     *
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * Search result factory
     *
     * @var \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordSearchResultInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * constructor
     *
     * @param \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord $resource
     * @param \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord\CollectionFactory $udcustomerrecordCollectionFactory
     * @param \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterfaceFactory $udcustomerrecordInterfaceFactory
     * @param \Magento\Framework\Api\DataObjectHelper $dataObjectHelper
     * @param \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordSearchResultInterfaceFactory $searchResultsFactory
     */
    public function __construct(
        \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord $resource,
        \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord\CollectionFactory $udcustomerrecordCollectionFactory,
        \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterfaceFactory $udcustomerrecordInterfaceFactory,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordSearchResultInterfaceFactory $searchResultsFactory
    ) {
    
        $this->resource = $resource;
        $this->udcustomerrecordCollectionFactory = $udcustomerrecordCollectionFactory;
        $this->udcustomerrecordInterfaceFactory = $udcustomerrecordInterfaceFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->searchResultsFactory = $searchResultsFactory;
    }

    /**
     * Save UD Customer Record.
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord)
    {
        /** @var \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface|\Magento\Framework\Model\AbstractModel $udcustomerrecord */
        try {
            $this->resource->save($udcustomerrecord);
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\CouldNotSaveException(__(
                'Could not save the UD&#x20;Customer&#x20;Record: %1',
                $exception->getMessage()
            ));
        }
        return $udcustomerrecord;
    }

    /**
     * Retrieve UD Customer Record.
     *
     * @param int $udcustomerrecordId
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($udcustomerrecordId)
    {
        if (!isset($this->instances[$udcustomerrecordId])) {
            /** @var \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface|\Magento\Framework\Model\AbstractModel $udcustomerrecord */
            $udcustomerrecord = $this->udcustomerrecordInterfaceFactory->create();
            $this->resource->load($udcustomerrecord, $udcustomerrecordId);
            if (!$udcustomerrecord->getId()) {
                throw new \Magento\Framework\Exception\NoSuchEntityException(__('Requested UD&#x20;Customer&#x20;Record doesn\'t exist'));
            }
            $this->instances[$udcustomerrecordId] = $udcustomerrecord;
        }
        return $this->instances[$udcustomerrecordId];
    }

    /**
     * Retrieve UD Customer Records matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordSearchResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        /** @var \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordSearchResultInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);

        /** @var \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord\Collection $collection */
        $collection = $this->udcustomerrecordCollectionFactory->create();

        //Add filters from root filter group to the collection
        /** @var \Magento\Framework\Api\Search\FilterGroup $group */
        foreach ($searchCriteria->getFilterGroups() as $group) {
            $this->addFilterGroupToCollection($group, $collection);
        }
        $sortOrders = $searchCriteria->getSortOrders();
        /** @var \Magento\Framework\Api\SortOrder $sortOrder */
        if ($sortOrders) {
            foreach ($searchCriteria->getSortOrders() as $sortOrder) {
                $field = $sortOrder->getField();
                $collection->addOrder(
                    $field,
                    ($sortOrder->getDirection() == \Magento\Framework\Api\SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        } else {
            // set a default sorting order since this method is used constantly in many
            // different blocks
            $field = 'udcustomerrecord_id';
            $collection->addOrder($field, 'ASC');
        }
        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());

        /** @var \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface[] $udcustomerrecords */
        $udcustomerrecords = [];
        /** @var \Puma\EmbodeeIntegration\Model\Udcustomerrecord $udcustomerrecord */
        foreach ($collection as $udcustomerrecord) {
            /** @var \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecordDataObject */
            $udcustomerrecordDataObject = $this->udcustomerrecordInterfaceFactory->create();
            $this->dataObjectHelper->populateWithArray(
                $udcustomerrecordDataObject,
                $udcustomerrecord->getData(),
                \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::class
            );
            $udcustomerrecords[] = $udcustomerrecordDataObject;
        }
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults->setItems($udcustomerrecords);
    }

    /**
     * Delete UD Customer Record.
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord)
    {
        /** @var \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface|\Magento\Framework\Model\AbstractModel $udcustomerrecord */
        $id = $udcustomerrecord->getId();
        try {
            unset($this->instances[$id]);
            $this->resource->delete($udcustomerrecord);
        } catch (\Magento\Framework\Exception\ValidatorException $e) {
            throw new \Magento\Framework\Exception\CouldNotSaveException(__($e->getMessage()));
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\StateException(
                __('Unable to remove UD&#x20;Customer&#x20;Record %1', $id)
            );
        }
        unset($this->instances[$id]);
        return true;
    }

    /**
     * Delete UD Customer Record by ID.
     *
     * @param int $udcustomerrecordId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($udcustomerrecordId)
    {
        $udcustomerrecord = $this->getById($udcustomerrecordId);
        return $this->delete($udcustomerrecord);
    }

    /**
     * Helper function that adds a FilterGroup to the collection.
     *
     * @param \Magento\Framework\Api\Search\FilterGroup $filterGroup
     * @param \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord\Collection $collection
     * @return $this
     * @throws \Magento\Framework\Exception\InputException
     */
    protected function addFilterGroupToCollection(
        \Magento\Framework\Api\Search\FilterGroup $filterGroup,
        \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord\Collection $collection
    ) {
    
        $fields = [];
        $conditions = [];
        foreach ($filterGroup->getFilters() as $filter) {
            $condition = $filter->getConditionType() ? $filter->getConditionType() : 'eq';
            $fields[] = $filter->getField();
            $conditions[] = [$condition => $filter->getValue()];
        }
        if ($fields) {
            $collection->addFieldToFilter($fields, $conditions);
        }
        return $this;
    }
}

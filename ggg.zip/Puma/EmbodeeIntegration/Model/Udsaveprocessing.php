<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Model;

use Magento\Setup\Exception;
use Puma\EmbodeeIntegration\Model\UdcustomerrecordFactory;
use Puma\EmbodeeIntegration\Model\PrecartrecordFactory;
use Magento\Catalog\Model\ProductRepository;
use Magento\Checkout\Model\Cart;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\Json\Helper\Data;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Puma\EmbodeeIntegration\Helper\Data as Embodata;

class Udsaveprocessing
{
    /**
     * @var udcustomerrecordFactory
     */
    protected $udcustomerrecordFactory;

    /**
     * @var precartrecordFactory
     */
    protected $precartrecordFactory;
    
    /**
     * @var Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;

    /**
     * Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var $jsonHelper
     */
    protected $jsonHelper;

    /**
     * @var helperdata
     */
    protected $helperdata;

    /**
     * @var $embourl
     */
    protected $embourl;
    /**
     * @var $udtype
     */
    protected $udtype;

    /**
     * @var $udheight
     */
    protected $udheight;

    /**
     * @var $udwidth
     */
    protected $udwidth;

    /**
     * @var $udformat
     */
    protected $udformat;

    /**
     * @var $udframe
     */
    protected $udframe;

    /**
     * @var $udtypetwo
     */
    protected $udtypetwo;
    
    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;
    
    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;

    /**
     * constructor.
     *
     * @param Context $context
     * @param JsonHelper $jsonHelper
     * @param JsonFactory $jsonFactory
     * @param FormKey $formKey
     * @param Cart $cart
     * @param ProductRepository $productRepository
     * @param UdcustomerrecordFactory $udcustomerrecordFactory
     * @param PrecartrecordFactory $precartrecordFactory
     */
    public function __construct(
        UdcustomerrecordFactory $udcustomerrecordFactory,
        PrecartrecordFactory $precartrecordFactory,
        FormKey $formKey,
        Cart $cart,
        ProductRepository $productRepository,
        Data $jsonHelper,
        \Puma\EmbodeeIntegration\Helper\Data $helperdata,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        Embodata $embodeeintegrationhelper
    ) {
    
        $this->udcustomerrecordFactory = $udcustomerrecordFactory;
        $this->precartrecordFactory = $precartrecordFactory;
        $this->formKey = $formKey;
        $this->cart = $cart;
        $this->productRepository = $productRepository;
        $this->jsonHelper = $jsonHelper;
        $this->helperdata = $helperdata;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->embourl = $this->helperdata->getGeneralConfig('embourl');
        $this->udtype = $this->helperdata->getGeneralConfig('udtype');
        $this->udheight = $this->helperdata->getGeneralConfig('udheight');
        $this->udwidth = $this->helperdata->getGeneralConfig('udwidth');
        $this->udformat = $this->helperdata->getGeneralConfig('udformat');
        $this->udframe = $this->helperdata->getGeneralConfig('udframe');
        $this->udtypetwo = $this->helperdata->getGeneralConfig('udtypetwo');
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
    }


    public function SaveudToMagento($data)
    {
        if ($this->helperdata->isLoggedIn()) {
            $imageurl = $this->getUdImageUrl($data);
            $item = $this->udcustomerrecordFactory->create();
            $item->setCustomerId($this->helperdata->getCustomerId());
            $item->setUdId($data['ud_id']);
            $item->setProductCode($data['product_code']);
            $item->setExtraFieldOne($data['name']);
            $item->setExtraFieldTwo($imageurl);
            $item->setExtraFieldThree($data['product_url'] . '?ud=' . $data['ud_id']);
            try {
                $item->save();
                return 'success';
            } catch (Exception $e) {
                $this->embodeeintegrationhelper->logtofile('Message: ' . $e->getMessage());
                return 'error';
            }
        } else {
            return 'temp';
        }
    }
    
    public function getUdImageUrl($data)
    {
            return '//'. $this->embourl . '/builder/ud/image/' . $data['ud_id'] . '/' . $this->udtype . '/' . $this->udheight . ',' . $this->udwidth . ',' . $this->udformat . ',' . $this->udframe . ',' . $this->udtypetwo;
    }
    
    public function AddToCartMagento($data)
    {
        if ($this->helperdata->isLoggedIn()) {
        //$this->SaveudToMagento($data);
            $skus = $this->getProductSkus($data);
            $this->embodeeintegrationhelper->logtofile($skus);
            if (empty($skus)) {
                   return "No Sku retrun from factory service";
            }
            foreach ($skus as $sku) {
                $sku = $this->searchProductSkuOnEmboCode($sku);
                $imageurl = $this->getUdImageUrl($data);
                $item = $this->precartrecordFactory->create();
                $item->setUserId($this->helperdata->getCustomerId());
                $item->setSku($sku);
                $item->setUdName($data['name']);
                $item->setUdId($data['ud_id']);
                $item->setUdImage($imageurl);
                try {
                    $item->save();
                } catch (Exception $e) {
                    $this->embodeeintegrationhelper->logtofile('Message: ' . $e->getMessage());
                    return 'error';
                }
            }
            return 'success';
        } else {
            return 'temp';
        }
    }

    /**
     * @param $data
     * @return array|string
     */
    public function getProductSkus($data)
    {
        $url = $this->embourl.'/services/details/'.$data['ud_id'];
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        try {
            $data = curl_exec($ch);
        } catch (Exception $e) {
            $this->embodeeintegrationhelper->logtofile('Message: ' . $e->getMessage());
            return 'error';
        }
        curl_close($ch);
        $data = $this->jsonHelper->jsonDecode($data);
        //$this->embodeeintegrationhelper->logtofile($data);
        $data = $data['result']['styles'];
        foreach ($data as $key => $value) {
            if($value['meta']['bagselected'] == 1 ) {
                $skus[] = $key;
            }
        }
        return $skus;
    }


    public function getProductInfo($data)
    {
        $result = $this->productRepository->get($data['product_code']);
        $data = ['product_name'=>$result->getName(),'product_description'=>$result->getDescription()];
        return $data;
    }
    
    public function getPriceBreakDown($data)
    {
        $result = $this->productRepository->get($data['product_code']);
        $data = [
            [
                "errorcode"   => 0,

            ],
            [
                "display_name"   => $result->getName(),
                "display_price" => $result->getFinalPrice()
            ]
        ];
        return $data;
    }

    public function searchProductSkuOnEmboCode($sku)
    {
        $searchCriteria = $this->searchCriteriaBuilder->addFilter(
            'embodee_garment_product_code',
            $sku,
            'eq'
        )->create();
        $result = $this->productRepository->getList($searchCriteria);
        foreach ($result->getItems() as $value) {
            if ($value->getSku() && $value->getTypeId() == 'configurable') {
                return $value->getSku();
            } else {
                continue;
            }
        }
    }
}

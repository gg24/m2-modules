<?php

/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Model;

use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Translate\Inline\StateInterface;
use Puma\EmbodeeIntegration\Helper\Data;

class ShareEmail
{

    /**
     *
     * @var TransportBuilder
     */
    protected $_transportBuilder;

    /**
     *
     * @var StoreManagerInterface
     */
    protected $_storeManager;

    /**
     *
     * @var StateInterface
     */
    protected $_inlineTranslation;
    
    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;
    
    
    /**
     *
     * @param TransportBuilder $transportBuilder
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        TransportBuilder $transportBuilder,
        StoreManagerInterface $storeManager,
        StateInterface $inlineTranslation,
        Data $embodeeintegrationhelper
    ) {
        $this->_transportBuilder = $transportBuilder;
        $this->_storeManager = $storeManager;
        $this->_inlineTranslation = $inlineTranslation;
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
    }

    public function sendMail($data)
    {
        $shareemail = [
            'mailfrom' => $data['mailfrom'],
            'content' => $data['content']
        ];
        $this->embodeeintegrationhelper->logtofile($shareemail);
        $postObject = new \Magento\Framework\DataObject();
        $postObject->setData($shareemail);

        $transport = $this->_transportBuilder
                ->setTemplateIdentifier('embodee_share_template')
                ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->_storeManager->getStore()->getId()])
                ->setTemplateVars(['data' => $postObject])
                ->setFrom(['name' => 'Puma', 'email' => $data['mailfrom']])
                ->addTo([$data['mailto']])
                ->getTransport();
        try {
            //$this->embodeeintegrationhelper->logtofile($data);
            $transport->sendMessage();
            $this->_inlineTranslation->resume();
            return 'success';
        } catch (\Exception $e) {
            //$this->embodeeintegrationhelper->logtofile($data);
            return 'error';
        }
    }
}

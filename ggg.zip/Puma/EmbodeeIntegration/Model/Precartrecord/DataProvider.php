<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Model\Precartrecord;

class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * Loaded data cache
     *
     * @var array
     */
    protected $loadedData;

    /**
     * Data persistor
     *
     * @var \Magento\Framework\App\Request\DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * constructor
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\CollectionFactory $collectionFactory
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\CollectionFactory $collectionFactory,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    ) {
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        /** @var \Puma\EmbodeeIntegration\Model\Precartrecord $precartrecord */
        foreach ($items as $precartrecord) {
            $this->loadedData[$precartrecord->getId()] = $precartrecord->getData();
        }
        $data = $this->dataPersistor->get('puma_embodeeintegration_precartrecord');
        if (!empty($data)) {
            $precartrecord = $this->collection->getNewEmptyItem();
            $precartrecord->setData($data);
            $this->loadedData[$precartrecord->getId()] = $precartrecord->getData();
            $this->dataPersistor->clear('puma_embodeeintegration_precartrecord');
        }
        return $this->loadedData;
    }
}

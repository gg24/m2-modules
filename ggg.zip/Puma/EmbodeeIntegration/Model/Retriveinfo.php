<?php

/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Model;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Setup\Exception;
use Puma\EmbodeeIntegration\Model\UdcustomerrecordFactory;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\Json\Helper\Data;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Store\Model\StoreManagerInterface;
use Magento\ConfigurableProduct\Api\LinkManagementInterface;
use Magento\Catalog\Model\Product\Attribute\Repository;
use mpdf\mpdf;
use Puma\EmbodeeIntegration\Helper\Data as Embodata;

class Retriveinfo
{

    /**
     * @var udcustomerrecordFactory
     */
    protected $udcustomerrecordFactory;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var $jsonHelper
     */
    protected $jsonHelper;

    /**
     * @var helperdata
     */
    protected $helperdata;

    
    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     *
     * @var StoreManagerInterface
     */
    protected $_storeManager;
    
    /**
     * @var \Magento\Framework\View\Asset\Repository
     */
    protected $assetRepository;
        
    /**
     *
     * @var File
     */
    protected $_driverFile;

    /**
     * @var LinkManagementInterface
     */
    protected $linkManagement;

    /**
     * @var PriceHelperData
     */
    protected $_priceData;
    protected $_productAttributeRepository;


     /**
      * @var \Magento\Framework\HTTP\Client\Curl
      */
    protected $_curl;

    /**
     * @var Filesystem
     */
    protected $fileSystem;
    
    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;

    /**
     * constructor.
     *
     * @param Context $context
     * @param JsonHelper $jsonHelper
     * @param JsonFactory $jsonFactory
     * @param ProductRepository $productRepository
     * @param UdcustomerrecordFactory $udcustomerrecordFactory
     * @param StoreManagerInterface $storeManager
     * @param LinkManagementInterface $linkManagement
     * @param Repository $productAttributeRepository
     * @param Embodata $embodeeintegrationhelper
     */
    public function __construct(
        UdcustomerrecordFactory $udcustomerrecordFactory,
        ProductRepository $productRepository,
        Data $jsonHelper,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        StoreManagerInterface $storeManager,
        File $driverFile,
        LinkManagementInterface $linkManagement,
        \Magento\Framework\Pricing\Helper\Data $priceData,
        Repository $productAttribute,
        \Magento\Framework\View\Asset\Repository $assetRepository,
        \Puma\EmbodeeIntegration\Helper\Data $helperdata,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Magento\Framework\Filesystem $filesystem,
        Embodata $embodeeintegrationhelper
    ) {
        $this->udcustomerrecordFactory = $udcustomerrecordFactory;
        $this->productRepository = $productRepository;
        $this->jsonHelper = $jsonHelper;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->_storeManager = $storeManager;
        $this->driverFile = $driverFile;
        $this->_storeManager = $storeManager;
        $this->linkManagement = $linkManagement;
        $this->_priceData = $priceData;
        $this->_productAttributeRepository = $productAttribute;
        $this->assetRepository = $assetRepository;
        $this->helperdata = $helperdata;
        $this->_curl = $curl;
        $this->fileSystem = $filesystem;
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
    }

    public function getProductInfo($data)
    {
        try {
            $product = $this->productRepository->get($data['product_code']);
            $data = ['product_name' => $product->getName(), 'product_description' => $product->getDescription()];
        } catch (Exception $e) {
            $this->embodeeintegrationhelper->logtofile('Message: ' . $e->getMessage());
            return 'error';
        }
        return $data;
    }

    public function getPriceBreakDown($data)
    {
        try {
            $product = $this->productRepository->get($data['product_code']);
            $data = [
                    "errorcode" => 0,
                    "display_name" => $product->getName(),
                    "display_price" => $this->_priceData->currency($product->getFinalPrice(), true, false)
                ];
        } catch (Exception $e) {
            $this->embodeeintegrationhelper->logtofile('Message: ' . $e->getMessage());
            return 'error';
        }
        return $data;
    }

    public function getGraphic()
    {
        $fileId = 'Puma_EmbodeeIntegration::images/graphic';
        $params = [
            'area' => 'frontend'
        ];
        $asset = $this->assetRepository->createAsset($fileId, $params);
        $path = $asset->getSourceFile();
        if ($this->driverFile->isExists($path)) {
            $files = $this->driverFile->readDirectory($path);
            foreach ($files as $file) {
                $partsOfPath = explode('/', str_replace('\\', '/', $file));
                $fileName = $partsOfPath[count($partsOfPath) - 1];
                $name = str_replace('.png', '', str_replace(' ', '_', $fileName));
                $filenamearr[] = $name;
            }
        }
        $data = [[
        'status' => 'successful'
            ], [
                'components' => [
                    'host' => $asset->getUrl(),
                    'icons' => $filenamearr
                ]
            ]]
        ;
        return $data;
    }

    public function getPriceTiers($data)
    {
        $result = [];
        try {
            $childProducts = $this->linkManagement->getChildren($data['product_code']);
        } catch (Exception $e) {
            $this->embodeeintegrationhelper->logtofile('Message: ' . $e->getMessage());
            return 'error';
        }
        foreach (array_slice($childProducts, 0, 1) as $product) {
            $this->embodeeintegrationhelper->logtofile($product->getSku());
            $product = $this->productRepository->get($product->getSku());
            $tiers = $product->getTierPrice();
            foreach ($tiers as $price) {
                $this->embodeeintegrationhelper->logtofile($price);
                $result[$price['price_qty']] = $this->_priceData->currency($price['price'], true, false);
            }
        }
        return $result;
    }

    public function getStyleNumber($data)
    {
        $result = $this->searchProductSkuByAttributes($data['data']);
        $data = [
            'sku' => $result
        ];
        return $data;
    }

    public function searchProductSkuByAttributes($data)
    {
        $attributes = $this->jsonHelper->jsonDecode($data);
        foreach ($attributes as $code => $value) {
            switch ($code) {
                case 'embodee_garment_product_code':
                    $code = 'embodee_garment_product_code';
                    break;
                case 'CVP':
                    $code = 'cvp';
                    $attributeOptions = $this->_productAttributeRepository->get($code)->getOptions();
                    foreach ($attributeOptions as $attriopt) {
                        if ($attriopt->getLabel() == $value) {
                            $value = $attriopt->getValue();
                        } else {
                            continue;
                        }
                    }
                    break;
                case 'LS':
                    $code = 'ls';
                    $attributeOptions = $this->_productAttributeRepository->get($code)->getOptions();
                    foreach ($attributeOptions as $attriopt) {
                        if ($attriopt->getLabel() == $value) {
                            $value = $attriopt->getValue();
                        } else {
                            continue;
                        }
                    }
                    break;
                case 'Pro':
                    $code = 'pro';
                    $attributeOptions = $this->_productAttributeRepository->get($code)->getOptions();
                    foreach ($attributeOptions as $attriopt) {
                        if ($attriopt->getLabel() == $value) {
                            $value = $attriopt->getValue();
                        } else {
                            continue;
                        }
                    }
                    break;
                case 'G1':
                    $code = 'g1';
                    $attributeOptions = $this->_productAttributeRepository->get($code)->getOptions();
                    foreach ($attributeOptions as $attriopt) {
                        if ($attriopt->getLabel() == $value) {
                            $value = $attriopt->getValue();
                        } else {
                            continue;
                        }
                    }
                    break;
                case 'JrW':
                    $code = 'jrw';
                    $attributeOptions = $this->_productAttributeRepository->get($code)->getOptions();
                    foreach ($attributeOptions as $attriopt) {
                        if ($attriopt->getLabel() == $value) {
                            $value = $attriopt->getValue();
                        } else {
                            continue;
                        }
                    }
                    break;
                default:
                    break;
            }
            $this->searchCriteriaBuilder->addFilter(
                $code,
                $value,
                'eq'
            );
            $this->embodeeintegrationhelper->logtofile($code . '-' . $value);
        }
        $searchCriteria = $this->searchCriteriaBuilder->create();

        $result = $this->productRepository->getList($searchCriteria);
        foreach ($result->getItems() as $value) {
            $this->embodeeintegrationhelper->logtofile($value->getTypeId());
            if ($value->getSku() && $value->getTypeId() == 'configurable') {
                return $value->getSku();
            } else {
                continue;
            }
        }
    }


    public function getPdf($data)
    {
        $ud = $data['ud'];
        $productName = $data['pname'];
        $embodeUrl = $this->helperdata->getGeneralConfig('embourl');
        $totalImageCount = 5;
        $tempFile = [];
        $varPath = $this->fileSystem->getDirectoryWrite(DirectoryList::TMP)->getAbsolutePath();
       
        $fileId = 'Puma_EmbodeeIntegration::images/puma-logo.png';
        $params = [
            'area' => 'frontend'
        ];

        $asset = $this->assetRepository->createAsset($fileId, $params);
        try {
            $mediapath = $asset->getSourceFile();
        } catch (\Exception $e) {
            return null;
        }
        
        $mpdf = new \Mpdf\Mpdf(['tempDir' => $varPath]);
        
        $htmlHeader = '<div style="margin:0px auto; width:100%;max-width:630px;padding:25px;">
        <h1 style="font-size:28px;line-height:28px;color:#000000;margin:0px;font-family:ff-din-for-puma,serif;">'.$productName. '  '.$ud.'</h1>
        
        <div style="margin-top:30px;">
            <div style="width:436px; margin:0px auto;border-bottom:8px solid #000000;background: #f7f7f7;padding:12px;">';
                        
                
        for ($i=0; $i<$totalImageCount; $i++) {
            if ($i==0) {
                $fullEmbodeUrl=$embodeUrl.'/builder/ud/image/'.$ud.'/custom/254,263,jpg,1';
            }
            if ($i==1) {
                $fullEmbodeUrl=$embodeUrl.'/builder/ud/image/'.$ud.'/custom/158,179,jpg,5';
            }
            if ($i==2) {
                $fullEmbodeUrl=$embodeUrl.'/builder/ud/image/'.$ud.'/custom/122,181,jpg,7';
            }
            if ($i==3) {
                $fullEmbodeUrl=$embodeUrl.'/builder/ud/image/'.$ud.'/custom/122,181,jpg,3';
            }
            if ($i==4) {
                $fullEmbodeUrl=$embodeUrl.'/builder/ud/image/'.$ud.'/custom/158,265,jpg,5';
            }
            
            $this->_curl->get($fullEmbodeUrl);
            $response = $this->_curl->getBody();

            if ($response !== false) {
                $directory = $this->fileSystem->getDirectoryWrite(
                    DirectoryList::TMP
                );

               
                $directory->create();
                $image = @imagecreatefromstring($response);
                if (!$image) {
                    return false;
                }

                $xSize = imagesx($image);
                $ySize = imagesy($image);
                //imageinterlace($image, 0);
                $tmpFileName = $directory->getAbsolutePath(
                    'embodee_' . uniqid(\Magento\Framework\Math\Random::getRandomNumber()) . time() . '.jpg'
                );
                //imagepng($image, $tmpFileName);
                imagejpeg($image, $tmpFileName);
                $tempFile[] = $tmpFileName;
                if ($i==0) {
                    $htmlImage0 = '<img src="'.$tmpFileName.'" alt="" style="margin: 5px;vertical-align:top;">';
                }
                if ($i==1) {
                    $htmlImage1 = '<img src="'.$tmpFileName.'" alt=""  style="margin: 5px;vertical-align:top;">';
                }
                if ($i==2) {
                    $htmlImage2 = '<img src="'.$tmpFileName.'" alt=""  style="margin: 5px;vertical-align:top;">';
                }
                if ($i==3) {
                    $htmlImage3 = '<img src="'.$tmpFileName.'" alt=""  style="margin: 5px;vertical-align:top;">';
                }
                if ($i==4) {
                    $htmlImage4 = '<img src="'.$tmpFileName.'" alt="" style="display: inline-block;margin: 5px;margin-bottom: 0px;margin-top:-79px;">';
                }
            } else {
                $this->embodeeintegrationhelper->logtofile(curl_error($response));
            }
        }


        $htmlFooter = '</div>
            </div>
            <div style="text-align:right;clear:both;margin-top: 40px;">
                <img src="'.$mediapath.'" alt="">
            </div>
        </div>';
        $htmlImage =$htmlImage0.$htmlImage1.$htmlImage2.$htmlImage3.$htmlImage4;
        $html = $htmlHeader.$htmlImage.$htmlFooter;
        
        $mpdf->WriteHTML($html);

        $mpdf->Output('ProductDesign.pdf', 'D');

        if (count($tempFile)>0) {
            foreach ($tempFile as $temp) {
                unlink($temp);
            }
        }
    }
}

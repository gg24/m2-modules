<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Model;

/**
 * @method \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord _getResource()
 * @method \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord getResource()
 */
class Udcustomerrecord extends \Magento\Framework\Model\AbstractModel implements \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
{
    /**
     * Cache tag
     *
     * @var string
     */
    const CACHE_TAG = 'puma_embodeeintegration_udcustomerrecord';

    /**
     * Cache tag
     *
     * @var string
     */
    protected $_cacheTag = self::CACHE_TAG;

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'puma_embodeeintegration_udcustomerrecord';

    /**
     * Event object
     *
     * @var string
     */
    protected $_eventObject = 'udcustomerrecord';

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord::class);
    }

    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Get UD Customer Record id
     *
     * @return array
     */
    public function getUdcustomerrecordId()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::UDCUSTOMERRECORD_ID);
    }

    /**
     * set UD Customer Record id
     *
     * @param int $udcustomerrecordId
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
     */
    public function setUdcustomerrecordId($udcustomerrecordId)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::UDCUSTOMERRECORD_ID, $udcustomerrecordId);
    }

    /**
     * set Customer Id
     *
     * @param mixed $customerId
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
     */
    public function setCustomerId($customerId)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::CUSTOMER_ID, $customerId);
    }

    /**
     * get Customer Id
     *
     * @return string
     */
    public function getCustomerId()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::CUSTOMER_ID);
    }

    /**
     * set User Design Id
     *
     * @param mixed $udId
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
     */
    public function setUdId($udId)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::UD_ID, $udId);
    }

    /**
     * get User Design Id
     *
     * @return string
     */
    public function getUdId()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::UD_ID);
    }

    /**
     * set Product Code
     *
     * @param mixed $productCode
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
     */
    public function setProductCode($productCode)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::PRODUCT_CODE, $productCode);
    }

    /**
     * get Product Code
     *
     * @return string
     */
    public function getProductCode()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::PRODUCT_CODE);
    }

    /**
     * set Extra Field 1
     *
     * @param mixed $extraFieldOne
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
     */
    public function setExtraFieldOne($extraFieldOne)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::EXTRA_FIELD_ONE, $extraFieldOne);
    }

    /**
     * get Extra Field 1
     *
     * @return string
     */
    public function getExtraFieldOne()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::EXTRA_FIELD_ONE);
    }

    /**
     * set Extra Field 2
     *
     * @param mixed $extraFieldTwo
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
     */
    public function setExtraFieldTwo($extraFieldTwo)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::EXTRA_FIELD_TWO, $extraFieldTwo);
    }

    /**
     * get Extra Field 2
     *
     * @return string
     */
    public function getExtraFieldTwo()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::EXTRA_FIELD_TWO);
    }

    /**
     * set Extra Field 3
     *
     * @param mixed $extraFieldThree
     * @return \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface
     */
    public function setExtraFieldThree($extraFieldThree)
    {
        return $this->setData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::EXTRA_FIELD_THREE, $extraFieldThree);
    }

    /**
     * get Extra Field 3
     *
     * @return string
     */
    public function getExtraFieldThree()
    {
        return $this->getData(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::EXTRA_FIELD_THREE);
    }
}

<?php

/**
 * Created by PhpStorm.
 * User: prashant
 * Date: 31/5/18
 * Time: 4:24 PM
 */

namespace Puma\EmbodeeIntegration\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Customer\Model\Session;

class Data extends AbstractHelper
{

    const XML_PATH_PUMAEMBODEE = 'pumaembodeesection/';
    
    /**
     * @var $_session
     */
    private $customerSession;
    
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        Session $customerSession
    ) {
        $this->customerSession = $customerSession;
        parent::__construct($context);
    }

    public function getConfigValue($field, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $field,
            ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
            $storeId
        );
    }

    public function getGeneralConfig($code, $storeId = null)
    {

        return $this->getConfigValue(self::XML_PATH_PUMAEMBODEE . 'general/' . $code, $storeId);
    }

    public function isLoggedIn()
    {
        return $this->customerSession->isLoggedIn();
    }
    
    public function getCustomerId()
    {
        return $this->customerSession->getCustomerId();
    }
    
    public function logtofile($data)
    {
        if ($this->getGeneralConfig('logenable')) {
            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/embodeedata.log');
            $logger = new \Zend\Log\Logger();
            $logger->addWriter($writer);
        //$logger->info($data);
            $logger->info($data);
        } else {
            return;
        }
    }
}

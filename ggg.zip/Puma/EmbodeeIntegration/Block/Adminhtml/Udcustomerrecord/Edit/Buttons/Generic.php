<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Block\Adminhtml\Udcustomerrecord\Edit\Buttons;

class Generic
{
    /**
     * Widget Context
     *
     * @var \Magento\Backend\Block\Widget\Context
     */
    protected $context;

    /**
     * UD Customer Record Repository
     *
     * @var \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface
     */
    protected $udcustomerrecordRepository;

    /**
     * constructor
     *
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface $udcustomerrecordRepository
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface $udcustomerrecordRepository
    ) {
    
        $this->context = $context;
        $this->udcustomerrecordRepository = $udcustomerrecordRepository;
    }

    /**
     * Return UD Customer Record ID
     *
     * @return int|null
     */
    public function getUdcustomerrecordId()
    {
        try {
            return $this->udcustomerrecordRepository->getById(
                $this->context->getRequest()->getParam('udcustomerrecord_id')
            )->getId();
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            return null;
        }
    }

    /**
     * Generate url by route and parameters
     *
     * @param   string $route
     * @param   array $params
     * @return  string
     */
    public function getUrl($route = '', $params = [])
    {
        return $this->context->getUrlBuilder()->getUrl($route, $params);
    }
}

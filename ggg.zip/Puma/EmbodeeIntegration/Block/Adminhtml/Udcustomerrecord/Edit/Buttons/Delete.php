<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Block\Adminhtml\Udcustomerrecord\Edit\Buttons;

class Delete extends \Puma\EmbodeeIntegration\Block\Adminhtml\Udcustomerrecord\Edit\Buttons\Generic implements \Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface
{
    /**
     * get button data
     *
     * @return array
     */
    public function getButtonData()
    {
        $data = [];
        if ($this->getUdcustomerrecordId()) {
            $data = [
                'label' => __('Delete UD&#x20;Customer&#x20;Record'),
                'class' => 'delete',
                'on_click' => 'deleteConfirm(\'' . __(
                    'Are you sure you want to do this?'
                ) . '\', \'' . $this->getDeleteUrl() . '\')',
                'sort_order' => 20,
            ];
        }
        return $data;
    }

    /**
     * @return string
     */
    public function getDeleteUrl()
    {
        return $this->getUrl('*/*/delete', ['udcustomerrecord_id' => $this->getUdcustomerrecordId()]);
    }
}

<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Block\Adminhtml\Precartrecord\Edit\Buttons;

class Generic
{
    /**
     * Widget Context
     *
     * @var \Magento\Backend\Block\Widget\Context
     */
    protected $context;

    /**
     * Pre Cart Record Repository
     *
     * @var \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface
     */
    protected $precartrecordRepository;

    /**
     * constructor
     *
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository
    ) {
        $this->context                 = $context;
        $this->precartrecordRepository = $precartrecordRepository;
    }

    /**
     * Return Pre Cart Record ID
     *
     * @return int|null
     */
    public function getPrecartrecordId()
    {
        try {
            return $this->precartrecordRepository->getById(
                $this->context->getRequest()->getParam('precartrecord_id')
            )->getId();
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            return null;
        }
    }

    /**
     * Generate url by route and parameters
     *
     * @param   string $route
     * @param   array $params
     * @return  string
     */
    public function getUrl($route = '', $params = [])
    {
        return $this->context->getUrlBuilder()->getUrl($route, $params);
    }
}

<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Block;

use Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord\CollectionFactory;
use Magento\Customer\Model\Session;

class Embodeeintegration extends \Magento\Framework\View\Element\Template
{

    /**
     * @var UdcustomerrecordFactory
     */
    protected $_udcollectionFactory;

    /**
     * @var $session
     */
    protected $_customerSession;

    /**
     * @var $udlist
     */
    protected $udlist;

    /**
     * Embodeeintegration constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param UdcustomerrecordFactory $udcustomerrecordFactory
     * @param Session $customerSession
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        CollectionFactory $udcollectionFactory,
        Session $customerSession,
        array $data = []
    ) {
    
        $this->_udcollectionFactory = $udcollectionFactory;
        $this->_customerSession = $customerSession;
        parent::__construct($context, $data);
        //get collection of data
    }



    /**
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _construct()
    {
        parent::_construct();
        $this->pageConfig->getTitle()->set(__('Saved Designs'));
    }

    /**
     * @return CollectionFactoryInterface
     */
    private function getUdCollectionFactory()
    {
        if ($this->_udcollectionFactory === null) {
            $this->_udcollectionFactory = ObjectManager::getInstance()->get(CollectionFactoryInterface::class);
        }
        return $this->_udcollectionFactory;
    }


    public function getUdList()
    {
        if (!($customerId = $this->_customerSession->getCustomerId())) {
            return false;
        }
        if ($this->getRequest()->getParam('udname') != '') {
            $udname = $this->getRequest()->getParam('udname');
        } else {
            $udname = '';
        }
        if ($this->getRequest()->getParam('sort_by') != '') {
            $sort_by = $this->getRequest()->getParam('sort_by');
        } else {
            $sort_by = 'desc';
        }
        if (!$this->udlist) {
            $this->udlist = $this->getUdCollectionFactory()->create()->addFieldToSelect(
                '*'
            )->addFieldToFilter(
                'customer_id',
                ['eq' => $customerId]
            )
            ->addFieldToFilter(
                'extra_field_one',
                ['like' => '%'.$udname.'%']
            )
            ->setOrder(
                'created_at',
                $sort_by
            );
        }
        return $this->udlist;
    }

    /**
     * @return $this|\Magento\Framework\View\Element\Template
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        if ($this->getUdList()) {
            $pager = $this->getLayout()->createBlock(
                \Magento\Theme\Block\Html\Pager::class,
                'sales.order.history.pager'
            )->setCollection(
                $this->getUdList()
            );
            $this->setChild('pager', $pager);
            $this->getUdList()->load();
        }
        return $this;
    }


    /**
     * @return string
     * method for get pager html
     */
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }


    /**
     * @return string
     */
    public function getBanner()
    {
        return "Sample UD";
    }
}

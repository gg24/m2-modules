<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Userdesigns;

use Magento\Framework\App\Action\Context;
use Puma\EmbodeeIntegration\Model\UdcustomerrecordFactory;
use Puma\EmbodeeIntegration\Model\UdcustomerrecordRepository;
use Magento\Framework\Controller\ResultFactory;

class Remove extends \Magento\Framework\App\Action\Action
{
    protected $_resultPageFactory;
    protected $_udcustomerrecordFactory;
    protected $_udcustomerrecordRepository;
    protected $_resultFactory;

    public function __construct(
        Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        UdcustomerrecordFactory $udcustomerrecordFactory,
        UdcustomerrecordRepository $udcustomerrecordRepository
    ) {

    
        $this->_udcustomerrecordFactory = $udcustomerrecordFactory;
        $this->_udcustomerrecordRepository = $udcustomerrecordRepository;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $this->_udcustomerrecordRepository->deleteById($data['id']);
        $this->_redirect($this->_redirect->getRefererUrl());
    }
}

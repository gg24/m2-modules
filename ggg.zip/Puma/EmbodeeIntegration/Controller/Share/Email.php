<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Share;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\Result\JsonFactory;
use Puma\EmbodeeIntegration\Model\ShareEmail;
use Puma\EmbodeeIntegration\Helper\Data;

class Email extends Action
{
    protected $_resultPageFactory;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var JsonFactory
     */
    protected $jsonFactory;
    
    /**
     * @var ShareEmail
     */
    protected $shareEmail;
    
    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;
  

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param JsonHelper $jsonHelper
     * @param JsonFactory $jsonFactory
     */
    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        ShareEmail $shareEmail,
        Data $embodeeintegrationhelper
    ) {
    
        $this->jsonFactory = $jsonFactory;
        $this->shareEmail = $shareEmail;
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
        parent::__construct($context);
    }


    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $response = $this->shareEmail->sendMail($data);
        $result = $this->jsonFactory->create();
        return $result->setData($response);
    }
}

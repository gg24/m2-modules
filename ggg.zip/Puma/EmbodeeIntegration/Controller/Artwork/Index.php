<?php

/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Artwork;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\Result\JsonFactory;
use Puma\EmbodeeIntegration\Model\Udsaveprocessing;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Io\File;
use Magento\Store\Model\StoreManagerInterface;
use Puma\EmbodeeIntegration\Helper\Data;

class Index extends Action
{

    protected $_resultPageFactory;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var JsonFactory
     */
    protected $jsonFactory;

    /**
     * @var Udsaveprocessing
     */
    private $udsaveprocessing;

    /**
     *
     * @var Filesystem
     */
    protected $_fileSystem;

    /**
     *
     * @var Files
     */
    protected $_file;

    /**
     *
     * @var UploaderFactory
     */
    protected $fileUploaderFactory;
    
    /**
     *
     * @var StoreManagerInterface
     */
    protected $_storeManager;
    
    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param JsonFactory $jsonFactory
     * @param UploaderFactory
     * @param Udsaveprocessing
     * @param Filesystem
     */
    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        JsonFactory $jsonFactory,
        UploaderFactory $fileUploaderFactory,
        Udsaveprocessing $udsaveprocessing,
        Filesystem $fileSystem,
        File $file,
        Data $embodeeintegrationhelper
    ) {
        $this->jsonFactory = $jsonFactory;
        $this->fileUploaderFactory = $fileUploaderFactory;
        $this->udsaveprocessing = $udsaveprocessing;
        $this->_fileSystem = $fileSystem;
        $this->_file = $file;
        $this->_storeManager = $storeManager;
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
        parent::__construct($context);
    }

    public function execute()
    {
        $this->embodeeintegrationhelper->logtofile($_FILES);
        $result_file = [];
        if ($_FILES['image']['name']) {
            try {
                // init uploader model.
                $uploader = $this->fileUploaderFactory->create(['fileId' => 'image']);
                $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png', 'svg)']);
                $uploader->setAllowRenameFiles(true);
                $uploader->setFilesDispersion(false);
                // get media directory
                $mediaDirectory = $this->_fileSystem->getDirectoryRead(DirectoryList::MEDIA);
                $artworkPath = $mediaDirectory->getAbsolutePath('artwork/');
                if (!is_dir($artworkPath)) {
                    $this->_file->mkdir($artworkPath);
                }
                // save the image to media directory
                $result_file = $uploader->save($artworkPath);
            } catch (\Exception $e) {
                \Zend_Debug::dump($e->getMessage());
            }
        }
        if (is_file($artworkPath.$result_file['file'])) {
            $url = $this->_storeManager
                    ->getStore()
                    ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'artwork/'.$result_file['file'];
        } else {
            $url = 'error';
        }
        $result = $this->jsonFactory->create();
        return $result->setData($url);
    }
}

<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Index;

use Magento\Framework\App\Action\Context;
use Puma\EmbodeeIntegration\Model\UdcustomerrecordFactory;
use Magento\Store\Model\ScopeInterface;

class Index extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;

    /**
     * @var UdcustomerrecordFactory
     */
    protected $_udcustomerrecordFactory;

    /**
     * @var Data
     */
    protected $jsonHelper;

    /**
     * @var helperdata
     */
    protected $helperdata;
    /**
     * Index constructor.
     * @param Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param UdcustomerrecordFactory $udcustomerrecordFactory
     * @param $jsonHelper
     * @param $helperdata
     */
    public function __construct(
        Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        UdcustomerrecordFactory $udcustomerrecordFactory,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Puma\EmbodeeIntegration\Helper\Data $helperdata
    ) {
        $this->_udcustomerrecordFactory = $udcustomerrecordFactory;
        $this->_resultPageFactory = $resultPageFactory;
        $this->jsonHelper = $jsonHelper;
        $this->helperdata = $helperdata;
        parent::__construct($context);
    }
    public function execute()
    {
        /* checking with sample */
        return true;
    }
}

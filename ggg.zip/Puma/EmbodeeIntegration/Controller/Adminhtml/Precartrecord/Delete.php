<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord;

class Delete extends \Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord
{
    /**
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('precartrecord_id');
        if ($id) {
            try {
                $this->precartrecordRepository->deleteById($id);
                $this->messageManager->addSuccessMessage(__('The Pre&#x20;Cart&#x20;Record has been deleted.'));
                $resultRedirect->setPath('puma_embodeeintegration/*/');
                return $resultRedirect;
            } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
                $this->messageManager->addErrorMessage(__('The Pre&#x20;Cart&#x20;Record no longer exists.'));
                return $resultRedirect->setPath('puma_embodeeintegration/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
                return $resultRedirect->setPath('puma_embodeeintegration/precartrecord/edit', ['precartrecord_id' => $id]);
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(__('There was a problem deleting the Pre&#x20;Cart&#x20;Record'));
                return $resultRedirect->setPath('puma_embodeeintegration/precartrecord/edit', ['precartrecord_id' => $id]);
            }
        }
        $this->messageManager->addErrorMessage(__('We can\'t find a Pre&#x20;Cart&#x20;Record to delete.'));
        $resultRedirect->setPath('puma_embodeeintegration/*/');
        return $resultRedirect;
    }
}

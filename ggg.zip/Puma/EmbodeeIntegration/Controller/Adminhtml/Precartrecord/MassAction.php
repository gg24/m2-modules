<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord;

abstract class MassAction extends \Magento\Backend\App\Action
{
    /**
     * Pre Cart Record repository
     *
     * @var \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface
     */
    protected $precartrecordRepository;

    /**
     * Mass Action filter
     *
     * @var \Magento\Ui\Component\MassAction\Filter
     */
    protected $filter;

    /**
     * Pre Cart Record collection factory
     *
     * @var \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * Action success message
     *
     * @var string
     */
    protected $successMessage;

    /**
     * Action error message
     *
     * @var string
     */
    protected $errorMessage;

    /**
     * constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository
     * @param \Magento\Ui\Component\MassAction\Filter $filter
     * @param \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\CollectionFactory $collectionFactory
     * @param string $successMessage
     * @param string $errorMessage
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository,
        \Magento\Ui\Component\MassAction\Filter $filter,
        \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\CollectionFactory $collectionFactory,
        $successMessage,
        $errorMessage
    ) {
        $this->precartrecordRepository = $precartrecordRepository;
        $this->filter                  = $filter;
        $this->collectionFactory       = $collectionFactory;
        $this->successMessage          = $successMessage;
        $this->errorMessage            = $errorMessage;
        parent::__construct($context);
    }

    /**
     * @param \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord
     * @return mixed
     */
    abstract protected function massAction(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord);

    /**
     * execute action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        try {
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $collectionSize = $collection->getSize();
            foreach ($collection as $precartrecord) {
                $this->massAction($precartrecord);
            }
            $this->messageManager->addSuccessMessage(__($this->successMessage, $collectionSize));
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, $this->errorMessage);
        }
        $redirectResult = $this->resultRedirectFactory->create();
        $redirectResult->setPath('puma_embodeeintegration/*/index');
        return $redirectResult;
    }
}

<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord;

class InlineEdit extends \Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    /**
     * Pre Cart Record repository
     *
     * @var \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface
     */
    protected $precartrecordRepository;

    /**
     * Page factory
     *
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * Data object processor
     *
     * @var \Magento\Framework\Reflection\DataObjectProcessor
     */
    protected $dataObjectProcessor;

    /**
     * Data object helper
     *
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * JSON Factory
     *
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $jsonFactory;

    /**
     * Pre Cart Record resource model
     *
     * @var \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord
     */
    protected $precartrecordResourceModel;

    /**
     * constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Reflection\DataObjectProcessor $dataObjectProcessor
     * @param \Magento\Framework\Api\DataObjectHelper $dataObjectHelper
     * @param \Magento\Framework\Controller\Result\JsonFactory $jsonFactory
     * @param \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord $precartrecordResourceModel
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Reflection\DataObjectProcessor $dataObjectProcessor,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        \Magento\Framework\Controller\Result\JsonFactory $jsonFactory,
        \Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord $precartrecordResourceModel
    ) {
        $this->dataObjectProcessor        = $dataObjectProcessor;
        $this->dataObjectHelper           = $dataObjectHelper;
        $this->jsonFactory                = $jsonFactory;
        $this->precartrecordResourceModel = $precartrecordResourceModel;
        parent::__construct($context, $coreRegistry, $precartrecordRepository, $resultPageFactory);
    }

    /**
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->jsonFactory->create();
        $error = false;
        $messages = [];

        $postItems = $this->getRequest()->getParam('items', []);
        if (!($this->getRequest()->getParam('isAjax') && count($postItems))) {
            return $resultJson->setData([
                'messages' => [__('Please correct the data sent.')],
                'error' => true,
            ]);
        }

        foreach (array_keys($postItems) as $precartrecordId) {
            /** @var \Puma\EmbodeeIntegration\Model\Precartrecord|\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord */
            $precartrecord = $this->precartrecordRepository->getById((int)$precartrecordId);
            try {
                $precartrecordData = $postItems[$precartrecordId];
                $this->dataObjectHelper->populateWithArray($precartrecord, $precartrecordData, \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::class);
                $this->precartrecordResourceModel->saveAttribute($precartrecord, array_keys($precartrecordData));
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $messages[] = $this->getErrorWithPrecartrecordId($precartrecord, $e->getMessage());
                $error = true;
            } catch (\RuntimeException $e) {
                $messages[] = $this->getErrorWithPrecartrecordId($precartrecord, $e->getMessage());
                $error = true;
            } catch (\Exception $e) {
                $messages[] = $this->getErrorWithPrecartrecordId(
                    $precartrecord,
                    __('Something went wrong while saving the Pre&#x20;Cart&#x20;Record.')
                );
                $error = true;
            }
        }

        return $resultJson->setData([
            'messages' => $messages,
            'error' => $error
        ]);
    }

    /**
     * Add Pre&#x20;Cart&#x20;Record id to error message
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord
     * @param string $errorText
     * @return string
     */
    protected function getErrorWithPrecartrecordId(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord, $errorText)
    {
        return '[Pre&#x20;Cart&#x20;Record ID: ' . $precartrecord->getId() . '] ' . $errorText;
    }
}

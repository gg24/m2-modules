<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord;

class Save extends \Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord
{
    /**
     * Pre Cart Record factory
     *
     * @var \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterfaceFactory
     */
    protected $precartrecordFactory;

    /**
     * Data Object Processor
     *
     * @var \Magento\Framework\Reflection\DataObjectProcessor
     */
    protected $dataObjectProcessor;

    /**
     * Data Object Helper
     *
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * Uploader pool
     *
     * @var \Puma\EmbodeeIntegration\Model\Precartrecord
     */
    protected $uploaderPool;

    /**
     * Data Persistor
     *
     * @var \Magento\Framework\App\Request\DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterfaceFactory $precartrecordFactory
     * @param \Magento\Framework\Reflection\DataObjectProcessor $dataObjectProcessor
     * @param \Magento\Framework\Api\DataObjectHelper $dataObjectHelper
     * @param \Puma\EmbodeeIntegration\Model\Precartrecord $uploaderPool
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterfaceFactory $precartrecordFactory,
        \Magento\Framework\Reflection\DataObjectProcessor $dataObjectProcessor,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        \Puma\EmbodeeIntegration\Model\Precartrecord $uploaderPool,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
    ) {
        $this->precartrecordFactory = $precartrecordFactory;
        $this->dataObjectProcessor  = $dataObjectProcessor;
        $this->dataObjectHelper     = $dataObjectHelper;
        $this->uploaderPool         = $uploaderPool;
        $this->dataPersistor        = $dataPersistor;
        parent::__construct($context, $coreRegistry, $precartrecordRepository, $resultPageFactory);
    }

    /**
     * run the action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord */
        $precartrecord = null;
        $postData = $this->getRequest()->getPostValue();
        $data = $postData;
        $id = !empty($data['precartrecord_id']) ? $data['precartrecord_id'] : null;
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            if ($id) {
                $precartrecord = $this->precartrecordRepository->getById((int)$id);
            } else {
                unset($data['precartrecord_id']);
                $precartrecord = $this->precartrecordFactory->create();
            }
            $this->dataObjectHelper->populateWithArray($precartrecord, $data, \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface::class);
            $this->precartrecordRepository->save($precartrecord);
            $this->messageManager->addSuccessMessage(__('You saved the Pre&#x20;Cart&#x20;Record'));
            $this->dataPersistor->clear('puma_embodeeintegration_precartrecord');
            if ($this->getRequest()->getParam('back')) {
                $resultRedirect->setPath('puma_embodeeintegration/precartrecord/edit', ['precartrecord_id' => $precartrecord->getId()]);
            } else {
                $resultRedirect->setPath('puma_embodeeintegration/precartrecord');
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
            $this->dataPersistor->set('puma_embodeeintegration_precartrecord', $postData);
            $resultRedirect->setPath('puma_embodeeintegration/precartrecord/edit', ['precartrecord_id' => $id]);
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('There was a problem saving the Pre&#x20;Cart&#x20;Record'));
            $this->dataPersistor->set('puma_embodeeintegration_precartrecord', $postData);
            $resultRedirect->setPath('puma_embodeeintegration/precartrecord/edit', ['precartrecord_id' => $id]);
        }
        return $resultRedirect;
    }

    /**
     * @param string $type
     * @return \Puma\EmbodeeIntegration\Model\Uploader
     * @throws \Exception
     */
    protected function getUploader($type)
    {
        return $this->uploaderPool->getUploader($type);
    }
}

<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord;

class Edit extends \Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord
{
    /**
     * Initialize current Pre Cart Record and set it in the registry.
     *
     * @return int
     */
    protected function initPrecartrecord()
    {
        $precartrecordId = $this->getRequest()->getParam('precartrecord_id');
        $this->coreRegistry->register(\Puma\EmbodeeIntegration\Controller\RegistryConstants::CURRENT_PRECARTRECORD_ID, $precartrecordId);

        return $precartrecordId;
    }

    /**
     * Edit or create Pre Cart Record
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $precartrecordId = $this->initPrecartrecord();

        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Puma_EmbodeeIntegration::embodeeintegration_precartrecord');
        $resultPage->getConfig()->getTitle()->prepend(__('Pre&#x20;Cart&#x20;Record'));
        $resultPage->addBreadcrumb(__('Puma Embodee Interface'), __('Puma Embodee Interface'));
        $resultPage->addBreadcrumb(__('Pre&#x20;Cart&#x20;Record'), __('Pre&#x20;Cart&#x20;Record'), $this->getUrl('puma_embodeeintegration/precartrecord'));

        if ($precartrecordId === null) {
            $resultPage->addBreadcrumb(__('New Pre&#x20;Cart&#x20;Record'), __('New Pre&#x20;Cart&#x20;Record'));
            $resultPage->getConfig()->getTitle()->prepend(__('New Pre&#x20;Cart&#x20;Record'));
        } else {
            $resultPage->addBreadcrumb(__('Edit Pre&#x20;Cart&#x20;Record'), __('Edit Pre&#x20;Cart&#x20;Record'));
            $resultPage->getConfig()->getTitle()->prepend(
                $this->precartrecordRepository->getById($precartrecordId)->getUser_id()
            );
        }
        return $resultPage;
    }
}

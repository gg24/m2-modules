<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord;

class MassDelete extends \Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord\MassAction
{
    /**
     * @param \Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord
     * @return $this
     */
    protected function massAction(\Puma\EmbodeeIntegration\Api\Data\PrecartrecordInterface $precartrecord)
    {
        $this->precartrecordRepository->delete($precartrecord);
        return $this;
    }
}

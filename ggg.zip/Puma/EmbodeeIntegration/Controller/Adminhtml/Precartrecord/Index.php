<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord;

class Index extends \Puma\EmbodeeIntegration\Controller\Adminhtml\Precartrecord
{
    /**
     * Pre Cart Record list.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Puma_EmbodeeIntegration::precartrecord');
        $resultPage->getConfig()->getTitle()->prepend(__('Pre&#x20;Cart&#x20;Record'));
        $resultPage->addBreadcrumb(__('Puma Embodee Interface'), __('Puma Embodee Interface'));
        $resultPage->addBreadcrumb(__('Pre&#x20;Cart&#x20;Record'), __('Pre&#x20;Cart&#x20;Record'));
        return $resultPage;
    }
}

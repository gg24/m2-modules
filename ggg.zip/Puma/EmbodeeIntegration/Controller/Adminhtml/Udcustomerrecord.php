<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Adminhtml;

abstract class Udcustomerrecord extends \Magento\Backend\App\Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    /**
     * UD Customer Record repository
     *
     * @var \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface
     */
    protected $udcustomerrecordRepository;

    /**
     * Page factory
     *
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface $udcustomerrecordRepository
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface $udcustomerrecordRepository,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
    
        $this->coreRegistry = $coreRegistry;
        $this->udcustomerrecordRepository = $udcustomerrecordRepository;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
}

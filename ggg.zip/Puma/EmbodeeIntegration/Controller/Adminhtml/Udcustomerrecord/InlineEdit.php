<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Adminhtml\Udcustomerrecord;

class InlineEdit extends \Puma\EmbodeeIntegration\Controller\Adminhtml\Udcustomerrecord
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    /**
     * UD Customer Record repository
     *
     * @var \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface
     */
    protected $udcustomerrecordRepository;

    /**
     * Page factory
     *
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * Data object processor
     *
     * @var \Magento\Framework\Reflection\DataObjectProcessor
     */
    protected $dataObjectProcessor;

    /**
     * Data object helper
     *
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * JSON Factory
     *
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $jsonFactory;

    /**
     * UD Customer Record resource model
     *
     * @var \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord
     */
    protected $udcustomerrecordResourceModel;

    /**
     * constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface $udcustomerrecordRepository
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Reflection\DataObjectProcessor $dataObjectProcessor
     * @param \Magento\Framework\Api\DataObjectHelper $dataObjectHelper
     * @param \Magento\Framework\Controller\Result\JsonFactory $jsonFactory
     * @param \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord $udcustomerrecordResourceModel
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface $udcustomerrecordRepository,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Reflection\DataObjectProcessor $dataObjectProcessor,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        \Magento\Framework\Controller\Result\JsonFactory $jsonFactory,
        \Puma\EmbodeeIntegration\Model\ResourceModel\Udcustomerrecord $udcustomerrecordResourceModel
    ) {
    
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->jsonFactory = $jsonFactory;
        $this->udcustomerrecordResourceModel = $udcustomerrecordResourceModel;
        parent::__construct($context, $coreRegistry, $udcustomerrecordRepository, $resultPageFactory);
    }

    /**
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->jsonFactory->create();
        $error = false;
        $messages = [];

        $postItems = $this->getRequest()->getParam('items', []);
        if (!($this->getRequest()->getParam('isAjax') && count($postItems))) {
            return $resultJson->setData([
                'messages' => [__('Please correct the data sent.')],
                'error' => true,
            ]);
        }

        foreach (array_keys($postItems) as $udcustomerrecordId) {
            /** @var \Puma\EmbodeeIntegration\Model\Udcustomerrecord|\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord */
            $udcustomerrecord = $this->udcustomerrecordRepository->getById((int)$udcustomerrecordId);
            try {
                $udcustomerrecordData = $postItems[$udcustomerrecordId];
                $this->dataObjectHelper->populateWithArray($udcustomerrecord, $udcustomerrecordData, \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::class);
                $this->udcustomerrecordResourceModel->saveAttribute($udcustomerrecord, array_keys($udcustomerrecordData));
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $messages[] = $this->getErrorWithUdcustomerrecordId($udcustomerrecord, $e->getMessage());
                $error = true;
            } catch (\RuntimeException $e) {
                $messages[] = $this->getErrorWithUdcustomerrecordId($udcustomerrecord, $e->getMessage());
                $error = true;
            } catch (\Exception $e) {
                $messages[] = $this->getErrorWithUdcustomerrecordId(
                    $udcustomerrecord,
                    __('Something went wrong while saving the UD&#x20;Customer&#x20;Record.')
                );
                $error = true;
            }
        }

        return $resultJson->setData([
            'messages' => $messages,
            'error' => $error
        ]);
    }

    /**
     * Add UD&#x20;Customer&#x20;Record id to error message
     *
     * @param \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord
     * @param string $errorText
     * @return string
     */
    protected function getErrorWithUdcustomerrecordId(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord, $errorText)
    {
        return '[UD&#x20;Customer&#x20;Record ID: ' . $udcustomerrecord->getId() . '] ' . $errorText;
    }
}

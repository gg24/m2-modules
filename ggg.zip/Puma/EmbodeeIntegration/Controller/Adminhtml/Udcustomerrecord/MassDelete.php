<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Adminhtml\Udcustomerrecord;

class MassDelete extends \Puma\EmbodeeIntegration\Controller\Adminhtml\Udcustomerrecord\MassAction
{
    /**
     * @param \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord
     * @return $this
     */
    protected function massAction(\Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord)
    {
        $this->udcustomerrecordRepository->delete($udcustomerrecord);
        return $this;
    }
}

<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Adminhtml\Udcustomerrecord;

class Save extends \Puma\EmbodeeIntegration\Controller\Adminhtml\Udcustomerrecord
{
    /**
     * UD Customer Record factory
     *
     * @var \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterfaceFactory
     */
    protected $udcustomerrecordFactory;

    /**
     * Data Object Processor
     *
     * @var \Magento\Framework\Reflection\DataObjectProcessor
     */
    protected $dataObjectProcessor;

    /**
     * Data Object Helper
     *
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * Uploader pool
     *
     * @var \Puma\EmbodeeIntegration\Model\Udcustomerrecord
     */
    protected $uploaderPool;

    /**
     * Data Persistor
     *
     * @var \Magento\Framework\App\Request\DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface $udcustomerrecordRepository
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterfaceFactory $udcustomerrecordFactory
     * @param \Magento\Framework\Reflection\DataObjectProcessor $dataObjectProcessor
     * @param \Magento\Framework\Api\DataObjectHelper $dataObjectHelper
     * @param \Puma\EmbodeeIntegration\Model\Udcustomerrecord $uploaderPool
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Puma\EmbodeeIntegration\Api\UdcustomerrecordRepositoryInterface $udcustomerrecordRepository,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterfaceFactory $udcustomerrecordFactory,
        \Magento\Framework\Reflection\DataObjectProcessor $dataObjectProcessor,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        \Puma\EmbodeeIntegration\Model\Udcustomerrecord $uploaderPool,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
    ) {
    
        $this->udcustomerrecordFactory = $udcustomerrecordFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->uploaderPool = $uploaderPool;
        $this->dataPersistor = $dataPersistor;
        parent::__construct($context, $coreRegistry, $udcustomerrecordRepository, $resultPageFactory);
    }

    /**
     * run the action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface $udcustomerrecord */
        $udcustomerrecord = null;
        $postData = $this->getRequest()->getPostValue();
        $data = $postData;
        $id = !empty($data['udcustomerrecord_id']) ? $data['udcustomerrecord_id'] : null;
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            if ($id) {
                $udcustomerrecord = $this->udcustomerrecordRepository->getById((int)$id);
            } else {
                unset($data['udcustomerrecord_id']);
                $udcustomerrecord = $this->udcustomerrecordFactory->create();
            }
            $this->dataObjectHelper->populateWithArray($udcustomerrecord, $data, \Puma\EmbodeeIntegration\Api\Data\UdcustomerrecordInterface::class);
            $this->udcustomerrecordRepository->save($udcustomerrecord);
            $this->messageManager->addSuccessMessage(__('You saved the UD&#x20;Customer&#x20;Record'));
            $this->dataPersistor->clear('puma_embodeeintegration_udcustomerrecord');
            if ($this->getRequest()->getParam('back')) {
                $resultRedirect->setPath('puma_embodeeintegration/udcustomerrecord/edit', ['udcustomerrecord_id' => $udcustomerrecord->getId()]);
            } else {
                $resultRedirect->setPath('puma_embodeeintegration/udcustomerrecord');
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
            $this->dataPersistor->set('puma_embodeeintegration_udcustomerrecord', $postData);
            $resultRedirect->setPath('puma_embodeeintegration/udcustomerrecord/edit', ['udcustomerrecord_id' => $id]);
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('There was a problem saving the UD&#x20;Customer&#x20;Record'));
            $this->dataPersistor->set('puma_embodeeintegration_udcustomerrecord', $postData);
            $resultRedirect->setPath('puma_embodeeintegration/udcustomerrecord/edit', ['udcustomerrecord_id' => $id]);
        }
        return $resultRedirect;
    }

    /**
     * @param string $type
     * @return \Puma\EmbodeeIntegration\Model\Uploader
     * @throws \Exception
     */
    protected function getUploader($type)
    {
        return $this->uploaderPool->getUploader($type);
    }
}

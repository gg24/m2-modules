<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Adminhtml\Udcustomerrecord;

class Index extends \Puma\EmbodeeIntegration\Controller\Adminhtml\Udcustomerrecord
{
    /**
     * UD Customer Records list.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Puma_EmbodeeIntegration::udcustomerrecord');
        $resultPage->getConfig()->getTitle()->prepend(__('UD&#x20;Customer&#x20;Records'));
        $resultPage->addBreadcrumb(__('Puma Embodee Interface'), __('Puma Embodee Interface'));
        $resultPage->addBreadcrumb(__('UD&#x20;Customer&#x20;Records'), __('UD&#x20;Customer&#x20;Records'));
        return $resultPage;
    }
}

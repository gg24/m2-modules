<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\EmbodeeIntegration\Controller\Adminhtml;

abstract class Precartrecord extends \Magento\Backend\App\Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    /**
     * Pre Cart Record repository
     *
     * @var \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface
     */
    protected $precartrecordRepository;

    /**
     * Page factory
     *
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Puma\EmbodeeIntegration\Api\PrecartrecordRepositoryInterface $precartrecordRepository,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->coreRegistry            = $coreRegistry;
        $this->precartrecordRepository = $precartrecordRepository;
        $this->resultPageFactory       = $resultPageFactory;
        parent::__construct($context);
    }
}

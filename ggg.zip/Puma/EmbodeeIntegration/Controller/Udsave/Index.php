<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Udsave;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\Result\JsonFactory;
use Puma\EmbodeeIntegration\Model\Udsaveprocessing;
use Puma\EmbodeeIntegration\Helper\Data;

class Index extends Action
{
    protected $_resultPageFactory;

    /**
     * @var JsonFactory
     */
    protected $jsonFactory;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Udsaveprocessing
     */
    private $udsaveprocessing;
    
    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param JsonHelper $jsonHelper
     * @param JsonFactory $jsonFactory
     */
    public function __construct(
        Udsaveprocessing $udsaveprocessing,
        Context $context,
        JsonFactory $jsonFactory,
        Data $embodeeintegrationhelper
    ) {
    
        $this->udsaveprocessing = $udsaveprocessing;
        $this->jsonFactory = $jsonFactory;
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
        parent::__construct($context);
    }


    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $this->embodeeintegrationhelper->logtofile($data);
        $response = $this->udsaveprocessing->SaveudToMagento($data);
        $result = $this->jsonFactory->create();
        return $result->setData($response);
    }
}

<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller;

class RegistryConstants
{
    /**
     * Registry key where current UD Customer Record ID is stored
     *
     * @var string
     */
    const CURRENT_UDCUSTOMERRECORD_ID = 'current_udcustomerrecord_id';
    /**
     * Registry key where current Pre Cart Record ID is stored
     *
     * @var string
     */
    const CURRENT_PRECARTRECORD_ID = 'current_precartrecord_id';
}

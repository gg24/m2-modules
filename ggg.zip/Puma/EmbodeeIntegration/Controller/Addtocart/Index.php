<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Addtocart;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\Result\JsonFactory;
use Puma\EmbodeeIntegration\Model\Udsaveprocessing;
use Puma\EmbodeeIntegration\Helper\Data;

class Index extends Action
{
    protected $_resultPageFactory;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var JsonFactory
     */
    protected $jsonFactory;
    
    /**
     * @var Udsaveprocessing
     */
    protected $udsaveprocessing;
    
    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param JsonHelper $jsonHelper
     * @param JsonFactory $jsonFactory
     */
    public function __construct(
        JsonFactory $jsonFactory,
        Udsaveprocessing $udsaveprocessing,
        Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        Data $embodeeintegrationhelper
    ) {
    
        $this->jsonFactory = $jsonFactory;
        $this->udsaveprocessing = $udsaveprocessing;
        $this->_resultPageFactory = $resultPageFactory;
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
        parent::__construct($context);
    }


    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $this->embodeeintegrationhelper->logtofile($data);
        $response = $this->udsaveprocessing->AddToCartMagento($data);
        $result = $this->jsonFactory->create();
        return $result->setData($response);
    }
}

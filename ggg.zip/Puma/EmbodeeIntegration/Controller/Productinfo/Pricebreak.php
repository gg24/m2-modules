<?php
/**
 * Puma_EmbodeeIntegration extension
 * @category  Puma
 * @package   Puma_EmbodeeIntegration
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\EmbodeeIntegration\Controller\Productinfo;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\Result\JsonFactory;
use Puma\EmbodeeIntegration\Model\Retriveinfo;
use Puma\EmbodeeIntegration\Helper\Data;

class Pricebreak extends Action
{
    protected $_resultPageFactory;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var JsonFactory
     */
    protected $jsonFactory;


    /**
     * @var Retriveinfo
     */
    private $retriveinfo;
    
    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;


    /**
     * Index constructor.
     *
     * @param Context $context
     * @param JsonHelper $jsonHelper
     * @param JsonFactory $jsonFactory
     */
    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        Retriveinfo $retriveinfo,
        Data $embodeeintegrationhelper
    ) {
    
        $this->jsonFactory = $jsonFactory;
        $this->retriveinfo = $retriveinfo;
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
        parent::__construct($context);
    }


    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $this->embodeeintegrationhelper->logtofile($data);
        $response = $this->retriveinfo->getPriceBreakDown($data);
        $this->embodeeintegrationhelper->logtofile($response);
        $result = $this->jsonFactory->create();
        return $result->setData($response);
    }
}

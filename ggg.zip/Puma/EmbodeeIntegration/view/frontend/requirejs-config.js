var config = {
    map: {
        '*': {
            udsave:      'Puma_EmbodeeIntegration/js/udsave',
            embodeemodal:      'Puma_EmbodeeIntegration/js/embodeemodal',
            designlisting:      'Puma_EmbodeeIntegration/js/designlisting',
        }
    }
};
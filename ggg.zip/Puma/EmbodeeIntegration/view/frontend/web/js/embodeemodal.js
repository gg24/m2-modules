define(
    [
        'jquery',
        'Magento_Ui/js/modal/modal'
    ],
    function ($,modal) {
    return function (opts, el) {
            var savedesign = {
                type: 'popup',
                responsive: true,
                title: 'Design Saved',
            };
            
            $(function () {
                var modalsavedesign = $('.savedesign-modal-content').modal(savedesign);
                $("body").on('click',".open-savedesign-modal",function () {
                    modalsavedesign.modal('openModal');
                });

            });
            
            
            var savedesignwarning = {
                type: 'popup',
                responsive: true,
                title: 'Design Saved',
            };
            
            $(function () {
                var modalsavedesignwarning = $('.savedesignwarning-modal-content').modal(savedesignwarning);
                $("body").on('click',".open-savedesignwarning-modal",function () {
                    modalsavedesignwarning.modal('openModal');
                });

            });
            
            var addtobagwarning = {
                type: 'popup',
                responsive: true,
                title: 'Design Saved',
            };
            
            $(function () {
                var modaladdtobagwarning = $('.addtobagwarning-modal-content').modal(addtobagwarning);
                $("body").on('click',".open-addtobagwarning-modal",function () {
                    modaladdtobagwarning.modal('openModal');
                });

            });
            
            var loginform = {
                type: 'popup',
                responsive: true,
                title: 'Login in',
            };
            
            $(function () {
                var modalloginform = $('.loginform-modal-content').modal(loginform);
                $("body").on('click',".open-loginform-modal",function () {
                     $('.savedesignwarning-modal-content').modal('closeModal');
                    modalloginform.modal('openModal');
                });

            });
            
            
            var downloaddesign = {
                type: 'popup',
                responsive: true,
                title: 'Download Design',
            };
            
            $(function () {
                var modaldownloaddesign = $('.downloaddesign-modal-content').modal(downloaddesign);
                $("body").on('click',".open-downloaddesign-modal",function () {
                    modaldownloaddesign.modal('openModal');
                });
            });

            var logoutuser = {
                type: 'popup',
                responsive: true,
                title: 'You are not currently logged in',
            };
            
            $(function () {
                var modallogoutuser = $('.logoutuser-modal-content').modal(logoutuser);
                  //wait until the last element (#gbuilder-events) being rendered
                  var existCondition = setInterval(function() {
                   if ($('#gbuilder-events').length) { 
                    clearInterval(existCondition);
                    console.log( "ready33!" );
                    modallogoutuser.modal('openModal');
                   }
                  }, 100);
                
            });
    }
    }
);




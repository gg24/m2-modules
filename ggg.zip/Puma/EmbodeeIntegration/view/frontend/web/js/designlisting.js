define([
    "jquery"
], function ($) {
    "use strict";
     return function (opts, el) {

        $('#sort_by').on('change', function () {
                $(this).closest('form').trigger('submit');
        });
        if (opts.udname !='') {
           $('#udname').val(opts.udname);
        }
        if (opts.sort_by !='') {
           $('#sort_by').val(opts.sort_by);
        }
    }
        
});
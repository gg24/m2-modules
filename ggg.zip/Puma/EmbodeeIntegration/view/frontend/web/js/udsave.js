var customer_type = jQuery('.customer-type').text().trim();
var code = jQuery('.sku-ajax').text().trim();
var url = jQuery('.url-ajax').text().trim();
var baseurl = jQuery('.baseurl-ajax').text().trim();
var fileupload = jQuery("#FileUpload1");
var productname = jQuery('.product-name').text().trim();

function selectArtwork(dimensions, callback)
{
    fileupload.click();
    fileupload.change(function () {
        var input = jQuery("#FileUpload1")[0];
        file = input.files[0]
        if (file != undefined) {
            formData = new FormData();
            if (!!file.type.match(/image.*/)) {
                formData.append("image", file);
                jQuery.ajax({
                    url: baseurl+'embodeeintegration/artwork/index',
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (data) {
                        callback(JSON.stringify(data));
                    },
                    error: function (error) {
                        callback('error');
                    }
                });
                jQuery("#FileUpload1").val("");
            } else {
                alert('Not a valid image!');
            }
        }
    });
}

function saveToLocker(name, ud, callback)
{
    jQuery.ajax({
        type: "POST",
        data: {
            "ud_id": ud,
            "product_code": code,
            "name": name,
            "product_url": url
        },
        url: baseurl+'embodeeintegration/udsave/index',
        success: function (response) {
            if (response == 'success') {
                callback(response);
                if (customer_type == 'customer') {
                    jQuery(".open-savedesign-modal").trigger("click");
                } else {
                    jQuery(".open-savedesignwarning-modal").trigger("click");
                }
            } else {
                callback('nomessage');
                jQuery(".open-savedesignwarning-modal").trigger("click");
            }
        },
        error: function (error) {
            callback('error');
        }

    });
}



function addToCart(name, ud, callback)
{
    jQuery.ajax({
        type: "POST",
        data: {
            "ud_id": ud,
            "product_code": code,
            "name": name,
            "product_url": url
        },
        url: baseurl+'embodeeintegration/addtocart/index',
        success: function (response) {
            if (response == 'success') {
                callback(response);
            } else if (response == 'temp') {
                callback('nomessage')
                jQuery(".open-savedesignwarning-modal").trigger("click");
            } else {
                callback('nomessage');
            }
        },
        error: function (error) {
            callback('error');
        }

    });
}

function productInfo(productcode, callback)
{
    jQuery.ajax({
        type: "post",
        data: {
            "product_code": productcode
        },
        url: baseurl+'embodeeintegration/productinfo/index',
        success: function (response) {
            callback(JSON.stringify(response));
        },
        error: function (error) {
            callback('error');
        }

    });
}

function priceBreakDown(productcode, callback)
{
    jQuery.ajax({
        type: "post",
        data: {
            "product_code": productcode
        },
        url: baseurl+'embodeeintegration/productinfo/pricebreak',
        success: function (response) {
            callback(JSON.stringify(response));
        },
        error: function (error) {
            callback('error');
        }

    });
}

function getPriceTiers(productcode, callback)
{
    jQuery.ajax({
        type: "post",
        data: {
            "product_code": productcode
        },
        url: baseurl+'embodeeintegration/productinfo/tierprice',
        success: function (response) {
            callback(JSON.stringify(response));
        },
        error: function (error) {
            callback('error');
        }

    });
}

function getGraphic(callback)
{
    jQuery.ajax({
        type: "post",
        url: baseurl+'embodeeintegration/artwork/graphics',
        success: function (response) {
            if (response != 'error') {
                callback(JSON.stringify(response));
            } else {
                callback('error');
            }
        },
        error: function (error) {
            callback('error');
        }

    });
}

function getStyleNumber(jsondata, callback)
{
    jQuery.ajax({
        type: "post",
        data: {
            "data": jsondata
        },
        url: baseurl + 'embodeeintegration/productinfo/getstyle',
        success: function (response) {
            if (response !== null && response !== '') {
                callback(JSON.stringify(response))
            } else {
                callback('error')
            }
        },
        error: function (error) {
            callback('error');
        }
    });
}

function copyCustomProductLink(ud,callback)
{
    if (ud && url) {
        callback(url+'?ud='+ud);
    } else {
        callback('error');
    }
}

function emailCustomProduct(ud,mailto,mailfrom,content,callback)
{
    jQuery.ajax({
        type: "post",
        data: {
            "ud_id": ud,
            "mailto": mailto,
            "mailfrom": mailfrom,
            "content": content
        },
        url: baseurl+'embodeeintegration/share/email',
        success: function (response) {
            if (response !== null && response !== '') {
                callback(response)
            } else {
                callback('error')
            }
        },
        error: function (error) {
            callback('error');
        }
    });
}

function printCustomProduct(ud)
{
    jQuery('.open-downloaddesign-modal').trigger('click');
    var count = 0;
    jQuery(".initprint").click(function () {
           count++;
           printPDPpdf(ud,count);
    });
}


function printPDPpdf(ud, count)
{
    if (count == 1) {
        jQuery('.close-downloaddesign-modal').trigger('click');
        var url = baseurl + 'embodeeintegration/productinfo/printproduct/ud/' + ud + '/pname/' + productname;
        jQuery("body").append("<iframe src='" + url + "' style='display: none;' ></iframe>");
    } else {
        return;
    }
}
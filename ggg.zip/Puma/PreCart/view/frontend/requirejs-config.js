var config = {
    map: {
        '*': {
            incart:      'Puma_PreCart/js/incart',
            precart:      'Puma_PreCart/js/precart',
            download:      'Puma_PreCart/js/download',
        }
    }
};
define(
    [
        'jquery',
        'Magento_Ui/js/modal/modal',
    ],
    function ($) {
    return function (opts, el) {
        $(".updatepush").click(function () {
            var div = $(this).closest( "article" ).attr("class");                        
            var counter = 0;
            var j = 0;
            var sku = $('.'+div+' .sku-ajax').text().trim();
            var attriId = $('.'+div+' .attri-ajax').text().trim();
            var udname = $('.'+div+' .attri-udname').text().trim();
            var udid = $('.'+div+' .attri-udid').text().trim();
            var udimage = $('.'+div+' .attri-udimage').text().trim();
            var optids = $('.'+div+' .attri-optionids').text().trim();
            var removeids = $('.'+div+' .attri-removeitems').text().trim();
            var effect = function () {
                $('.'+div+' input').each(function () {                            
                            if($(this).val() > 0){
                            counter += 1;
                            }
                });
            return counter;
            };
            $('body').loader('show');
            $.ajax({
                type: "POST",
                data: {
                    "removeitems": removeids
                },
                url: opts.ajaxremoveurl,
                success: function (response) {
                    $.when(effect()).done(function () {
                        if (counter < 1) {
                           location.reload(); }
                    });
                    $('.'+div+' input').each(function () {
                        var name = $(this).attr('name');
                        var val = $(this).val();
                        if (val < 1) {
                            return true; }                        
                        $('body').loader('show');
                        $.ajax({
                            type: "POST",
                            data: {
                                "sku": sku,
                                "key": name,
                                "value": val,
                                "attriId": attriId,
                                "udname": udname,
                                "udid": udid,
                                "udimage": udimage,
                                "optids": optids,
                            },
                            url: opts.ajaxurl,
                            success: function (response) {
                                j++;
                                if (counter === j && counter !== 0) {
                                    location.reload();
                                }
                                return true;
                            },
                            error: function (error) {
                                j++;
                            }
                        });
                    });
                },
                error: function (error) {
                    return false;
                }
            });
        });
        $(".toggle-incart-box").click(function () {
            $(this).siblings(".qty-boxes").toggle();
        });
        $(".toggle-incart-cancel").click(function () {
            $(this).parent().toggle();
        });
        
        var options = {
                    type: 'popup',
                    responsive: true,
                    title: 'Size Guide'
                };
                $(function () {
                    var modal = $('.sizeguide-content').modal(options);
                    $("body").on('click', ".open-sizeguide-in", function () {
                        modal.modal('openModal');
                    });
        });
    }
    }
);

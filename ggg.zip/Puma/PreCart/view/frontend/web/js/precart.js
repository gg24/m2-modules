define(
    [
        'jquery',
        'Magento_Ui/js/modal/modal'
    ],
    function ($,modal) {
    return function (opts, el) {
        var i = 0;
        var j = 0;        
        $(".push").on( "click", function( event ) {
            var div = $( event.target ).closest( "article" ).attr("class");             
            var sku = $('.'+div+' .sku-ajax').text().trim();            
            var attriId = $('.'+div+' .attri-ajax').text().trim();
            var udname = $('.'+div+' .attri-udname').text().trim();
            var udid = $('.'+div+' .attri-udid').text().trim();
            var udimage = $('.'+div+' .attri-udimage').text().trim();
            var optids = $('.'+div+' .attri-optionids').text().trim();
            $('.'+div+' input').each(function () {
                var name = $(this).attr('name');
                var val = $(this).val();
                if (val < 1) {
                    return true; }
                i++;
                $('body').loader('show');
                $.ajax({
                    type: "POST",
                    data: {
                        "sku": sku,
                        "key": name,
                        "value": val,
                        "attriId": attriId,
                        "udname": udname,
                        "udid": udid,
                        "udimage": udimage,
                        "optids": optids
                    },
                    url: opts.ajaxurl,
                    success: function (response) {
                        j++;
                        if (i === j && i !== 0) {
                        location.reload();
                        }
                        return true;
                    },
                    error: function (error) {
                        j++;
                    }
                });
            });
        });      
        
                var options = {
                    type: 'popup',
                    responsive: true,
                    title: 'Size Guide'
                };
                $(function () {
                    var modal = $('.sizeguide-content').modal(options);
                    $("body").on('click', ".open-sizeguide-pre", function () {
                        modal.modal('openModal');
                    });
                });
    }
    }
);

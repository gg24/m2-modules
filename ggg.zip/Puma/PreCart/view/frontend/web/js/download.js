define(
    [
        'jquery',
        'Magento_Ui/js/modal/modal',
    ],
    function ($) {
    return function (opts, el) {

        var udid = [];
        var udname = [];
        var uddetails = [];
        
        $("#download").click(function () {
            var url = opts.downloadurl;
           
            $('.attri-udid').each(function () {
                udid.push($(this).text().trim());
            });
           
            udid = jQuery.unique(udid);
            
            $('.attri-udname').each(function () {
                udname.push($(this).text().trim());
            });
           
            udname = jQuery.unique(udname);
            
            $('.attri-details').each(function () {
                uddetails.push($(this).text().trim());
            });
            
            uddetails = jQuery.unique(uddetails);
            
            var callurl = url+'/uddetails/' + uddetails;
            
            jQuery("body").append("<iframe src='" + callurl + "' style='display: none;' ></iframe>");
            

               });
          }
    }
);

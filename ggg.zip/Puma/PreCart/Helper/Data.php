<?php

/**
 * Puma_PreCart extension
 * @category  Puma
 * @package   Puma_PreCart
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\PreCart\Helper;

use Magento\Catalog\Model\ProductFactory;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable as ConfigurableProTypeModel;
use Magento\Catalog\Api\ProductCustomOptionRepositoryInterface;
use Magento\Catalog\Model\ProductRepository;
use Magento\Checkout\Model\Cart;
use Puma\EmbodeeIntegration\Helper\Data as Embodeeintdata;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    /**
     * @var \Magento\ConfigurableProduct\Model\Product\Type\Configurable
     */
    private $_configurableProTypeModel;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    private $_productFactory;

    /**
     * @var ProductCustomOptionRepositoryInterface
     */
    private $_productoptRepository;

    /**
     * @var ProductRepository
     */
    private $_productRepository;

    /**
     * Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;


    /**
     * @param ConfigurableProTypeModel $configurableProTypeModel ,
     * @param Product $product ,
     */
    public function __construct(
        ConfigurableProTypeModel $configurableProTypeModel,
        ProductFactory $productfactory,
        ProductCustomOptionRepositoryInterface $productoptrepository,
        ProductRepository $productRepository,
        Cart $cart,
        \Magento\Framework\Pricing\Helper\Data $priceData,
        Embodeeintdata $embodeeintegrationhelper
    ) {
    
        $this->_configurableProTypeModel = $configurableProTypeModel;
        $this->_productFactory = $productfactory;
        $this->_productoptRepository = $productoptrepository;
        $this->_productRepository = $productRepository;
        $this->cart = $cart;
        $this->_priceData = $priceData;
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
    }

    /**
     * return Congigurable associated product id.
     * @param object $productId
     * @return bool|int
     */
    public function getConfAssoOptions($productSku)
    {
        $assocateProId = false;
        $superAttrOptions = [];
        $customoptions = [];
        $type = [];
        //load product
        $product = $this->_productFactory->create()->loadByAttribute('sku', $productSku);
        //get configurable products attributes array with all values with lable (supper attribute which use for configuration)
        if ($product && $product->getTypeId() == 'configurable') {
            $optionsData = $product->getTypeInstance(true)->getConfigurableAttributesAsArray($product);
            $options = $this->_productoptRepository->getProductOptions($product);
            foreach ($options as $optiondata) {
                $customoptions[] = $optiondata['option_id'];
            }
            // prepare array with attribute values
            foreach ($optionsData as $option) {
                foreach ($option['options'] as $attrOpt) {
                    $attributeValues[$option['attribute_id']] = $attrOpt['value'];
                    $assPro = $this->_configurableProTypeModel->getProductByAttributes($attributeValues, $product);
                    if (!$assPro) {
                        continue;
                    }
                    $assocateProId = $assPro->getEntityId();
                    $assProduct = $this->_productRepository->getById($assocateProId);

                    $jrw = $assProduct->getResource()->getAttribute('jrw')->getFrontend()->getValue($assProduct);
                    $arr = ['jrw' => $jrw];
                    if (in_array($jrw, $type)) {
                        $type[] = $jrw;
                        $newoptions[] = array_merge($arr, $attrOpt);
                    } else {
                        $type[] = $jrw;
                        $newoptions = [];
                        $newoptions[] = array_merge($arr, $attrOpt);
                    }
                    $superAttrOptions[$option['attribute_id']][$jrw] = $newoptions;
                }
            }
            return [$superAttrOptions, $customoptions];
        } else {
            return [$superAttrOptions, $customoptions];
        }
    }


    /**
     * @return array
     */
    public function getPdfCartItems()
    {

        $cartiemcollection = $this->cart->getQuote()->getAllVisibleItems();
        if ($cartiemcollection && count($cartiemcollection)) :
            foreach ($cartiemcollection as $item) {
                /* This will get custom option value of cart item */
                $_customOptions = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
                $udid = '';
                $udimage = '';
                $udname = '';
                /* Each custom option loop */
                if (isset($_customOptions['options'])) {
                    foreach ($_customOptions['options'] as $_option) {
                        if ($_option['label'] == 'UD ID') {
                            $udid = $_option['value'];
                        } elseif ($_option['label'] == 'UD Image') {
                            $udimage = $_option['value'];
                        } elseif ($_option['label'] == 'UD Name') {
                            $udname = $_option['value'];
                        } else {
                            continue;
                        }
                    }
                } else {
                    $udid = $item->getId();
                    $udimage = $this->getBaseUrl() . 'media/catalog/product' . $item->getProduct()->getImage();
                    $udname = $item->getSku();
                }
                $cartdata[$udid][$item['product']['sku']][$item->getSku()] = $item->getQty();
                $cartdataremove[$item['product']['sku']][$udid][$item->getSku()] = $item->getId();
                $cartitemimage[$item['product']['sku']][$udid] = $udimage;
                $cartitemname[$item['product']['sku']][$udid] = $udname;
            } 
else :
                $cartdata = '';
                $cartdataremove = '';
                $cartitemimage = '';
                $cartitemname = '';
        endif;
            return [$cartdata, $cartdataremove, $cartitemimage, $cartitemname];
    }


    /**
     *
     * @return summary array
     */
    public function getCartSummary()
    {
        $cartSummary = [];
        $quote = $this->cart->getQuote();
        $cartSummary['subtotal'] = $this->_priceData->currency($quote->getSubtotal(), true, false);
        $cartSummary['grandtotal'] = $this->_priceData->currency($quote->getGrandTotal(), true, false);
        $cartSummary['tax'] = $this->_priceData->currency($quote->getTaxAmount(), true, false);

        return [$cartSummary];
    }
}

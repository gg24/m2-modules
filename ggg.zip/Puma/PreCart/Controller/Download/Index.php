<?php

/**
 * Puma_PreCart extension
 * @category  Puma
 * @package   Puma_PreCart
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\PreCart\Controller\Download;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Catalog\Model\ProductRepository;
use Magento\Checkout\Model\Cart;
use Magento\Framework\Data\Form\FormKey;
use Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\CollectionFactory;
use Puma\EmbodeeIntegration\Helper\Data;

class Index extends Action
{

    protected $_resultPageFactory;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var JsonFactory
     */
    protected $jsonFactory;

    /**
     * Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;

    /**
     *
     * @var CollectionFactory
     */
    protected $_precartcollectionFactory;

    /**
     * @var helperdata
     */
    protected $helperdata;

    /**
     * @var \Magento\Framework\HTTP\Client\Curl
     */
    protected $_curl;

    /**
     * @var Filesystem
     */
    protected $fileSystem;

    /**
     * @var \Magento\Framework\View\Asset\Repository
     */
    protected $assetRepository;

    protected $customerSession;
    protected $_resourceConnection;

    /**
     * @var \Magento\Authorization\Model\UserContextInterface
     */
    private $userContext;

    /**
     * @var \Magento\Company\Api\CompanyManagementInterface
     */
    private $companyManagement;

    /**
     * @var \Magento\User\Model\UserFactory
     */
    private $userFactory;

    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;


    /**
     * Index constructor.
     *
     * @param Context $context
     * @param JsonHelper $jsonHelper
     * @param JsonFactory $jsonFactory
     */
    public function __construct(
        Cart $cart,
        ProductRepository $productRepository,
        Context $context,
        JsonFactory $jsonFactory,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        FormKey $formKey,
        CollectionFactory $precartcollectionFactory,
        \Magento\Framework\View\Asset\Repository $assetRepository,
        \Puma\EmbodeeIntegration\Helper\Data $helperdata,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Authorization\Model\UserContextInterface $userContext,
        \Magento\Company\Api\CompanyManagementInterface $companyManagement,
        \Magento\User\Model\UserFactory $userFactory,
        \Puma\PreCart\Helper\Data $dataHelper,
        \Magento\Framework\Pricing\Helper\Data $priceData,
        Data $embodeeintegrationhelper
    ) {
    
        $this->jsonFactory = $jsonFactory;
        $this->cart = $cart;
        $this->productRepository = $productRepository;
        $this->_resultPageFactory = $resultPageFactory;
        $this->formKey = $formKey;
        $this->_precartcollectionFactory = $precartcollectionFactory;
        $this->assetRepository = $assetRepository;
        $this->helperdata = $helperdata;
        $this->_curl = $curl;
        $this->fileSystem = $filesystem;
        $this->customerSession = $customerSession;
        $this->_resourceConnection = $resourceConnection;
        $this->userContext = $userContext;
        $this->companyManagement = $companyManagement;
        $this->userFactory = $userFactory;
        $this->dataHelper = $dataHelper;
        $this->_priceData = $priceData;
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
        parent::__construct($context);
    }


    private function firstpdfpage($udDetail)
    {

        $udDetails = explode('-', $udDetail);
        $ud = $udDetails[0];

        $embodeUrl = $this->helperdata->getGeneralConfig('embourl');
        $fullEmbodeUrl = $embodeUrl . '/builder/ud/image/' . $ud . '/custom/900,900,jpg,1';
        $tempFile = [];
        $varPath = $this->fileSystem->getDirectoryWrite(DirectoryList::TMP)->getAbsolutePath();

        $fileId = 'Puma_EmbodeeIntegration::images/puma-logo.png';
        $params = [
            'area' => 'frontend'
        ];

        $asset = $this->assetRepository->createAsset($fileId, $params);
        try {
            $mediapath = $asset->getSourceFile();
        } catch (\Exception $e) {
            return null;
        }


        $this->_curl->get($fullEmbodeUrl);
        $response = $this->_curl->getBody();

        if ($response !== false) {
            $directory = $this->fileSystem->getDirectoryWrite(
                DirectoryList::TMP
            );

            $image = @imagecreatefromstring($response);
            if (!$image) {
                return false;
            }

            $tmpFileName = $directory->getAbsolutePath(
                'embodee_' . uniqid(\Magento\Framework\Math\Random::getRandomNumber()) . time() . '.jpg'
            );

            imagejpeg($image, $tmpFileName);
            $tempFile[] = $tmpFileName;
            $strImage = '<img src="' . $tmpFileName . '" alt="">';


            $strFirstPage = '<div style="margin:0px auto; width:100%;max-width:630px;padding:25px;">
                    <h1 style="font-size:28px;line-height:28px;color:#000000;margin:0px;font-family:ff-din-for-puma,serif;">Your Puma Kit</h1>
                    <h1 style="font-size:28px;line-height:28px;color:#000000;margin-top: 7px;font-family:ff-din-for-puma,serif;">Designer Quote</h1>


                    <div style="margin-top:30px;">
                        <div style="width:440px; margin:0px auto;border-bottom:8px solid #000000;background: #f7f7f7;padding:12px; text-align:center;">         
                            <img src="' . $tmpFileName . '" alt="">
                        </div>
                    </div>
                    <div style="text-align:right;clear:both;margin-top: 40px;">
                        <img src="' . $mediapath . '" alt="">
                    </div>
                </div>';
        } else {
            $this->embodeeintegrationhelper->logtofile(curl_error($response));
        }

        $strFirstHtml = ['strfirstpage' => $strFirstPage, 'filename' => $tempFile];
        return $strFirstHtml;
    }

    private function thirdpdfpage($dataud)
    {

        $tempFile = [];
        $udArray = [];
        $udArr = [];
        $html = '';
        $k = 0;
        foreach ($dataud as $ud) {
            $udid = explode('-', $ud);
            for ($i = 0; $i < count($udid); $i++) {
                if ($udid[$i] == $udid[$k]) {
                    if (!in_array($udid[$i], $udArray)) {
                        $udArray[] = $udid[$i];
                        $udArr[] = $udid[$i] . '-' . $udid[$k + 1];
                    }
                }
            }
        }


        foreach ($udArr as $ud) {
            $udDetails = explode('-', $ud);

            $udID = $udDetails[0];
            $productSku = $udDetails[1];
            $_product = $this->productRepository->get($productSku);

            $embodeUrl = $this->helperdata->getGeneralConfig('embourl');
            $totalImageCount = 5;

            $varPath = $this->fileSystem->getDirectoryWrite(DirectoryList::TMP)->getAbsolutePath();

            $fileId = 'Puma_EmbodeeIntegration::images/puma-logo.png';
            $params = [
                'area' => 'frontend'
            ];

            $asset = $this->assetRepository->createAsset($fileId, $params);
            try {
                $mediapath = $asset->getSourceFile();
            } catch (\Exception $e) {
                return null;
            }


            $htmlHeader = '<pagebreak /><div style="margin:0px auto; width:100%;max-width:630px;padding:25px;">
            <h1 style="font-size:28px;line-height:28px;color:#000000;margin:0px;font-family:ff-din-for-puma,serif;">' . $_product->getName() . '  ' . $udID . '</h1>
            
            <div style="margin-top:30px;">
                <div style="width:436px; margin:0px auto;border-bottom:8px solid #000000;background: #f7f7f7;padding:12px;">';


            for ($i = 0; $i < $totalImageCount; $i++) {
                if ($i == 0) {
                    $fullEmbodeUrl = $embodeUrl . '/builder/ud/image/' . $udID . '/custom/254,263,jpg,1';
                }
                if ($i == 1) {
                    $fullEmbodeUrl = $embodeUrl . '/builder/ud/image/' . $udID . '/custom/158,179,jpg,5';
                }
                if ($i == 2) {
                    $fullEmbodeUrl = $embodeUrl . '/builder/ud/image/' . $udID . '/custom/122,181,jpg,7';
                }
                if ($i == 3) {
                    $fullEmbodeUrl = $embodeUrl . '/builder/ud/image/' . $udID . '/custom/122,181,jpg,3';
                }
                if ($i == 4) {
                    $fullEmbodeUrl = $embodeUrl . '/builder/ud/image/' . $udID . '/custom/158,265,jpg,5';
                }

                $this->_curl->get($fullEmbodeUrl);
                $response = $this->_curl->getBody();

                if ($response !== false) {
                    $directory = $this->fileSystem->getDirectoryWrite(
                        DirectoryList::TMP
                    );


                    $directory->create();
                    $image = @imagecreatefromstring($response);
                    if (!$image) {
                        return false;
                    }

                    $xSize = imagesx($image);
                    $ySize = imagesy($image);
                    //imageinterlace($image, 0);
                    $tmpFileName = $directory->getAbsolutePath(
                        'embodee_' . uniqid(\Magento\Framework\Math\Random::getRandomNumber()) . time() . '.jpg'
                    );
                    //imagepng($image, $tmpFileName);
                    imagejpeg($image, $tmpFileName);
                    $tempFile[] = $tmpFileName;
                    if ($i == 0) {
                        $htmlImage0 = '<img src="' . $tmpFileName . '" alt="" style="margin: 5px;vertical-align:top;">';
                    }
                    if ($i == 1) {
                        $htmlImage1 = '<img src="' . $tmpFileName . '" alt=""  style="margin: 5px;vertical-align:top;">';
                    }
                    if ($i == 2) {
                        $htmlImage2 = '<img src="' . $tmpFileName . '" alt=""  style="margin: 5px;vertical-align:top;">';
                    }
                    if ($i == 3) {
                        $htmlImage3 = '<img src="' . $tmpFileName . '" alt=""  style="margin: 5px;vertical-align:top;">';
                    }
                    if ($i == 4) {
                        $htmlImage4 = '<img src="' . $tmpFileName . '" alt="" style="display: inline-block;margin: 5px;margin-bottom: 0px;margin-top:-79px;">';
                    }
                } else {
                    $this->embodeeintegrationhelper->logtofile(curl_error($response));
                }
            }


            $htmlFooter = '</div>
                </div>
                <div style="text-align:right;clear:both;margin-top: 40px;">
                    <img src="' . $mediapath . '" alt="">
                </div>
            </div>';
            $htmlImage = $htmlImage0 . $htmlImage1 . $htmlImage2 . $htmlImage3 . $htmlImage4;
            $html .= $htmlHeader . $htmlImage . $htmlFooter;
        }
        $strThirdHtml = ['strthirdpage' => $html, 'filename' => $tempFile];
        return $strThirdHtml;
    }

    public function execute()
    {

        $fileId = 'Puma_PreCart::css/pdf.css';
        $params = [
            'area' => 'frontend'
        ];

        $asset = $this->assetRepository->createAsset($fileId, $params);
        try {
            $csspath = $asset->getSourceFile();
        } catch (\Exception $e) {
            return null;
        }

        $data = $this->getRequest()->getParams();
        $params = explode(',', $data['uddetails']);

        $varPath = $this->fileSystem->getDirectoryWrite(DirectoryList::TMP)->getAbsolutePath();
        $mpdf = new \Mpdf\Mpdf(['tempDir' => $varPath]);

        $customerId = $this->customerSession->getCustomerId();
        if ($customerId) {
            $company = $this->companyManagement->getByCustomerId($customerId);
        }

        if ($company) {
            $salesRepresentative = $this->userFactory->create()->load($company->getSalesRepresentativeId());
        }

        $cartSummary = $this->dataHelper->getCartSummary();
        $cartdata = $this->dataHelper->getPdfCartItems();


        $firstPageHtml = $this->firstpdfpage($params[0]);
        $firstPage = $firstPageHtml['strfirstpage'];

        $strSecondPage = '<pagebreak /><div class="main-section">  

        <div class="header-section marginB40">
            <div class="col-3">
                <div>Company Name:</div>
                <div>' . $company->getCompanyName() . '</div>
            </div>
            <div class="col-3">
                <div>Sales Rep:</div>
                <div>' . $salesRepresentative->getName() . '</div>
            </div>
            <div class="col-3">
                <div>Date:</div>
                <div>' . date('j/n/Y ') . '</div>
            </div>
            <div class="clearfix"></div>
        </div>';

        if ($cartdata[0] && count($cartdata[0])) {
            foreach ($cartdata[0] as $ud => $prods) {
                foreach ($prods as $pro => $sizes) {
                    $_product = $this->productRepository->get($pro);
                    $strSecondPage .= '<div class="content-section clearfix">
            
            <div class="table-row clearfix">
                <div class="table-head border-top">
                    <div>' . $pro . '</div>
                    <div>' . $_product->getName() . '</div>
                    <div>Design: ' . $cartdata[3][$pro][$ud] . ' (' . $ud . ')</div>
                </div>
                <div class="table-content">         
                    <table class="pricing-table">
                        <thead>
                            <tr>
                                <th>Size</th>
                                <th>Price</th>
                                <th>Qty</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>';

                    foreach ($sizes as $sku => $qty) {
                        $itemproduct = $this->productRepository->get($sku);
                        $label = $itemproduct->getResource()->getAttribute('size')->getFrontend()->getValue($itemproduct);
                        $itemprice = $itemproduct->getPrice();
                        $timeTotalPrice = $itemprice * $qty;

                        $strSecondPage .= '<tr>
                                    <td>' . $label . '</td>
                                    <td>' . $this->_priceData->currency($itemprice, true, false) . '</td>
                                    <td>' . $qty . '</td>
                                    <td>' . $this->_priceData->currency($timeTotalPrice, true, false) . '</td>
                                </tr>';
                    }

                    $strSecondPage .= '
                         </tbody>
                    </table>
                </div>
            </div>';
                }
            }
        }

        $strSecondPage .= ' <div class="footer-section border-top">
            <table class="pricing-table-tfoot">
                 <tr>
                    <td>Subtotal</td>
                    <td>' . $cartSummary[0]['subtotal'] . '</td>
                </tr>
                <tr>
                    <td>VAT</td>
                    <td>' . $cartSummary[0]['tax'] . '</td>
                </tr>
                <tr>
                    <td>Grand total</td>
                    <td>' . $cartSummary[0]['grandtotal'] . '</td>
                </tr>
            </table>
        </div>
    </div>';


        $thirdPageHtml = $this->thirdpdfpage($params);
        $thirdPage = $thirdPageHtml['strthirdpage'];

        $html = $firstPage . $strSecondPage . $thirdPage;
        $stylesheet = file_get_contents($csspath); // external css
        $mpdf->WriteHTML($stylesheet, 1);

        $mpdf->WriteHTML($html, 2);

        $mpdf->Output('basket.pdf', 'D');

        $firstPageFile = $firstPageHtml['filename'];

        $thirdPageFile = $thirdPageHtml['filename'];
        if (count($firstPageFile) > 0) {
            foreach ($firstPageFile as $temp) {
                unlink($temp);
            }
        }
        if (count($thirdPageFile) > 0) {
            foreach ($thirdPageFile as $temp) {
                unlink($temp);
            }
        }
    }
}

<?php

/**
 * Puma_PreCart extension
 * @category  Puma
 * @package   Puma_PreCart
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\PreCart\Controller\Remove;

use Magento\Framework\App\Action\Context;
use Puma\EmbodeeIntegration\Model\PrecartrecordRepository;
use Magento\Framework\Controller\ResultFactory;

class Index extends \Magento\Framework\App\Action\Action
{
    protected $_resultPageFactory;
    protected $_precartrecordRepository;
    protected $_resultFactory;

    public function __construct(
        Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        PrecartrecordRepository $precartrecordFactory
    ) {
    


        $this->_precartrecordRepository = $precartrecordFactory;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $this->_precartrecordRepository->deleteById($data['id']);
        $this->_redirect($this->_redirect->getRefererUrl());
    }
}

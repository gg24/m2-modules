<?php

/**
 * Puma_PreCart extension
 * @category  Puma
 * @package   Puma_PreCart
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\PreCart\Controller\Add;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Catalog\Model\ProductRepository;
use Magento\Checkout\Model\Cart;
use Magento\Framework\Data\Form\FormKey;
use Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\CollectionFactory;
use Puma\EmbodeeIntegration\Helper\Data;

class Index extends Action
{

    protected $_resultPageFactory;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var JsonFactory
     */
    protected $jsonFactory;

    /**
     * Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;

    /**
     *
     * @var CollectionFactory
     */
    protected $_precartcollectionFactory;

    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param JsonHelper $jsonHelper
     * @param JsonFactory $jsonFactory
     */
    public function __construct(
        Cart $cart,
        ProductRepository $productRepository,
        Context $context,
        JsonFactory $jsonFactory,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        FormKey $formKey,
        CollectionFactory $precartcollectionFactory,
        Data $embodeeintegrationhelper
    ) {
    
        $this->jsonFactory = $jsonFactory;
        $this->cart = $cart;
        $this->productRepository = $productRepository;
        $this->_resultPageFactory = $resultPageFactory;
        $this->formKey = $formKey;
        $this->_precartcollectionFactory = $precartcollectionFactory;
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
        parent::__construct($context);
    }

    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $this->embodeeintegrationhelper->logtofile($data);
        $optids = explode(',', $data['optids']);
        $params = [
            'product' => $data['sku'], //product Id
            'qty' => $data['value'], //quantity of product
            'super_attribute' => [
                $data['attriId'] => $data['key']
            ],
            'options' => [
                $optids[0] => $data['udname'],
                $optids[1] => $data['udid'],
                $optids[2] => $data['udimage']
            ]
        ];
        $this->embodeeintegrationhelper->logtofile($params);
        $_product = $this->productRepository->get($data['sku']);
        $this->cart->addProduct($_product, $params);
        try {
            $this->cart->save();
            $todelete = $this->_precartcollectionFactory->create()->addFieldToSelect(
                '*'
            )->addFieldToFilter(
                'sku',
                ['eq' => $data['sku']]
            )->addFieldToFilter(
                'ud_id',
                ['eq' => $data['udid']]
            );

            foreach ($todelete as $delete) {
                $delete->delete();
            }
            $result = $this->jsonFactory->create();
            return $result->setData('success');
        } catch (\Exception $e) {
            $this->embodeeintegrationhelper->logtofile($e->getMessage());
            $result = $this->jsonFactory->create();
            return $result->setData('error');
        }
    }
}

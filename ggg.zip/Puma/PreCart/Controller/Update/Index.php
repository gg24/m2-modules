<?php

/**
 * Puma_PreCart extension
 * @category  Puma
 * @package   Puma_PreCart
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\PreCart\Controller\Update;

use Magento\Framework\App\Action\Context;
use Magento\Checkout\Model\Cart;
use Magento\Framework\Controller\ResultFactory;
use Puma\EmbodeeIntegration\Helper\Data;

class Index extends \Magento\Framework\App\Action\Action
{
    /**
     *
     * @var ResultFactory
     */
    protected $_resultPageFactory;
    /**
     *
     * @var Item
     */
    protected $_item;

    /**
     * Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var Helper
     */
    protected $embodeeintegrationhelper;


    public function __construct(
        Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        Cart $cart,
        Data $embodeeintegrationhelper
    ) {
    


        $this->_resultPageFactory = $resultPageFactory;
        $this->cart = $cart;
        $this->embodeeintegrationhelper = $embodeeintegrationhelper;
        parent::__construct($context);
    }

    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $this->embodeeintegrationhelper->logtofile($data);
    }
}

<?php

/**
 * Puma_PreCart extension
 * @category  Puma
 * @package   Puma_PreCart
 * @copyright Copyright (c) 2018
 * @author    Prashant Chaudhary
 */

namespace Puma\PreCart\Block;

use Puma\EmbodeeIntegration\Model\ResourceModel\Precartrecord\CollectionFactory;
use Magento\Customer\Model\Session;
use Puma\PreCart\Helper\Data;
use Magento\Framework\View\Element\Template\Context;
use Magento\Catalog\Model\ProductRepository;
use Magento\Checkout\Model\Cart;
use Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable;

class PreCart extends \Magento\Framework\View\Element\Template
{

    /**
     * @var PrecartrecordFactory
     */
    protected $_precartcollectionFactory;

    /**
     * @var $session
     */
    protected $_customerSession;

    /**
     * @var $precartlist
     */
    protected $precartlist;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var Configurable
     */
    protected $_catalogProductTypeConfigurable;

    /**
     * PreCart constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param PrecartrecordFactory $precartrecordFactory
     * @param Session $customerSession
     * @param array $data
     */
    public function __construct(
        Context $context,
        Cart $cart,
        Configurable $catalogProductTypeConfigurable,
        CollectionFactory $precartrecordFactory,
        ProductRepository $productRepository,
        Session $customerSession,
        Data $dataHelper,
        \Magento\Framework\Pricing\Helper\Data $priceData,
        array $data = []
    )
    {
        $this->_precartcollectionFactory = $precartrecordFactory;
        $this->cart = $cart;
        $this->_catalogProductTypeConfigurable = $catalogProductTypeConfigurable;
        $this->productRepository = $productRepository;
        $this->_customerSession = $customerSession;
        $this->dataHelper = $dataHelper;
        $this->_priceData = $priceData;
        parent::__construct($context, $data);
        //get collection of data
    }

    /**
     * @return CollectionFactoryInterface
     */
    private function getPrecartCollectionFactory()
    {
        if ($this->_precartcollectionFactory === null) {
            $this->_precartcollectionFactory = ObjectManager::getInstance()->get(CollectionFactoryInterface::class);
        }
        return $this->_precartcollectionFactory;
    }

    public function getPrecartList()
    {

        if (!($customerId = $this->_customerSession->getCustomerId())) {
            return false;
        }
        if (!$this->precartlist) {
            $this->precartlist = $this->getPrecartCollectionFactory()->create()->addFieldToSelect(
                '*'
            )->addFieldToFilter(
                'user_id', ['eq' => $customerId]
            );
        }
        return $this->precartlist;
    }

    public function getProductName($sku)
    {
        $product = $this->productRepository->get($sku);
        return $product->getName();
    }

    public function getProductPrice($sku)
    {
        $product = $this->productRepository->get($sku);
        return $this->_priceData->currency($product->getFinalPrice(), true, false);
    }

    /**
     * @return array
     */
    public function getCartItems()
    {
        if (!($customerId = $this->_customerSession->getCustomerId())) {
            return false;
        }
        $cartiemcollection = $this->cart->getQuote()->getAllVisibleItems();
        if ($cartiemcollection && count($cartiemcollection)):
            foreach ($cartiemcollection as $item) {
                /* This will get custom option value of cart item */
                $_customOptions = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
                $udid = '';
                $udimage = '';
                $udname = '';
                /* Each custom option loop */
                if (isset($_customOptions['options'])) {
                    foreach ($_customOptions['options'] as $_option) {
                        if ($_option['label'] == 'UD ID') {
                            $udid = $_option['value'];
                        } elseif ($_option['label'] == 'UD Image') {
                            $udimage = $_option['value'];
                        } elseif ($_option['label'] == 'UD Name') {
                            $udname = $_option['value'];
                        } else {
                            continue;
                        }
                    }
                } else {
                    $udid = $item->getId();
                    $udimage = $this->getBaseUrl() . 'media/catalog/product' . $item->getProduct()->getImage();
                    $udname = $item->getSku();
                }
                $cartdata[$udid][$item['product']['sku']][$item->getSku()] = $item->getQty();
                $cartdataremove[$item['product']['sku']][$udid][$item->getSku()] = $item->getId();
                $cartitemimage[$item['product']['sku']][$udid] = $udimage;
                $cartitemname[$item['product']['sku']][$udid] = $udname;
            }
        else:
            $cartdata = '';
            $cartdataremove = '';
            $cartitemimage = '';
            $cartitemname = '';
        endif;
        return array($cartdata, $cartdataremove, $cartitemimage, $cartitemname);
    }

    /**
     *
     * @param  $id
     * @return array
     */
    public function getParentProductSku($id)
    {
        $product = $this->productRepository->get($id);
        return $product;
    }

    /**
     *
     * @return summary array
     */
    public function getCartSummary()
    {
        if (!($customerId = $this->_customerSession->getCustomerId())) {
            return false;
        }
        $quote = $this->cart->getQuote();
        $subtotal = $this->_priceData->currency($quote->getSubtotal(), true, false);
        $total = $this->_priceData->currency($quote->getGrandTotal(), true, false);
        $shipping = $this->_priceData->currency($quote->getShippingAddress()->getShippingAmount(), true, false);
        return array($subtotal, $total, $shipping);
    }

    /**
     * @return string
     */
    public function getBanner()
    {
        return "Sample Banner";
    }

    /**
     * @return additional information data
     */
    public function getAdditionalData($sku)
    {
        // Do your code here
        return $this->dataHelper->getConfAssoOptions($sku);
    }

}

<?php
/**
 * Puma_ListingFilter extension
 * @category  Puma
 * @package   Puma_ListingFilter
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\ListingFilter\Api;

/**
 * @api
 */
interface GridRepositoryInterface
{
    /**
     * Save Grid.
     *
     * @param \Puma\ListingFilter\Api\Data\GridInterface $grid
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(\Puma\ListingFilter\Api\Data\GridInterface $grid);

    /**
     * Retrieve Grid
     *
     * @param int $entityId
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($entityId);

    /**
     * Retrieve Grids matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Puma\ListingFilter\Api\Data\GridSearchResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    /**
     * Delete Grid.
     *
     * @param \Puma\ListingFilter\Api\Data\GridInterface $grid
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Puma\ListingFilter\Api\Data\GridInterface $grid);

    /**
     * Delete Grid by ID.
     *
     * @param int $entityId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($entityId);
}

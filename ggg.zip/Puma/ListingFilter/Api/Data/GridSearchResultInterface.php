<?php
/**
 * Puma_ListingFilter extension
 * @category  Puma
 * @package   Puma_ListingFilter
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\ListingFilter\Api\Data;

/**
 * @api
 */
interface GridSearchResultInterface
{
    /**
     * Get Grids list.
     *
     * @return \Puma\ListingFilter\Api\Data\GridInterface[]
     */
    public function getItems();

    /**
     * Set Grids list.
     *
     * @param \Puma\ListingFilter\Api\Data\GridInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

<?php
/**
 * Puma_ListingFilter extension
 * @category  Puma
 * @package   Puma_ListingFilter
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\ListingFilter\Api\Data;

/**
 * @api
 */
interface GridInterface
{
    /**
     * ID
     *
     * @var string
     */
    const GRID_ID = 'entity_id';

    /**
     * Quote Name attribute constant
     *
     * @var string
     */
    const QUOTE_NAME = 'quote_name';

    /**
     * Company ID attribute constant
     *
     * @var string
     */
    const COMPANY_ID = 'company_id';

    /**
     * Company Name attribute constant
     *
     * @var string
     */
    const COMPANY_NAME = 'company_name';

    /**
     * Customer Id attribute constant
     *
     * @var string
     */
    const CUSTOMER_ID = 'customer_id';

    /**
     * Submited By attribute constant
     *
     * @var string
     */
    const SUBMUTED_BY = 'submuted_by';

    /**
     * Sales Rep Id attribute constant
     *
     * @var string
     */
    const SALES_REP_ID = 'sales_rep_id';

    /**
     * Sales Rep attribute constant
     *
     * @var string
     */
    const SALES_REP = 'sales_rep';

    /**
     * Base Grand Total attribute constant
     *
     * @var string
     */
    const BASE_GRAND_TOTAL = 'base_grand_total';

    /**
     * Grand Total attribute constant
     *
     * @var string
     */
    const GRAND_TOTAL = 'grand_total';

    /**
     * Base Negotiated Grand Total attribute constant
     *
     * @var string
     */
    const BASE_NEGOTIATED_GRAND_TOTAL = 'base_negotiated_grand_total';

    /**
     * Negotiated Grand Total attribute constant
     *
     * @var string
     */
    const NEGOTIATED_GRAND_TOTAL = 'negotiated_grand_total';

    /**
     * Status attribute constant
     *
     * @var string
     */
    const STATUS = 'status';

    /**
     * Base_currency_code attribute constant
     *
     * @var string
     */
    const BASE_CURRENCY_CODE = 'base_currency_code';

    /**
     * Quote_currency_code attribute constant
     *
     * @var string
     */
    const QUOTE_CURRENCY_CODE = 'quote_currency_code';

    /**
     * Store_id attribute constant
     *
     * @var string
     */
    const STORE_ID = 'store_id';

    /**
     * Rate attribute constant
     *
     * @var string
     */
    const RATE = 'rate';

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getEntityId();

    /**
     * Set ID
     *
     * @param int $entityId
     * @return GridInterface
     */
    public function setEntityId($entityId);

    /**
     * Get Quote Name
     *
     * @return mixed
     */
    public function getQuoteName();

    /**
     * Set Quote Name
     *
     * @param mixed $quoteName
     * @return GridInterface
     */
    public function setQuoteName($quoteName);

    /**
     * Get Company ID
     *
     * @return mixed
     */
    public function getCompanyId();

    /**
     * Set Company ID
     *
     * @param mixed $companyId
     * @return GridInterface
     */
    public function setCompanyId($companyId);

    /**
     * Get Company Name
     *
     * @return mixed
     */
    public function getCompanyName();

    /**
     * Set Company Name
     *
     * @param mixed $companyName
     * @return GridInterface
     */
    public function setCompanyName($companyName);

    /**
     * Get Customer Id
     *
     * @return mixed
     */
    public function getCustomerId();

    /**
     * Set Customer Id
     *
     * @param mixed $customerId
     * @return GridInterface
     */
    public function setCustomerId($customerId);

    /**
     * Get Submited By
     *
     * @return mixed
     */
    public function getSubmutedBy();

    /**
     * Set Submited By
     *
     * @param mixed $submutedBy
     * @return GridInterface
     */
    public function setSubmutedBy($submutedBy);

    /**
     * Get Sales Rep Id
     *
     * @return mixed
     */
    public function getSalesRepId();

    /**
     * Set Sales Rep Id
     *
     * @param mixed $salesRepId
     * @return GridInterface
     */
    public function setSalesRepId($salesRepId);

    /**
     * Get Sales Rep
     *
     * @return mixed
     */
    public function getSalesRep();

    /**
     * Set Sales Rep
     *
     * @param mixed $salesRep
     * @return GridInterface
     */
    public function setSalesRep($salesRep);

    /**
     * Get Base Grand Total
     *
     * @return mixed
     */
    public function getBaseGrandTotal();

    /**
     * Set Base Grand Total
     *
     * @param mixed $baseGrandTotal
     * @return GridInterface
     */
    public function setBaseGrandTotal($baseGrandTotal);

    /**
     * Get Grand Total
     *
     * @return mixed
     */
    public function getGrandTotal();

    /**
     * Set Grand Total
     *
     * @param mixed $grandTotal
     * @return GridInterface
     */
    public function setGrandTotal($grandTotal);

    /**
     * Get Base Negotiated Grand Total
     *
     * @return mixed
     */
    public function getBaseNegotiatedGrandTotal();

    /**
     * Set Base Negotiated Grand Total
     *
     * @param mixed $baseNegotiatedGrandTotal
     * @return GridInterface
     */
    public function setBaseNegotiatedGrandTotal($baseNegotiatedGrandTotal);

    /**
     * Get Negotiated Grand Total
     *
     * @return mixed
     */
    public function getNegotiatedGrandTotal();

    /**
     * Set Negotiated Grand Total
     *
     * @param mixed $negotiatedGrandTotal
     * @return GridInterface
     */
    public function setNegotiatedGrandTotal($negotiatedGrandTotal);

    /**
     * Get Status
     *
     * @return mixed
     */
    public function getStatus();

    /**
     * Set Status
     *
     * @param mixed $status
     * @return GridInterface
     */
    public function setStatus($status);

    /**
     * Get Base_currency_code
     *
     * @return mixed
     */
    public function getBaseCurrencyCode();

    /**
     * Set Base_currency_code
     *
     * @param mixed $baseCurrencyCode
     * @return GridInterface
     */
    public function setBaseCurrencyCode($baseCurrencyCode);

    /**
     * Get Quote_currency_code
     *
     * @return mixed
     */
    public function getQuoteCurrencyCode();

    /**
     * Set Quote_currency_code
     *
     * @param mixed $quoteCurrencyCode
     * @return GridInterface
     */
    public function setQuoteCurrencyCode($quoteCurrencyCode);

    /**
     * Get Store_id
     *
     * @return mixed
     */
    public function getStoreId();

    /**
     * Set Store_id
     *
     * @param mixed $storeId
     * @return GridInterface
     */
    public function setStoreId($storeId);

    /**
     * Get Rate
     *
     * @return mixed
     */
    public function getRate();

    /**
     * Set Rate
     *
     * @param mixed $rate
     * @return GridInterface
     */
    public function setRate($rate);
}

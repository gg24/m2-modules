<?php
/**
 * Puma_ListingFilter extension
 * @category  Puma
 * @package   Puma_ListingFilter
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\ListingFilter\Model;

class GridRepository implements \Puma\ListingFilter\Api\GridRepositoryInterface
{
    /**
     * Cached instances
     *
     * @var array
     */
    protected $instances = [];

    /**
     * Grid resource model
     *
     * @var \Puma\ListingFilter\Model\ResourceModel\Grid
     */
    protected $resource;

    /**
     * Grid collection factory
     *
     * @var \Puma\ListingFilter\Model\ResourceModel\Grid\CollectionFactory
     */
    protected $gridCollectionFactory;

    /**
     * Grid interface factory
     *
     * @var \Puma\ListingFilter\Api\Data\GridInterfaceFactory
     */
    protected $gridInterfaceFactory;

    /**
     * Data Object Helper
     *
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * Search result factory
     *
     * @var \Puma\ListingFilter\Api\Data\GridSearchResultInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * constructor
     *
     * @param \Puma\ListingFilter\Model\ResourceModel\Grid $resource
     * @param \Puma\ListingFilter\Model\ResourceModel\Grid\CollectionFactory $gridCollectionFactory
     * @param \Puma\ListingFilter\Api\Data\GridInterfaceFactory $gridInterfaceFactory
     * @param \Magento\Framework\Api\DataObjectHelper $dataObjectHelper
     * @param \Puma\ListingFilter\Api\Data\GridSearchResultInterfaceFactory $searchResultsFactory
     */
    public function __construct(
        \Puma\ListingFilter\Model\ResourceModel\Grid $resource,
        \Puma\ListingFilter\Model\ResourceModel\Grid\CollectionFactory $gridCollectionFactory,
        \Puma\ListingFilter\Api\Data\GridInterfaceFactory $gridInterfaceFactory,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        \Puma\ListingFilter\Api\Data\GridSearchResultInterfaceFactory $searchResultsFactory
    ) {
        $this->resource              = $resource;
        $this->gridCollectionFactory = $gridCollectionFactory;
        $this->gridInterfaceFactory  = $gridInterfaceFactory;
        $this->dataObjectHelper      = $dataObjectHelper;
        $this->searchResultsFactory  = $searchResultsFactory;
    }

    /**
     * Save Grid.
     *
     * @param \Puma\ListingFilter\Api\Data\GridInterface $grid
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(\Puma\ListingFilter\Api\Data\GridInterface $grid)
    {
        /** @var \Puma\ListingFilter\Api\Data\GridInterface|\Magento\Framework\Model\AbstractModel $grid */
        try {
            $this->resource->save($grid);
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\CouldNotSaveException(__(
                'Could not save the Grid: %1',
                $exception->getMessage()
            ));
        }
        return $grid;
    }

    /**
     * Retrieve Grid.
     *
     * @param int $entityId
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($entityId)
    {
        if (!isset($this->instances[$entityId])) {
            /** @var \Puma\ListingFilter\Api\Data\GridInterface|\Magento\Framework\Model\AbstractModel $grid */
            $grid = $this->gridInterfaceFactory->create();
            $this->resource->load($grid, $entityId);
            if (!$grid->getId()) {
                throw new \Magento\Framework\Exception\NoSuchEntityException(__('Requested Grid doesn\'t exist'));
            }
            $this->instances[$entityId] = $grid;
        }
        return $this->instances[$entityId];
    }

    /**
     * Retrieve Grids matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Puma\ListingFilter\Api\Data\GridSearchResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        /** @var \Puma\ListingFilter\Api\Data\GridSearchResultInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);

        /** @var \Puma\ListingFilter\Model\ResourceModel\Grid\Collection $collection */
        $collection = $this->gridCollectionFactory->create();

        //Add filters from root filter group to the collection
        /** @var \Magento\Framework\Api\Search\FilterGroup $group */
        foreach ($searchCriteria->getFilterGroups() as $group) {
            $this->addFilterGroupToCollection($group, $collection);
        }
        $sortOrders = $searchCriteria->getSortOrders();
        /** @var \Magento\Framework\Api\SortOrder $sortOrder */
        if ($sortOrders) {
            foreach ($searchCriteria->getSortOrders() as $sortOrder) {
                $field = $sortOrder->getField();
                $collection->addOrder(
                    $field,
                    ($sortOrder->getDirection() == \Magento\Framework\Api\SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        } else {
            // set a default sorting order since this method is used constantly in many
            // different blocks
            $field = 'entity_id';
            $collection->addOrder($field, 'ASC');
        }
        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());

        /** @var \Puma\ListingFilter\Api\Data\GridInterface[] $grids */
        $grids = [];
        /** @var \Puma\ListingFilter\Model\Grid $grid */
        foreach ($collection as $grid) {
            /** @var \Puma\ListingFilter\Api\Data\GridInterface $gridDataObject */
            $gridDataObject = $this->gridInterfaceFactory->create();
            $this->dataObjectHelper->populateWithArray(
                $gridDataObject,
                $grid->getData(),
                \Puma\ListingFilter\Api\Data\GridInterface::class
            );
            $grids[] = $gridDataObject;
        }
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults->setItems($grids);
    }

    /**
     * Delete Grid.
     *
     * @param \Puma\ListingFilter\Api\Data\GridInterface $grid
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Puma\ListingFilter\Api\Data\GridInterface $grid)
    {
        /** @var \Puma\ListingFilter\Api\Data\GridInterface|\Magento\Framework\Model\AbstractModel $grid */
        $id = $grid->getId();
        try {
            unset($this->instances[$id]);
            $this->resource->delete($grid);
        } catch (\Magento\Framework\Exception\ValidatorException $e) {
            throw new \Magento\Framework\Exception\CouldNotSaveException(__($e->getMessage()));
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\StateException(
                __('Unable to remove Grid %1', $id)
            );
        }
        unset($this->instances[$id]);
        return true;
    }

    /**
     * Delete Grid by ID.
     *
     * @param int $entityId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($entityId)
    {
        $grid = $this->getById($entityId);
        return $this->delete($grid);
    }

    /**
     * Helper function that adds a FilterGroup to the collection.
     *
     * @param \Magento\Framework\Api\Search\FilterGroup $filterGroup
     * @param \Puma\ListingFilter\Model\ResourceModel\Grid\Collection $collection
     * @return $this
     * @throws \Magento\Framework\Exception\InputException
     */
    protected function addFilterGroupToCollection(
        \Magento\Framework\Api\Search\FilterGroup $filterGroup,
        \Puma\ListingFilter\Model\ResourceModel\Grid\Collection $collection
    ) {
        $fields = [];
        $conditions = [];
        foreach ($filterGroup->getFilters() as $filter) {
            $condition = $filter->getConditionType() ? $filter->getConditionType() : 'eq';
            $fields[] = $filter->getField();
            $conditions[] = [$condition => $filter->getValue()];
        }
        if ($fields) {
            $collection->addFieldToFilter($fields, $conditions);
        }
        return $this;
    }
}

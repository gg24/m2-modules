<?php
/**
 * Puma_ListingFilter extension
 * @category  Puma
 * @package   Puma_ListingFilter
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\ListingFilter\Model;

/**
 * @method \Puma\ListingFilter\Model\ResourceModel\Grid _getResource()
 * @method \Puma\ListingFilter\Model\ResourceModel\Grid getResource()
 */
class Grid extends \Magento\Framework\Model\AbstractModel implements \Puma\ListingFilter\Api\Data\GridInterface
{
    /**
     * Cache tag
     *
     * @var string
     */
    const CACHE_TAG = 'negotiable_quote_grid';

    /**
     * Cache tag
     *
     * @var string
     */
    protected $_cacheTag = self::CACHE_TAG;

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'negotiable_quote_grid';

    /**
     * Event object
     *
     * @var string
     */
    protected $_eventObject = 'grid';

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Puma\ListingFilter\Model\ResourceModel\Grid::class);
    }

    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Get Grid id
     *
     * @return array
     */
    public function getEntityId()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::GRID_ID);
    }

    /**
     * set Grid id
     *
     * @param int $entityId
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setEntityId($entityId)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::GRID_ID, $entityId);
    }

    /**
     * set Quote Name
     *
     * @param mixed $quoteName
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setQuoteName($quoteName)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::QUOTE_NAME, $quoteName);
    }

    /**
     * get Quote Name
     *
     * @return string
     */
    public function getQuoteName()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::QUOTE_NAME);
    }

    /**
     * set Company ID
     *
     * @param mixed $companyId
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setCompanyId($companyId)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::COMPANY_ID, $companyId);
    }

    /**
     * get Company ID
     *
     * @return string
     */
    public function getCompanyId()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::COMPANY_ID);
    }

    /**
     * set Company Name
     *
     * @param mixed $companyName
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setCompanyName($companyName)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::COMPANY_NAME, $companyName);
    }

    /**
     * get Company Name
     *
     * @return string
     */
    public function getCompanyName()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::COMPANY_NAME);
    }

    /**
     * set Customer Id
     *
     * @param mixed $customerId
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setCustomerId($customerId)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::CUSTOMER_ID, $customerId);
    }

    /**
     * get Customer Id
     *
     * @return string
     */
    public function getCustomerId()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::CUSTOMER_ID);
    }

    /**
     * set Submited By
     *
     * @param mixed $submutedBy
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setSubmutedBy($submutedBy)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::SUBMUTED_BY, $submutedBy);
    }

    /**
     * get Submited By
     *
     * @return string
     */
    public function getSubmutedBy()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::SUBMUTED_BY);
    }

    /**
     * set Sales Rep Id
     *
     * @param mixed $salesRepId
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setSalesRepId($salesRepId)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::SALES_REP_ID, $salesRepId);
    }

    /**
     * get Sales Rep Id
     *
     * @return string
     */
    public function getSalesRepId()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::SALES_REP_ID);
    }

    /**
     * set Sales Rep
     *
     * @param mixed $salesRep
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setSalesRep($salesRep)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::SALES_REP, $salesRep);
    }

    /**
     * get Sales Rep
     *
     * @return string
     */
    public function getSalesRep()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::SALES_REP);
    }

    /**
     * set Base Grand Total
     *
     * @param mixed $baseGrandTotal
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setBaseGrandTotal($baseGrandTotal)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::BASE_GRAND_TOTAL, $baseGrandTotal);
    }

    /**
     * get Base Grand Total
     *
     * @return string
     */
    public function getBaseGrandTotal()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::BASE_GRAND_TOTAL);
    }

    /**
     * set Grand Total
     *
     * @param mixed $grandTotal
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setGrandTotal($grandTotal)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::GRAND_TOTAL, $grandTotal);
    }

    /**
     * get Grand Total
     *
     * @return string
     */
    public function getGrandTotal()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::GRAND_TOTAL);
    }

    /**
     * set Base Negotiated Grand Total
     *
     * @param mixed $baseNegotiatedGrandTotal
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setBaseNegotiatedGrandTotal($baseNegotiatedGrandTotal)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::BASE_NEGOTIATED_GRAND_TOTAL, $baseNegotiatedGrandTotal);
    }

    /**
     * get Base Negotiated Grand Total
     *
     * @return string
     */
    public function getBaseNegotiatedGrandTotal()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::BASE_NEGOTIATED_GRAND_TOTAL);
    }

    /**
     * set Negotiated Grand Total
     *
     * @param mixed $negotiatedGrandTotal
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setNegotiatedGrandTotal($negotiatedGrandTotal)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::NEGOTIATED_GRAND_TOTAL, $negotiatedGrandTotal);
    }

    /**
     * get Negotiated Grand Total
     *
     * @return string
     */
    public function getNegotiatedGrandTotal()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::NEGOTIATED_GRAND_TOTAL);
    }

    /**
     * set Status
     *
     * @param mixed $status
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setStatus($status)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::STATUS, $status);
    }

    /**
     * get Status
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::STATUS);
    }

    /**
     * set Base_currency_code
     *
     * @param mixed $baseCurrencyCode
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setBaseCurrencyCode($baseCurrencyCode)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::BASE_CURRENCY_CODE, $baseCurrencyCode);
    }

    /**
     * get Base_currency_code
     *
     * @return string
     */
    public function getBaseCurrencyCode()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::BASE_CURRENCY_CODE);
    }

    /**
     * set Quote_currency_code
     *
     * @param mixed $quoteCurrencyCode
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setQuoteCurrencyCode($quoteCurrencyCode)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::QUOTE_CURRENCY_CODE, $quoteCurrencyCode);
    }

    /**
     * get Quote_currency_code
     *
     * @return string
     */
    public function getQuoteCurrencyCode()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::QUOTE_CURRENCY_CODE);
    }

    /**
     * set Store_id
     *
     * @param mixed $storeId
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setStoreId($storeId)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::STORE_ID, $storeId);
    }

    /**
     * get Store_id
     *
     * @return string
     */
    public function getStoreId()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::STORE_ID);
    }

    /**
     * set Rate
     *
     * @param mixed $rate
     * @return \Puma\ListingFilter\Api\Data\GridInterface
     */
    public function setRate($rate)
    {
        return $this->setData(\Puma\ListingFilter\Api\Data\GridInterface::RATE, $rate);
    }

    /**
     * get Rate
     *
     * @return string
     */
    public function getRate()
    {
        return $this->getData(\Puma\ListingFilter\Api\Data\GridInterface::RATE);
    }
}

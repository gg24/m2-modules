<?php
/**
 * Puma_ListingFilter extension
 * @category  Puma
 * @package   Puma_ListingFilter
 * @copyright Copyright (c) 2018
 * @author    Prashanr Chaudhary
 */
namespace Puma\ListingFilter\Source;

class Grid implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Grid repository
     *
     * @var \Puma\ListingFilter\Api\GridRepositoryInterface
     */
    protected $gridRepository;

    /**
     * Search Criteria Builder
     *
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * Filter Builder
     *
     * @var \Magento\Framework\Api\FilterBuilder
     */
    protected $filterBuilder;

    /**
     * Options
     *
     * @var array
     */
    protected $options;

    /**
     * constructor
     *
     * @param \Puma\ListingFilter\Api\GridRepositoryInterface $gridRepository
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
     * @param \Magento\Framework\Api\FilterBuilder $filterBuilder
     */
    public function __construct(
        \Puma\ListingFilter\Api\GridRepositoryInterface $gridRepository,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Api\FilterBuilder $filterBuilder
    ) {
        $this->gridRepository        = $gridRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder         = $filterBuilder;
    }

    /**
     * Retrieve all Grids as an option array
     *
     * @return array
     * @throws StateException
     */
    public function getAllOptions()
    {
        if (empty($this->options)) {
            $options = [];
            $searchCriteria = $this->searchCriteriaBuilder->create();
            $searchResults = $this->gridRepository->getList($searchCriteria);
            foreach ($searchResults->getItems() as $grid) {
                $options[] = [
                    'value' => $grid->getEntityId(),
                    'label' => $grid->getQuote_name(),
                ];
            }
            $this->options = $options;
        }

        return $this->options;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return $this->getAllOptions();
    }
}

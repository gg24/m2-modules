<?php
/**
 * Puma_Customerole extension
 * @category  Puma
 * @package   Puma_Customerole
 * @copyright Copyright (c) 2018
 * @author    Nikesh
 */
?>
<?php
namespace Puma\Customrole\Plugin;


class Resultchange
{

	protected $authSession;
	protected $_resource;

	public function __construct(
		\Magento\Backend\Model\Auth\Session $authSession,
		\Magento\Framework\App\ResourceConnection $resource
	) {
		$this->authSession = $authSession;
		$this->_resource = $resource;
	}

	public function afterJoinAdvancedCustomerEntityTable(\Magento\Company\Model\ResourceModel\Company\Collection $subject, $result)
    { 
      
		$sqlSelect = $this->_resource->getConnection()->select();
        $sqlSelect->from($this->_resource->getTableName('authorization_rule'), ['resource_id'])
                ->where('role_id IN (?)', $this->authSession->getUser()->getRole()->getRoleId())
                ->where('permission = ? ','allow');

        $resourceArr = $this->_resource->getConnection()->fetchcol($sqlSelect);

		if(count($resourceArr)>0) {
			if($this->authSession->getUser()->getRole()->getId()>2) {
				if(in_array('Magento_Company::index',$resourceArr)) {
					$result->getSelect()->where('main_table.sales_representative_id = ?', $this->authSession->getUser()->getId());
				}
			}
		}

        return $this;
    }
}   
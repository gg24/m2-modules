<?php 
/**
 * Puma_Customerole extension
 * @category  Puma
 * @package   Puma_Customerole
 * @copyright Copyright (c) 2018
 * @author    Nikesh
 */
?>
<?php
namespace Puma\Customrole\Model\ResourceModel\Order\Grid;

use Magento\Sales\Model\ResourceModel\Order\Grid\Collection as OriginalCollection;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface as FetchStrategy;
use Magento\Framework\Data\Collection\EntityFactoryInterface as EntityFactory;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Psr\Log\LoggerInterface as Logger;

/**
* Order grid extended collection
*/
class Collection extends OriginalCollection
{

	protected $authSession;
	protected $_resourceConnection;
	 
	public function __construct(
		EntityFactory $entityFactory,
        Logger $logger,
        FetchStrategy $fetchStrategy,
        EventManager $eventManager,
        \Magento\Backend\Model\Auth\Session $authSession,
        \Magento\Framework\App\ResourceConnection $resourceConnection
    ) {
        $this->authSession = $authSession;
        $this->_resourceConnection = $resourceConnection;
        parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager);
    }



	protected function _renderFiltersBefore()
	{

		$companyArr = array();
		$sqlSelect = $this->_resourceConnection->getConnection()->select();
		$sqlSelect->from(
              ['c' => 'company']
          )
          ->join(
            ['coe' => 'company_order_entity'],
            'coe.company_id=c.entity_id'
          )
          ->where('c.sales_representative_id = ?', $this->authSession->getUser()->getId());


        $companyArr = $this->_resourceConnection->getConnection()->fetchcol($sqlSelect);

        
		if($this->authSession->getUser()->getRole()->getId()>2) {
			if(count($companyArr)>0) {
				$this->getSelect()->where('company_order.company_id IN (?)', array_unique($companyArr));
			}
		} 
		parent::_renderFiltersBefore();
	}
}
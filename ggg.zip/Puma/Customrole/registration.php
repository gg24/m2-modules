<?php
/**
 * Puma_Customerole extension
 * @category  Puma
 * @package   Puma_Customerole
 * @copyright Copyright (c) 2018
 * @author    Nikesh
 */
 ?>
<?php

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Puma_Customrole',
    __DIR__
);
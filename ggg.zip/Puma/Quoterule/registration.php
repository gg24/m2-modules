<?php
/**
 * Puma_Quoterule extension
 * @category  Puma
 * @package   Puma_Quoterule
 * @copyright Copyright (c) 2018
 * @author    Nikesh
 */
?>
<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Puma_Quoterule',
    __DIR__
);
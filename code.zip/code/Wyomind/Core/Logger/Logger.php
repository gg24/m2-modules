<?php

/**
 * Copyright © 2017 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Wyomind\Core\Logger;

/**
 * Logger for Wyomind_Core
 */
class Logger extends \Monolog\Logger
{
}

<?php
namespace DCKAP\Wpsearch\Block;
 
class Wordpress extends \Magento\Framework\View\Element\Template
{
	protected $page_url;
    protected $http;
    public $helper;
    public $query;
    public $request;
    public $result;
    public $registry;
    public $image_url;

    public function __construct( 
    	\Magento\Framework\View\Element\Template\Context $context, 
        \Magento\Framework\HTTP\Adapter\Curl $http,
        \Magento\Framework\App\Request\Http $request,
        \DCKAP\Wpsearch\Helper\Data $helper,
        \Magento\Framework\Registry $registry,
        array $data = []
    )  {
        parent::__construct($context, $data);
        $this->http       =   $http;
        $this->request    =   $request;
        $this->helper     =   $helper;
        $this->registry   =   $registry;
        $this->query      =   $request->getParam('q',null);

        $url              =   $this->helper->getConfig('wpsearch/wordpress/page_url');
        $this->page_url   =   $url."?searchname=".str_replace(" ","+",$this->query)."&submit=Search";
        $baseurl          =   $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        $config_image     =   $this->helper->getConfig('wpsearch/wordpress/default_image');
        $default_image    =   $this->getViewFileUrl('DCKAP_Wpsearch::images/no.png'); 
        $this->image_url  =   ($config_image)?$baseurl."favicon/".$config_image:$default_image; 
    }


	public function wordpressSearch()
	{
		try {

        	$config['header']=false;
        	$this->http->setConfig($config);
        	$this->http->write(\Zend_Http_Client::GET, $this->page_url,'1.1', array(), '');
        	$response = $this->http->read();
        	$curl_status=$this->http->getInfo(CURLINFO_HTTP_CODE);
         
        	if($this->http->getError()) {
        	 throw new \Magento\Framework\Validator\Exception(__($this->http->getError()));
	    	}
	    	else if($curl_status==200) {
            	if($response) {
			    	$result=json_decode($response, true);
                	return $result; 
		    	}
            	else{
                	return array(); 
		    	} 
        	}
        	else {
            	if($curl_status==404){
                	throw new \Magento\Framework\Validator\Exception(__("404:Page not found.(Please check your url)"));
            	}
            	else if($curl_status==403){
                	throw new \Magento\Framework\Validator\Exception(__("403:Forbidden Access.(Please check your permission)"));
            	}
            	else if($curl_status==500){
                	throw new \Magento\Framework\Validator\Exception(__("500:Internal Server.(The server encountered an unexpected condition)"));    
            	}
            	else{
                	throw new \Magento\Framework\Validator\Exception(__($curl_status));
            	}
        	}
        } 
        catch (\Exception $e) {               
		    throw new \Magento\Framework\Validator\Exception(__($e->getMessage(). $e->getCode()));
        }

        $this->http->close();    
                  
	}

    function convertHtml($string) {
        $html= str_replace("[","<",$string);
        $html= str_replace("]",">",$html);
        return $html;
    }

    function getContent($content,$desc,$length)
    {
        if(strpos($content,"<iframe")!==false) {
            $desc = preg_replace('/<iframe.*?\/iframe>/i','', $desc);
        }
        if(strpos($content,"<img")!==false) {
            preg_match_all('/<img[^>]+>/i',$content, $result); 
            $image=$result[0];
            foreach($image as $img){
                $desc=str_replace($img,"",$desc);
            }
        }
        $desc = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $desc);
        $desc = strip_tags($desc);
        $pos = @ strpos($desc, ' ',$length);
        $description = substr(strip_tags($desc),0,$pos);
        return $description;
    }
}

<?php
namespace DCKAP\Wpsearch\Block;

use Magento\Search\Model\AutocompleteInterface;

class Product extends \Magento\Framework\View\Element\Template
{
    protected   $request;
    public $query;
    public $helper;
    public $autocomplete;
    public $registry;

    public function __construct( 
        \Magento\Framework\View\Element\Template\Context $context, 
        AutocompleteInterface $autocomplete,
        \Magento\Framework\App\Request\Http $request,
        \DCKAP\Wpsearch\Helper\Data $helper,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->autocomplete     =   $autocomplete;
        $this->helper           =   $helper;
        $this->request          =   $request;
        $this->registry         =   $registry;
        $this->query            =   $request->getParam('q',null);
    }   
    public function displayDescription($desc,$length)
    {
        if(strlen($desc) > $length) {
            $pos=strpos($desc, ' ', $length);
            if(!$pos){
                return $desc;
            }
            $desc=substr($desc,0,$pos ); 
            return $desc."...";
        }
        else { 
            return $desc;
        }
    }
}
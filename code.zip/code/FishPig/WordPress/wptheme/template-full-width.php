<?php
/**
 * Template Name: Full Width
 */

get_template_part('index');

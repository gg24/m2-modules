<?php

namespace Bullitt\Customsitemap\Cron;
use Magento\Sitemap\Model\Sitemap;
use FishPig\WordPress\Model\App\ResourceConnection;
use Bullitt\Customsitemap\Model\Magento\Sitemap\CustomSitemap;
use Bullitt\Customsitemap\Helper\Wpconnection;
use Magento\Framework\App\Config\ScopeConfigInterface;
 
class Generatexml
{
	protected $logger;
 
	public function __construct(
		\Psr\Log\LoggerInterface $loggerInterface, CustomSitemap $CustomSitemap, Sitemap $sitemap, ResourceConnection $ResourceConnection, Wpconnection $Wpconnection, ScopeConfigInterface $ScopeConfigInterface
	) {
		$this->logger = $loggerInterface;
		$this->CustomSitemap = $CustomSitemap;
		$this->sitemap = $sitemap;
		$this->ResourceConnection = $ResourceConnection;
		$this->Wpconnection = $Wpconnection;
		$this->ScopeConfigInterface = $ScopeConfigInterface;
	}
 
	public function execute() {

		$config = $this->Wpconnection->getWPMConfig();

	  	$fish = $this->ResourceConnection->connect($config);

	
        $sitemap = $this->sitemap->getCollection();

	  	   foreach ($sitemap as $key => $value) {

	  	   	   $storecode = 'en_gb';
               $sitemapid = $value->getData('sitemap_id');
               $store_id = $value->getData('store_id');
               $sitemap_filename = $value->getData('sitemap_filename');
               $filename = explode('.', $sitemap_filename);
               $sitemap_store = explode('sitemap_', $filename[0]);
               $storecode = $sitemap_store[1];

               $post_id = $this->ScopeConfigInterface->getValue('wordpress/multisite/blog_id',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $scopeCode = $storecode);


                $select = $fish->getConnection()->select()
                			->from($fish->getTable('wp_'.$post_id.'_posts'), array('id', 'post_title', 'post_name', 'post_modified', 'post_parent'))
                			->where('`post_type` =  "page" OR `post_type` = "post" AND `post_status` = "publish"');
	
        		$result = $fish->getConnection()->fetchAll($select);
        
	      	if(count($result) > 0) {

		        foreach($result as $key=>$val){

		          	if($val["post_parent"] ==0){
		              	$url = $val["post_name"];
		            }else{
		                    $postparent = $val["post_parent"];
		                    $select =  $fish->getConnection()->select()
					                    	->from($fish->getTable('wp_'.$post_id.'_posts'), array('post_name', 'post_parent'))
					                    	->where('`post_type` =  "page" OR `post_type` = "post" AND `post_status` = "publish"')
					                    	->where('id = ?', $postparent);
		                	$result2 = $fish->getConnection()->fetchAll($select);
		               	foreach($result2 as $key2=>$val2){

		                	if($val2["post_parent"] ==0){
		                		$category = $val2["post_name"];
		                	}else{
		                		$postparent2 = $val2["post_parent"];
		                    	$select2 =  $fish->getConnection()->select()
					                    	->from($fish->getTable('wp_'.$post_id.'_posts'), array('post_name', 'post_parent'))
					                    	->where('`post_type` =  "page" OR `post_type` = "post"  AND `post_status` = "publish"')
					                    	->where('id = ?', $postparent2);

		                		$result3 = $fish->getConnection()->fetchAll($select2);

			                	foreach($result3 as $key3=>$val3){
				                	if($val3["post_parent"] ==0){
				                		$category2 = $val3["post_name"];
				                	}
		                		}
		                		$category = $category2.'/'.$val2["post_name"];
		               		}
		            	}
		            	$url = $category.'/'.$val["post_name"];              

		            }
		            $wparr[] = array("id"=>$val["id"],"url"=>$url,"updated_at" => $val["post_modified"]);
		        }
	      	}
				$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			    $customsitemap = $objectManager->get('Bullitt\Customsitemap\Model\Magento\Sitemap\Customsitemap');
			    $customsitemap->load($sitemapid);

		        if($customsitemap->getId()){
		          $customsitemap->generateCustomXml($wparr);
		          unset($wparr);
		          $customsitemap->unsetData();
		        }                
  		}
	}
}
<?php

namespace Bullitt\Customsitemap\Helper;

use Magento\Store\Model\Store;
use Magento\Framework\App\Helper\Context;

class Wpconnection extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_scopeConfig;
    protected $_request;

    /**
     * @param Context $context
     */
    public function __construct(
    Context $context
    ) {
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_request = $context->getRequest();
        parent::__construct($context);
    }

    /**
     * @return $params array 
     */
    public function getWPMConfig() {
        
            $active = $this->_scopeConfig->getValue('customsitemap_section/customsitemap_mode/active');

        if ($active == 1) {

            $host = $this->_scopeConfig->getValue('customsitemap_section/customsitemap_mode/host');
            $username = $this->_scopeConfig->getValue('customsitemap_section/customsitemap_mode/csmuser');
            $password = $this->_scopeConfig->getValue('customsitemap_section/customsitemap_mode/csmpwd');
            $db = $this->_scopeConfig->getValue('customsitemap_section/customsitemap_mode/csmdb');

            $config =  array('host' => $host,
              'dbname' => $db,
              'username' => $username,
              'password' => $password,
              'active' => '1' ); 
            return $config;
        }
    }
}

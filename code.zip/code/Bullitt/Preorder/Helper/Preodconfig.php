<?php
namespace Bullitt\Preorder\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;


class Preodconfig extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_scopeConfig;

    /**
     * @param OrderObj $orderObj
     */

    public function __construct(
    ScopeConfigInterface $scopeConfig
    ) {
        $this->_scopeConfig = $scopeConfig;
    }

    public function getConfig(){

        $preordertext = $this->_scopeConfig->getValue('preorder_section/preorder_mode/productsku');

        return $preordertext;
        
    }   
}
<?php

namespace Bullitt\Paypal\Plugin;

use Bullitt\Paypal\App\RequestDecorator;
use Magento\Framework\App\RequestInterface;
use Magento\Paypal\Controller\Transparent\Response;

/**
 * Class BeforePaypalTransparentResponseDispatch
 *
 * @package Bullitt\Paypal\Plugin
 */
class BeforePaypalTransparentResponseDispatch
{
    /**
     * @param Response         $subject
     * @param RequestInterface $request
     *
     * @return array
     */
    public function beforeDispatch(Response $subject, RequestInterface $request)
    {
        return [ new RequestDecorator($request) ];
    }
}
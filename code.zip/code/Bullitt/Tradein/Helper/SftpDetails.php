<?php

namespace Bullitt\Tradein\Helper;

use Magento\Store\Model\Store;
use Magento\Framework\App\Helper\Context;

class SftpDetails extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_scopeConfig;
    protected $_request;

    /**
     * @param Context $context
     */
    public function __construct(
    Context $context
    ) {
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_request = $context->getRequest();
        parent::__construct($context);
    }

    /**
     * get EarlBrown configuration details
     * @return $params array 
     */
    public function getSFTPConfig() {
        
            $active = $this->_scopeConfig->getValue('tradein_section/tradein_mode/active');

        if ($active == 1) {

            $host = $this->_scopeConfig->getValue('tradein_section/tradein_mode/host');
            $username = $this->_scopeConfig->getValue('tradein_section/tradein_mode/traduser');
            $password = $this->_scopeConfig->getValue('tradein_section/tradein_mode/tradpwd');
            $params = array(
                'host' => $host,
                'username' => $username,
                'password' => $password,
                'timeout' => 40
            );
            return $params;
        }
    }

    /**
     * get EarlBrown configuration details
     * @return $sfformaction string 
     */
    public function getFormActionsf() {

        $active = $this->_scopeConfig->getValue('tradein_section/tradein_mode/active');
        if ($active == 1) {

            $sfformaction = $this->_scopeConfig->getValue('tradein_section/tradein_mode/sfformaction');
            return $sfformaction;
        }else{
            return false;
        }
    }

    /**
     * get EarlBrown configuration details
     * @return $sfformimei string 
     */
    public function getFormImeisf() {

        $active = $this->_scopeConfig->getValue('tradein_section/tradein_mode/active');
        if ($active == 1) {

            $sfformimei = $this->_scopeConfig->getValue('tradein_section/tradein_mode/sfformimei');
            return $sfformimei;
        }else{
            return false;
        }
    }

}

<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Bullitt\Customdesign\Block;

use Magento\Framework\View\Element\Template;

/**
 * Main contact form block
 */
class ContactForm extends \Magento\Contact\Block\ContactForm
{

    protected $messageManager;
    /**
     * @param Template\Context $context
     * @param array $data
     */
    public function __construct(Template\Context $context, \Magento\Framework\Message\ManagerInterface $messageManager, array $data = [])
    {
        $this->messageManager = $messageManager;
        parent::__construct($context, $data);
        $this->_isScopePrivate = true;
    }

    /**
     * Returns action url for contact form
     *
     * @return string
     */
    public function getFormAction()
    {
        return $this->getUrl('contact/index/post', ['_secure' => true]);
    }

    public function getMessages()
{
    $messages = array();
    $collection = $this->messageManager->getMessages(true);
    if ($collection && $collection->getItems()) {
        foreach ($collection->getItems() as $message) {
            $messages[] = $message->getText();
        }
    }
    return $messages;
}
}

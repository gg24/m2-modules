<?php
namespace Bullitt\Customdesign\Helper;

use Magento\Framework\App\Helper\Context;
use FishPig\WordPress\Model\Post;

class PostCategory extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $_post;

    public function __construct(
        Context $context,
        Post $post
    ) {
        $this->_post            = $post;
        parent::__construct($context);
    }

    public function getCatInfoById($postId=''){

        if(!isset($postId)){
            return false;
        }
        if ($this->_post->load($postId)){
            $postObj  = $this->_post->load($postId);
            $terms = $postObj->getTermCollection('category');
            foreach($terms as $term) {
                $catUrl    = $term->getUrl();
                $catTitle  = $term->getName();
            }
            return array('url'=>$catUrl, 'title'=>$catTitle);
        }
        return false;
    }
}
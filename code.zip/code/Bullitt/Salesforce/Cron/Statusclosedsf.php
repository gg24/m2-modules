<?php

namespace Bullitt\Salesforce\Cron;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Bullitt\Salesforce\Helper\sfToken;
use Bullitt\Salesforce\Helper\sfUpdateorder;
 
class Statusclosedsf
{
	protected $_resource;
    protected $_scopeConfig;

    /**
     * OrderObj 
     */
    public function __construct(
    ResourceConnection $resource, sfToken $token, ScopeConfigInterface $scopeConfig, sfUpdateorder $sfUpdateorder
    ) {
        $this->_resource = $resource;
        $this->_token = $token;
        $this->_scopeConfig = $scopeConfig;
        $this->_sfUpdateorder = $sfUpdateorder;
    }
 
  	public function execute()
  	{   
  		$writer = new \Zend\Log\Writer\Stream(BP . '/var/log/SfordUpdate.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('==== Sales Force Cron run for orderstatus update====');
        
  		$connection = $this->_resource->getConnection();
        $tableName  = $this->_resource->getTableName('sales_creditmemo_grid');  
		$tableName2 = $this->_resource->getTableName('salesforce_senddata');  
		try
        {
			$token = $this->_token->getToken();

	        if(!$token || empty($token) || $token == null){
	                $logger->info('==== Sales Force Access Token not found====');
	               return $this; 
	        }
	        else
	        {
	        //Check if MID exists on salesforce 
	        	$sql = "SELECT order_increment_id FROM " . $tableName .
	         	" WHERE order_status = 'closed' and updated_at >= NOW()-INTERVAL 10 MINUTE";

	     		$result = $connection->fetchAll($sql);
	     		$orderNr = "";
	     		$ordresult = array();
	     		$custdata = "";
	     		$ordjson= "";
	     		$rec= "";
	     		$ordersg = array();
	     		$ordarr= array();
					foreach ($result as $key => $value) {
					$orderNr = $value['order_increment_id'];
					$status = "Closed";
					$custdata = "SELECT rejson FROM " . $tableName2 .
					        " WHERE od ='$orderNr'"; 
			        $ordresult = $connection->fetchAll($custdata);

				        if(empty($ordresult)){
				        	continue;
				        }
			           	$ordjson = $ordresult[0]['rejson'];

		                $ordjson = json_decode($ordjson, true);

		                $rec = $ordjson['OrderInformation'][0]['orders'];
		                
		                $magentoContactId ="";

		                foreach($rec as $val){ 
		                $magentoContactId =  $val['magentoContactId'];               
		                $ordersg[] = array("magentoContactId" => $val['magentoContactId'], "orderNr" => $val['orderNr'], "status" => $status,
		                    "trackingURL" => $val['trackingURL'], "trackingNumber" => "",
		                    "IMIENumber" => "");                        
		                }

		                $ordarr = [array("magentoContactId" => $magentoContactId,
		                "orderNr" => $orderNr, "status" => $status, "trackingURL"
		                 => "", "trackingNumber" => "", 
		                 "IMIENumber" => "")];
		                $sfordupdsatearray = array("OrderInformation" => 
		                    [array("orders" => $ordersg)]);
		                $orddata = json_encode($sfordupdsatearray, true);
		    	            $this->_sfUpdateorder->update_contactorder($token, $orddata);
					}

    		}
    	}
        catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
            return $this;
        }
  	}
}
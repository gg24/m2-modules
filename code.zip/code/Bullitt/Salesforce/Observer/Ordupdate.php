<?php
namespace Bullitt\Salesforce\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\Order;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\App\Helper\Context;
use Bullitt\Salesforce\Helper\sfToken;
use Bullitt\Salesforce\Helper\sfUpdateorder;

class Ordupdate implements \Magento\Framework\Event\ObserverInterface
{
    protected $_order;
    protected $_resource;
    protected $_context;

    /**
     * OrderObj 
     */

    public function __construct(
    Order $order, ResourceConnection $resource, Context $context, sfToken $token, sfUpdateorder $sfUpdateorder
    ) {
        $this->_order = $order;
        $this->_resource = $resource;
        $this->_context = $context;
        $this->_token = $token;
        $this->_sfUpdateorder = $sfUpdateorder;
    }


    public function execute(\Magento\Framework\Event\Observer $observer)
    {
            $request = $this->_context->getRequest();
            $controller = $request->getControllerName();
            $action     = $request->getActionName(); 
            $event = $observer->getEvent();
            $order = $event->getOrder();
            $orderId = $order->getIncrementId();
            $orderNr = $orderId;
            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/SFordupdate.log');
            $logger = new \Zend\Log\Logger();
            $logger->addWriter($writer);
            $shipmentDate           = null; 
                        $shipmentsCollection    = $order->getShipmentsCollection();
                        if($shipmentsCollection){
                            foreach($shipmentsCollection as $shipment){
                                $shipmentDate   = $shipment->getData('created_at');
                                $shipmentDate   = date("Y-m-d", strtotime($shipmentDate));
                            }
                        }
        
        if (empty($orderNr) || $orderNr == null) {
                $logger->info('==== Sales Force  Order Not Found ====');
            return $this;
        }
        else 
        {    
           try
            {    
                $token = $this->_token->getToken();
                if(!$token || empty($token) || $token == null){
                        $logger->info('==== Sales Force Access Token not found====');
                       return $this; 
                }
                else
                {
                    $magentoContactId = "";
                    $connection = $this->_resource->getConnection();  
                    $tableName2 = $this->_resource->getTableName('salesforce_senddata'); 
                    $status = "";
                    $status = $order->getStatusLabel();
                    
                    $trackingURL = $order->getData('custom_tracking_url');
                    $trackingNumber = "";
                    $IMIENumber = "";
                    $custdata = "SELECT rejson FROM " . $tableName2 .
                            " WHERE od ='$orderNr'";
                    
                    $ordresult = $connection->fetchAll($custdata);
                    if(empty($ordresult)){
                        $logger->info('==== Order not found in Sales Force ====');
                        return $this; 
                    }
                    $ordjson = $ordresult[0]['rejson'];

                    $ordjson = json_decode($ordjson, true);
                    $rec = $ordjson['OrderInformation'][0]['orders'];
                    $ordersg = array();
                    foreach($rec as $val){                 
                    $ordersg[] = array("magentoContactId" => $val['magentoContactId'], "orderNr" => $val['orderNr'], "status" => $status,
                        "shippingDate"      => $shipmentDate,
                        "trackingURL" => $val['trackingURL'], "trackingNumber" => "",
                        "IMIENumber" => "");                        
                    }

                    $sfordupdsatearray = array("OrderInformation" => 
                        [array("orders" => $ordersg)]);
                    $orddata = json_encode($sfordupdsatearray, true);
                    $this->_sfUpdateorder->update_contactorder($token, $orddata);    
                }
            }
            catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $this;
            }
        }
       
    }
}
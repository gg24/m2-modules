<?php
namespace Bullitt\Salesforce\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\Order;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Customer\Model\Customer;
use Magento\Newsletter\Model\Subscriber;
use Bullitt\Salesforce\Helper\sfToken;
use Bullitt\Salesforce\Helper\sfContactid;
use Bullitt\Salesforce\Helper\sfContactorder;

class Sfsend implements \Magento\Framework\Event\ObserverInterface
{

    protected $_order;
    protected $_scopeConfig;
    protected $_resource;

    /**
     * @param OrderObj $orderObj
     */
    public function __construct(
    Order $orderObject, ScopeConfigInterface $scopeConfig, ResourceConnection $resource, Customer $customer, Subscriber $subscriber, sfToken $token, sfContactid $sfcontact, sfContactorder $sfcontactorder
    ) {
        $this->_order = $orderObject;
        $this->_scopeConfig = $scopeConfig;
        $this->_resource = $resource;
        $this->_customer = $customer;
        $this->_subscriber = $subscriber;
        $this->_token = $token;
        $this->_sfcontact = $sfcontact;
        $this->_sfcontactorder = $sfcontactorder;
    }

    /**
     * define execution of observer
     */

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $orderIds = $observer->getData('order_ids');
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/SalesforceorderSuccess.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
     
        if (!is_array($orderIds) || empty($orderIds) || $orderIds[0] == null) {
                $logger->info('==== Sales Force  Order Not Found ====');
            return $this;
        }
        else 
        {    
           try
           {    
                $token = $this->_token->getToken();

                if(!$token || empty($token) || $token == null){
                        $logger->info('==== Sales Force Access Token not found====');
                        return $this; 
                }
                else
                {
                    foreach ($orderIds as $_orderId) 
                    {
                        $logger->info('==== Sales Force New Order Frontend ====');
                        $order = $this->_order->load($_orderId);
                        $strid = $order->getData('store_id');

                        //echo '<pre>';print_r($order->getData());exit;
                       
                        $titlearr = json_decode($this->_scopeConfig->getValue('salesforce_section/sf_mode/titlearr'), true);
                        $paymarr = json_decode($this->_scopeConfig->getValue('salesforce_section/sf_mode/paymentarr'), true);
                        $shipmarr = json_decode($this->_scopeConfig->getValue('salesforce_section/sf_mode/shiparr'), true);

                        $ordstatarr = json_decode($this->_scopeConfig->getValue('salesforce_section/sf_mode/ordstatarr'), true);

                        $langarr = json_decode($this->_scopeConfig->getValue('salesforce_section/sf_mode/langarr'), true);

                        $prefixbill = "";
                        $billingaddress = $order->getBillingAddress();
                        $prefixbill = $billingaddress->getPrefix();

                        if(array_key_exists($prefixbill, $titlearr)){
                            $prefixbill = $titlearr[$prefixbill];
                        }else{
                            $prefixbill;
                        }

                        $methodTitle = "";

                        $payment = $order->getPayment();
                        $paymentInfo = $payment->getAdditionalInformation();
                        $methodTitle = $paymentInfo['method_title'];


                        if(array_key_exists($methodTitle, $paymarr)){
                            $methodTitle = $paymarr[$methodTitle];
                        }else{
                            $methodTitle;
                        }

                        $shipmeth = "";
                        $shipmeth = $order->getData('shipping_description');
                       
                         $shipmeth = $order->getData('shipping_description');
                        if(array_key_exists($shipmeth, $shipmarr)){
                            $shipmeth = $shipmarr[$shipmeth];
                        }else{
                            $shipmeth;
                        }
  
                        $ordstatus = "";
                        //$ordstatus = $order->getStatusLabel();

                        $ordstatus = $order->getStatus();
                        if(array_key_exists($ordstatus, $ordstatarr)){
                            $ordstatus = $ordstatarr[$ordstatus];
                        }else{
                            $ordstatus;
                        }


                        //$ordstatus = $order->getStatusLabel();
                        $wesiteId =$order->getWebsiteId(); 
                        $storeid = $order->getStoreId();
                        $custemail = $order->getCustomerEmail();
                        $custeId = $order->getCustomerId();
                        $sfbillingaddr =array();
                        $language ="";


                        $language = $this->_scopeConfig->getValue('general/locale/code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeid);
                        if(array_key_exists($language, $langarr)){
                            $language = $langarr[$language];
                        }else{
                            $language;
                        }

                        $customr = $this->_customer;
                        if($order->getCustomerId()!='') {
                            $customr->load($custeId);
                        } else {
                            $customr = $this->_customer->setWebsiteId($order->getStoreId());
                            $customr->loadByEmail($order->getCustomerEmail());
                        }

                        $prefix = "";
                        $prefix = $customr->getData('prefix');
                        if($prefix == null ){
                           $prefix = $billingaddress->getPrefix();
                        }

                        if(array_key_exists($prefix, $titlearr)){
                            $prefix = $titlearr[$prefix];
                        }else{
                            $prefix;
                        }


                        
                        
                   
                        $customerstatus = "";
                        $customerType = "";
                        $magentoContactId = "";
                        $custid = "";
                        $custid = $customr->getId();
                         
                        $guest =  $order->getData('customer_is_guest');
                   
                        if(!empty($order->getCustomerId()) && $guest === '0' ){
                            $customerloginstatus = "Registered";

                            $magentoContactId = $this->_sfcontact->getMid($order->getCustomerEmail(), $customerloginstatus, $custid, $order->getIncrementId(),$strid);
                           $customerType = "Registered";
                            
                        
                        }elseif(empty($order->getCustomerId()) && $guest === '1'){

                            $connection = $this->_resource->getConnection();
                            $tableName  = $this->_resource->getTableName('salesforce_customer');  
                            //Check if MID exists on salesforce 
                            $sql = "SELECT id,mid,customer_type,orderid, prev_email FROM " . $tableName . " WHERE email ='$custemail' AND sfid = '$strid' AND custid <> '' ORDER BY id DESC" ; 
                            $result = $connection->fetchAll($sql);


                             $sqlQuery = "SELECT id,mid,custid,customer_type,orderid, prev_email FROM " . $tableName . " WHERE email ='$custemail' AND custid <> '' ORDER BY id DESC" ;
                            $resultQuery = $connection->fetchAll($sqlQuery);



                            if (isset($result) && (count($result) > 0)) {
                                 $customerloginstatus = "Guest";
                                 $customerType = $result[0]['customer_type']; 
                            }else if((count($resultQuery) > 0)) {
                                $customerloginstatus = "Guest";
                                $customerType = 'Registered'; 
                            }else{
                                $customerloginstatus = "Guest";
                                $customerType = 'Guest';
                            }
                          
                            $magentoContactId = $this->_sfcontact->getMid($order->getCustomerEmail(), $customerloginstatus, $custid, $order->getIncrementId(),$strid);
                            
                        }                            
                            $logger->info('orderId= ' . $order->getIncrementId());
                            $countryname = "";
                            $countryid = "";
                            $countryid = $this->_scopeConfig->getValue('general/store_information/country_id', \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $order->getData('store_id'));

                            if (isset($countryid) && $countryid != "") {
                                $countryname = $countryid;
                            }

                            $billingaddress = $order->getBillingAddress();
                            $billStreet = explode("\n", $billingaddress->getData('street'));
                            $billStreet1 = "";
                            $billStreet2 = "";
                            $billingCountryName = "";
                            if (is_array($billStreet) && !empty($billStreet)) {
                                if(isset($billStreet[0])){
                                    $billStreet1 = $billStreet[0];
                                }
                                if(isset($billStreet[1])){
                                    $billStreet2 = $billStreet[1];
                                }
                            }

                            if ($billingaddress->getData('country_id')) {
                                $billingCountryName = $billingaddress->getData('country_id');
                            }

                            $shippingaddress = $order->getShippingAddress();
                             
                            $prefixship = $shippingaddress->getPrefix();
                            $shippStreet = explode("\n", $shippingaddress->getData('street'));
                            $shippStreet1 = "";
                            $shippStreet2 = "";
                            $shippingCountryName = "";
                            if (is_array($shippStreet) && !empty($shippStreet)) {
                                if(isset($shippStreet[0])){
                                    $shippStreet1 = $shippStreet[0];
                                }
                                if(isset($shippStreet[1])){
                                    $shippStreet2 = $shippStreet[1];
                                }
                            }

                            if ($shippingaddress->getData('country_id')) {
                                $shippingCountryName = $shippingaddress->getData('country_id');
                            }

                            //Store Name
                            $storeName = explode("\n", $order->getData('store_name'));
                            $webstoreName = "";
                            if (is_array($storeName) && !empty($storeName)) {
                                $webstoreName = $storeName[0];
                            }

                            //Payment Info
                            $authCode = "";
                            $payment = $order->getPayment();
                            $paymentInfo = $payment->getAdditionalInformation();

                            if (isset($paymentInfo['processorAuthorizationCode']) && !empty($paymentInfo['processorAuthorizationCode'])) {
                                $authCode = $paymentInfo['processorAuthorizationCode'];
                            }

                            $orderDetail = array();
                            $items = $order->getItemsCollection();
                            $itemLineNumber = 1;
                            $itemInfo = array();
                            $moresku = 0;
                            $totalItemCount = 0;

                            foreach ($items as $item) {
                               
                                if($item->getQtyOrdered() >1){
                                    $cont = explode('.',$item->getQtyOrdered());
                                    for($i=1;$i<=$cont[0];$i++){
                                    $sku = $item->getData('sku');
                                    $sku = str_replace("_CK","",$sku);
                                    $sku = str_replace("_EB","",$sku);
                                    $itemInfo[$itemLineNumber]['magentoContactId'] = $magentoContactId;
                                    $itemInfo[$itemLineNumber]['customerName']= $shippingaddress->getData('firstname').' '.$shippingaddress->getData('lastname');
                                    $itemInfo[$itemLineNumber]['orderNr']= $order->getData('increment_id')."_".$itemLineNumber;
                                    $itemInfo[$itemLineNumber]['consumerSalesName']= $order->getData('increment_id')."_".$itemLineNumber;
                                    $itemInfo[$itemLineNumber]['IMIENumber']= "";
                                    $itemInfo[$itemLineNumber]['sku']= $sku;
                                    $itemInfo[$itemLineNumber]['paymentMethod']= $methodTitle;
                                    $itemInfo[$itemLineNumber]['shippingMethod']= $shipmeth;
                                    $itemInfo[$itemLineNumber]['netPrice']= $item->getData('price');
                                    
                                    $itemInfo[$itemLineNumber]['discountPercentage']= null;
                                    $itemInfo[$itemLineNumber]['status']= $ordstatus;
                                    $itemInfo[$itemLineNumber]['trackingURL']= "";
                                    
                                   
                                    
                                    $itemInfo[$itemLineNumber]['shippingDate']= null;
                                    $itemInfo[$itemLineNumber]['couponCode']= "";
                                    $itemInfo[$itemLineNumber]['currencyCode']=  $order->getData('store_currency_code');
                                    $itemInfo[$itemLineNumber]['promoName']= "";
                                    $itemInfo[$itemLineNumber]['vantr']= "";
                                    $itemInfo[$itemLineNumber]['website']= $webstoreName;
                                    $itemInfo[$itemLineNumber]['storeId']= $item->getData('store_id');
                                    $itemInfo[$itemLineNumber]['promoDescription']= "";
                                    
                                    $itemInfo[$itemLineNumber]['testAPI1']= "";
                                    $itemInfo[$itemLineNumber]['testAPI2']= "";

                                    $itemInfo[$itemLineNumber]['billingAddress'] = array ("address1"=> $billStreet1."\n". $billStreet2,
                                        "zip" => $billingaddress->getData('postcode'),
                                        "city" => $billingaddress->getData('city'),
                                        "state" => $billingaddress->getData('region'),
                                        "country" => $billingCountryName   
                                    );
                                    
                                    $itemInfo[$itemLineNumber]['shippingAddress'] = array ("address1"=> $shippStreet1."\n". $shippStreet2,
                                        "zip" => $shippingaddress->getData('postcode'),
                                        "city" => $shippingaddress->getData('city'),
                                        "state" => $shippingaddress->getData('region'),
                                        "country" => $shippingCountryName   
                                    );
                                    $itemLineNumber++;
                                    $totalItemCount++;
                                       
                                    }

                                }else{
                                    $sku = $item->getData('sku');
                                    $sku = str_replace("_CK","",$sku);
                                    $sku = str_replace("_EB","",$sku);
                                    $itemInfo[$itemLineNumber]['magentoContactId'] = $magentoContactId;
                                    $itemInfo[$itemLineNumber]['customerName']= $shippingaddress->getData('firstname').' '.$shippingaddress->getData('lastname');
                                    $itemInfo[$itemLineNumber]['orderNr']= $order->getData('increment_id')."_".$itemLineNumber;
                                    $itemInfo[$itemLineNumber]['consumerSalesName']= $order->getData('increment_id')."_".$itemLineNumber;
                                    $itemInfo[$itemLineNumber]['IMIENumber']= "";
                                    $itemInfo[$itemLineNumber]['sku']= $sku;
                                    $itemInfo[$itemLineNumber]['paymentMethod']= $methodTitle;
                                    $itemInfo[$itemLineNumber]['shippingMethod']= $shipmeth;
                                    $itemInfo[$itemLineNumber]['netPrice']= $item->getData('price');
                                    
                                    //$itemInfo[$itemLineNumber]['customer_taxvat']=null;
                                    $itemInfo[$itemLineNumber]['discountPercentage']= null;
                                    $itemInfo[$itemLineNumber]['status']= $ordstatus;
                                    $itemInfo[$itemLineNumber]['trackingURL']= "";
                                    
                                   
                                    
                                    $itemInfo[$itemLineNumber]['shippingDate']= null;
                                    $itemInfo[$itemLineNumber]['couponCode']= "";
                                    $itemInfo[$itemLineNumber]['currencyCode']=  $order->getData('store_currency_code');
                                    $itemInfo[$itemLineNumber]['promoName']= "";
                                    $itemInfo[$itemLineNumber]['vantr']= "";
                                    $itemInfo[$itemLineNumber]['website']= $webstoreName;
                                    $itemInfo[$itemLineNumber]['storeId']= $item->getData('store_id');
                                    $itemInfo[$itemLineNumber]['promoDescription']= "";
                                    
                                    $itemInfo[$itemLineNumber]['testAPI1']= "";
                                    $itemInfo[$itemLineNumber]['testAPI2']= "";

                                    $itemInfo[$itemLineNumber]['billingAddress'] = array ("address1"=> $billStreet1."\n". $billStreet2,
                                        "zip" => $billingaddress->getData('postcode'),
                                        "city" => $billingaddress->getData('city'),
                                        "state" => $billingaddress->getData('region'),
                                        "country" => $billingCountryName   
                                    );
                                    
                                    $itemInfo[$itemLineNumber]['shippingAddress'] = array ("address1"=> $shippStreet1."\n". $shippStreet2,
                                        "zip" => $shippingaddress->getData('postcode'),
                                        "city" => $shippingaddress->getData('city'),
                                        "state" => $shippingaddress->getData('region'),
                                        "country" => $shippingCountryName   
                                    );
                                    $itemLineNumber++;
                                    $totalItemCount++;
                                }
                                

                            }
                            
                            $orderDetail['order_no'] = $order->getData('increment_id');

                            $createdDate = date(DATE_ATOM, strtotime(($order->getData('created_at'))));

                            $orderDetail['order_date'] = $createdDate;
                            $orderDetail['total_item_count'] = $totalItemCount;
                            $orderDetail['currency'] = $order->getData('store_currency_code');
                            $orderDetail['weight'] = $order->getData('weight');
                            $orderDetail['payment_method'] = $methodTitle;
                            $orderDetail['shipping_method'] = $order->getData('shipping_description');
                            $orderDetail['customer_note'] = "";
                            $orderDetail['vat'] = $order->getData('customer_taxvat');
                            $orderDetail['grand_total'] = $order->getData('base_grand_total');
                            $orderDetail['shipping_cost'] = $order->getData('shipping_amount');
                            $orderDetail['discount'] = $order->getData('base_discount_amount');
                            $orderDetail['tax'] = $order->getData('base_tax_amount');
                            $orderDetail['paid_amount'] = $order->getData('base_total_paid');
                            $orderDetail['store_brand'] = $webstoreName;
                            $orderDetail['store_country'] = $countryname;
                            $orderDetail['cust_order'] = "";
                            $orderDetail['note'] = "";
                            $orderDetail['coupon_code'] = $order->getData('coupon_code');
                            $orderDetail['coupon_rule_name'] = $order->getData('coupon_rule_name');

                            $orderDetail['billing_address']['first_name'] = $billingaddress->getData('firstname');
                            $orderDetail['billing_address']['last_name'] = $billingaddress->getData('lastname');
                            $orderDetail['billing_address']['street_address_1'] = $billStreet1;
                            $orderDetail['billing_address']['street_address_2'] = $billStreet2;
                            $orderDetail['billing_address']['city'] = $billingaddress->getData('city');
                            $orderDetail['billing_address']['state'] = $billingaddress->getData('region');
                            $orderDetail['billing_address']['country'] = $billingCountryName;
                            $orderDetail['billing_address']['zip_code'] = $billingaddress->getData('postcode');
                            $orderDetail['billing_address']['telephone'] = $billingaddress->getData('telephone');
                            $orderDetail['billing_address']['fax'] = $billingaddress->getData('fax');
                            $orderDetail['billing_address']['email'] = $billingaddress->getData('email');

                            $orderDetail['shipping_address']['first_name'] = $shippingaddress->getData('firstname');
                            $orderDetail['shipping_address']['last_name'] = $shippingaddress->getData('lastname');
                            $orderDetail['shipping_address']['street_address_1'] = $shippStreet1;
                            $orderDetail['shipping_address']['street_address_2'] = $shippStreet2;
                            $orderDetail['shipping_address']['city'] = $shippingaddress->getData('city');
                            $orderDetail['shipping_address']['state'] = $shippingaddress->getData('region');
                            $orderDetail['shipping_address']['country'] = $shippingCountryName;
                            $orderDetail['shipping_address']['zip_code'] = $shippingaddress->getData('postcode');
                            $orderDetail['shipping_address']['telephone'] = $shippingaddress->getData('telephone');
                            $orderDetail['shipping_address']['fax'] = $shippingaddress->getData('fax');
                            $orderDetail['shipping_address']['email'] = $shippingaddress->getData('email');

                            $orderDetail['order_items']['items'] = $itemInfo;   

                            $sfbillingaddr = array ("address1"=> $orderDetail['billing_address']['street_address_1']."\n".
                                $orderDetail['billing_address']['street_address_2'],
                                "city" => $orderDetail['billing_address']['city'],
                                "state" => $orderDetail['billing_address']['state'],
                                "country" => $orderDetail['billing_address']['country'],
                                "zip" => $orderDetail['billing_address']['zip_code']);

                            $sfshippingaddr = array ("address1"=> $orderDetail['shipping_address']['street_address_1']."\n".
                                $orderDetail['shipping_address']['street_address_2'],
                                "zip" => $orderDetail['shipping_address']['zip_code'],
                                "city" => $orderDetail['shipping_address']['city'],
                                "state" => $orderDetail['shipping_address']['state'],
                                "country" => $orderDetail['shipping_address']['country']);

                            $newsl =false;
                            
                            if($customerType == "Registered"){
        
                            $newsletter = $this->_subscriber->load($customr->getEmail(), 'subscriber_email'); 
                            $emailExist =  $newsletter->getSubscriberStatus(); 
                            if($emailExist ==1){
                                $newsl = true;
                            }else{
                                $newsl = false;
                            }
                            $custdat = $customr->getData();

                            

                            if(!empty($custdat)){ 
                                //echo 'if';
                                $contactarr =array(
                               "magentoContactId"=>$magentoContactId,
                               "title"=>$prefix,
                               "email"=> $customr->getEmail(),
                               "firstName"=> $customr->getFirstname(),
                               "lastName"=> $customr->getLastname(),
                               "phoneNumber"=> $customr->getPhone(),
                               
                               "contactCurrency"=> $orderDetail['currency'],
                               "fax"=> $orderDetail['billing_address']['fax'],
                               "customerType"=>"Registered",
                               "newsletter"=> $newsl,
                               "language"=>$language,
                                "testAPI1" => "",
                                "testAPI2" => "",
                               "billingAddress"=>  $sfbillingaddr);
                               // echo '<pre>1';print_r($contactarr);exit;
                                }else{
                                    //echo 'else';
                                    $connection = $this->_resource->getConnection();
                                $tableName  = $this->_resource->getTableName('salesforce_customer');  
                                //Check if MID exists on salesforce 
                                $sql = "SELECT custid FROM " . $tableName . " WHERE email ='$custemail' AND sfid = '$strid' AND custid <> '' ORDER BY id DESC" ; 
                                $result = $connection->fetchAll($sql);
                                
                                if(count($result)==0) {
                                    $sql = "SELECT custid FROM " . $tableName . " WHERE email ='$custemail' AND custid <> '' ORDER BY id DESC" ; 
                                    $result = $connection->fetchAll($sql);
                                
                                }

                                $custid = $result[0]['custid'];
                            
                                $customrnew = $this->_customer->load($custid);
                                    // echo 'else';exit;
                                        $contactarr =array(
                               "magentoContactId"=>$magentoContactId,
                               "title"=>$prefix,
                               "email"=> $custemail,
                               "firstName"=> $customrnew->getFirstname(),
                               "lastName"=> $customrnew->getLastname(),
                               "phoneNumber"=> $billingaddress->getPhone(),
                               
                               "contactCurrency"=> $orderDetail['currency'],
                               "fax"=> $orderDetail['billing_address']['fax'],
                               "customerType"=>"Registered",
                               "newsletter"=> $newsl,
                               "language"=>$language,
                                "testAPI1" => "",
                                "testAPI2" => "",
                               "billingAddress"=>  $sfbillingaddr);
                                       
                                }

                               
                            }else{
                                $newsletter = $this->_subscriber->load($orderDetail['billing_address']['email'], 'subscriber_email'); 
                            $emailExist =  $newsletter->getSubscriberStatus(); 
                            if($emailExist ==1){
                                $newsl = true;
                            }else{
                                $newsl = false;
                            } 
                                $contactarr =array(
                               "magentoContactId"=>$magentoContactId,
                               "title"=>$prefixbill,
                               "email"=> $orderDetail['billing_address']['email'],
                               "firstName"=> $orderDetail['billing_address']['first_name'],
                               "lastName"=> $orderDetail['billing_address']['last_name'],
                               "phoneNumber"=> $orderDetail['billing_address']['telephone'],
                               
                               "contactCurrency"=> $orderDetail['currency'],
                               "fax"=> $orderDetail['billing_address']['fax'],
                               "customerType"=>$customerType,
                               "newsletter"=> $newsl,
                               "language"=>$language,
                                "testAPI1" => "",
                                "testAPI2" => "",
                               "billingAddress"=>  $sfbillingaddr);
                            }

                                $orderarr[] =  ["magentoContactId"=> $magentoContactId,
                                      "customerName"=>  $orderDetail['billing_address']['first_name']." ".$orderDetail['billing_address']['last_name'],
                                      "orderNr"=>  $orderDetail['order_no']."_0",
                                      "consumerSalesName"=>$orderDetail['order_no']."_0",
                                      "IMIENumber"=> "",
                                      "paymentMethod"=> $methodTitle,
                                      "shippingMethod"=> $shipmeth,
                                      "netPrice"=> $orderDetail['grand_total'],
                                      "tax"=>  $orderDetail['tax'],
                                      "discountPercentage"=> $orderDetail['discount'],
                                      "status"=>$ordstatus,
                                      "trackingURL"=>"",
                                      "shippingDate"=> null,
                                      "couponCode"=> $orderDetail['coupon_code'],
                                      "currencyCode"=> $orderDetail['currency'], 
                                      "promoName"=> $orderDetail['coupon_rule_name'],
                                      "vantr" => $orderDetail['vat'], 
                                      "website" => $webstoreName,
                                      "storeId"=> $order->getData('store_id'),
                                      "promoDescription"=> $orderDetail['coupon_rule_name'],
                                      "testAPI1" => "",
                                      "testAPI2" => "",
                                      "billingAddress"=>  $sfbillingaddr,
                                      "shippingAddress"=> $sfshippingaddr];
                       
                                $finalorder = array_merge($orderarr,$itemInfo);
                                   $sforderarray = array("OrderInformation" => [array("cont" => $contactarr,"orders" => $finalorder)]);
                                   
                                   $orddata = json_encode($sforderarray, true);
                                   $this->_sfcontactorder->create_contactorder($token, $orddata,$order->getIncrementId());
                    }
                }
            }
            catch (\Exception $e) {
                echo $e->getMessage();
                $this->messageManager->addError($e->getMessage());
                return $this;
            }

        }    
    }
}
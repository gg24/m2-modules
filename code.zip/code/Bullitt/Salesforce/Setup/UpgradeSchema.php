<?php
namespace Bullitt\Salesforce\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

/**
 * UpgradeSchema
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $version = $context->getVersion();
        
        if (version_compare($version, '1.1.0', '<')) {
            $installer->startSetup();

            $table = $installer->getConnection()
                ->newTable($installer->getTable('trigger_sf_after_dispatch'))
                ->addColumn(
                    'id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                    ],
                    'ID'
                )
                ->addColumn(
                    'order_status',
                    Table::TYPE_TEXT,
                    50,
                    ['nullable' => true],
                    'order status'
                )
                ->addColumn(
                    'send_sales_force',
                    Table::TYPE_SMALLINT,
                    null,
                    ['nullable' => false, 'default' => '0'],
                    'info send to sales force'
                )
                ->setComment('Salesforce Send data')
                ->setOption('type', 'InnoDB')
                ->setOption('charset', 'utf8');

            $installer->getConnection()->createTable($table);
            $installer->endSetup();   
        }

        if (version_compare($version, '1.2.0', '<')) {
            $installer->startSetup();

            $table = $installer->getConnection();

            $table->addColumn(
                $setup->getTable('trigger_sf_after_dispatch'),
                'order_id',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 50,
                    'nullable' => true,
                    'comment' => 'order increment',
                ]
            ); 
        }
        
        $installer->endSetup();
    }
}
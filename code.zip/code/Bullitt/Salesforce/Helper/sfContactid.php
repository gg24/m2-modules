<?php
namespace Bullitt\Salesforce\Helper;
use Magento\Framework\App\ResourceConnection;
use Bullitt\Salesforce\Model\Salesforcecustomer;
use Bullitt\Salesforce\Model\SalesforcecustomerFactory;


class sfContactid extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_scopeConfig;
    protected $_resource;

    /**
     * @param OrderObj $orderObj
     */
    public function __construct(
    ResourceConnection $resource, Salesforcecustomer $salesforcecustomer, SalesforcecustomerFactory $salesforcecustomerFactory
    )
    {
        $this->_resource = $resource;
        $this->_salesforcecustomer = $salesforcecustomer;
        $this->_salesforcecustomerFactory = $salesforcecustomerFactory;

    }

    /**
     * @param Email $email
     * @param CustType $custtype
     * @return Mid $mid
     */

    public function getMid($email, $custtype, $custid, $_orderId,$strid)
    {   
        $custdata=array();        
        $connection = $this->_resource->getConnection();
        $tableName  = $this->_resource->getTableName('salesforce_customer');  

        //Check if MID exists on salesforce 
        $sql = "SELECT id,mid,customer_type,orderid FROM " . $tableName . " WHERE email ='$email' AND sfid ='$strid'";
        $result = $connection->fetchAll($sql);
        

        if (isset($result) && (count($result) > 0)) 
        {   
            $cstype = $result[0]['customer_type'];


            if($cstype == 'Guest' && $custtype == 'Registered')
            {   
                $id = $result[0]['id'];
                $sfCustomermodel = $this->_salesforcecustomer->load($id);
                $data = $sfCustomermodel->getData();
                $cusdatid = $data['custid'];
                $rcmctid = $data['mid'];
                $sfCustomermodel->setCustid($custid);
                $sfCustomermodel->setCustomerType($custtype);
               
                $sfCustomermodel->setOrderid($_orderId);
                $sfCustomermodel->setLastOrder($data['orderid']);
                $sfCustomermodel->setUpdatedAt(date('Y-m-d H:i:s'));
                $sfCustomermodel->save();
                $sfCustomermodel->unsetData();
                return $rcmctid;
        
            }else{
                $id = $result[0]['id'];
                $sfCustomermodel = $this->_salesforcecustomer->load($id);
                $data = $sfCustomermodel->getData();
                $rcmctid = $data['mid'];
                $sfCustomermodel->setOrderid($_orderId);
                $sfCustomermodel->setLastOrder($data['orderid']);
                $sfCustomermodel->setUpdatedAt(date('Y-m-d H:i:s'));
                $sfCustomermodel->save();
                return $rcmctid;
            }

        }else{
            $sqlf = "SELECT id,mid,customer_type,orderid FROM " . $tableName . " WHERE email ='$email'";
            $result = $this->_resource->getConnection()->fetchAll($sqlf);

            if(isset($result) && (count($result) > 0))
            {   
                $mctid = $result[0]['mid'];

                $sfCustomermodel = $this->_salesforcecustomerFactory->create();
            
                $sfCustomermodel->setCustid($custid);
                $sfCustomermodel->setCustomerType($custtype);
                $sfCustomermodel->setMid($mctid);
                $sfCustomermodel->setEmail($email);
                $sfCustomermodel->setSfid($strid);
                $sfCustomermodel->setOrderid($_orderId);
                $sfCustomermodel->setCreatedAt(date('Y-m-d H:i:s'));
                $sfCustomermodel->setUpdatedAt(date('Y-m-d H:i:s'));
                $sfCustomermodel->save();
                $sfCustomermodel->unsetData();
                return $mctid;

            }else
            {
                $sfCustomermodel = $this->_salesforcecustomerFactory->create();
            
                $mctid = uniqid();
                $sfCustomermodel->setCustid($custid);
                $sfCustomermodel->setCustomerType($custtype);
                $sfCustomermodel->setMid($mctid);
                $sfCustomermodel->setEmail($email);
                $sfCustomermodel->setSfid($strid);
                $sfCustomermodel->setOrderid($_orderId);
                $sfCustomermodel->setCreatedAt(date('Y-m-d H:i:s'));
                $sfCustomermodel->setUpdatedAt(date('Y-m-d H:i:s'));
                $sfCustomermodel->save();
                $sfCustomermodel->unsetData();
                return $mctid;
            }
        }
    }
}
<?php
namespace Bullitt\Salesforce\Helper;

use Bullitt\Salesforce\Model\Salesforcesend;
use Bullitt\Salesforce\Model\SalesforcesendFactory;
use Magento\Framework\App\Helper\Context;

class sfUpdateorder extends \Magento\Framework\App\Helper\AbstractHelper {

    /**
     * @param OrderObj $orderObj
     */

    public function __construct(
      Salesforcesend $salesforcesend, SalesforcesendFactory $salesforcesendFactory, Context $context
    )
    {
        $this->_salesforcesend = $salesforcesend;
        $this->_salesforcesendFactory = $salesforcesendFactory;
        $this->_context = $context;
    }

    /**
     * send data to Sales Force API for Update contact Order
     */

    public function update_contactorder($access_token, $Order) {

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/SalesforceorderUpdate.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $endpoint = $this->_context->getScopeConfig()->getValue('salesforce_section/sf_mode/host');

        $url = $endpoint."/updateOrder";
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER,
                array("Authorization: Bearer $access_token",
                    "Content-type: application/json"));
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $Order);
        $json_response = curl_exec($curl);
        curl_close($curl);

        $response = json_decode($json_response, true);

        if($response["responseCode"] == 10001 && $response["responseStatus"] == 1)
        {
            $logger->info('==== Order Processed successfully on Sales Force ====');
            $logger->info('responseCode= ' . $response['responseCode']);
            $ordno = explode('_', array_keys($response['OrderInformation'][0])[0])[0];
            $respord = json_decode($Order, true);
            $status = $respord['OrderInformation'][0]['orders'][0]['status'];
            $sfsend = $this->_salesforcesend->getCollection();
            $custdata = $sfsend->addFieldToFilter('od', $ordno)
            ->getLastItem();
            $recorddata = $sfsend->getData(); 
            $recordid = $recorddata[0]['id'];
     
            $sfsendmodel = $this->_salesforcesendFactory->create();

            $sfsendmodel->load($recordid);
                    $sfsendmodel->setStatus($status);
                    $sfsendmodel->setMessage($response['responseMsg']);
                    $sfsendmodel->setAction('order updated successfully');
                    $sfsendmodel->save();
                    $sfsendmodel->unsetData();
            return $this;
        }else{
            $logger->info('==== Api hit but Order not Processed successfully on Sales Force ====');
            $logger->info('responseCode= ' . $response['responseCode']);
            return $this;
        }
    }   
}
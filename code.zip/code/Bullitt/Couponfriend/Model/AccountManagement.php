<?php

namespace Bullitt\Couponfriend\Model;

class AccountManagement {
    
    public function beforeIsEmailAvailable(\Magento\Customer\Model\AccountManagement $subject,$customerEmail, $websiteId = null) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $cart = $objectManager->get('\Magento\Checkout\Model\Cart');
        $shippingAddress = $cart->getQuote()->getShippingAddress();

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/guestFriendsFamily.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('------------');
        
        try {
            if ($shippingAddress) {
                $shippingAddress->setData('email', $customerEmail);
                $shippingAddress->save();
            }
        } catch (NoSuchEntityException $e) {
            $logger->info($e->getMessage());
        }
    }
    
}
<?php

namespace Bullitt\Checklogin\Helper;

use Magento\Customer\Model\Address;
use Magento\Directory\Api\CountryInformationAcquirerInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $_storeManager;
    protected $_address;
    protected $_countryInformation;

    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        CountryInformationAcquirerInterface $countryInformation,
        Address $address
    ) {
        $this->customerSession      = $customerSession;
        $this->_storeManager        = $storeManager;
        $this->_address             = $address;
        $this->_countryInformation  = $countryInformation;

        parent::__construct($context);
    }

    public function isLoggedIn(){
        return $this->customerSession->isLoggedIn();
    }

    public function getCurrentWebsiteId(){
        return $this->_storeManager->getStore()->getWebsiteId();
    }

    public function getCountryNameById($cid) {
        if($cid){
            $countryname    = '';
            $country        = $this->_countryInformation->getCountryInfo($cid);
            $countryname    = $country->getFullNameLocale();
            return $countryname;
        }else{
            return false;
        }
    }

    public function getCustomerData(){
        if($this->customerSession->isLoggedIn()){
            $cData              = [];
            $customerData       = $this->customerSession->getCustomer()->getData();
            $cData['user_title']= $customerData['prefix'];
            $cData['firstname'] = $customerData['firstname'];
            $cData['lastname']  = $customerData['lastname'];
            $cData['user_name'] = $customerData['firstname'].' '.$customerData['lastname'];
            $cData['entity_id'] = $customerData['entity_id'];
            $cData['email']     = $customerData['email'];
            $cData['user_city'] =  '';
            $cData['user_country'] = '';
            
            $shippingAddressId  = $this->customerSession->getCustomer()->getDefaultShipping();
            if($shippingAddressId){
                try {
                    $shippingAddress        = $this->_address->load($shippingAddressId);
                    $cData['user_city']     = $shippingAddress->getData('city');
                    $cData['user_country']  = $this->getCountryNameById($shippingAddress->getData('country_id'));
                } catch (\Exception $e) {
                    echo $e->getMessage();
                }
            }
            return $cData;           
        }else{
            return false;
        }
    }
}
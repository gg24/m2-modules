<?php

namespace Bullitt\ThreePL\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Bullitt\ThreePL\Helper\UploadSftp;
use Bullitt\ThreePL\Helper\ArrayToXml;
use Magento\Directory\Api\CountryInformationAcquirerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ResourceConnection;

class Backendorder implements ObserverInterface {

    const NEW_ORDER_LOCAL_DIR_CK = '3PL/charleskendall/Order/New';
    const NEW_ORDER_LOCAL_DIR_EB = '3PL/earlbrown/Order/New';
    const XML_UPLOAD_PATH_ON_SFTP_CK = 'charleskendall/Order/New';
    const XML_UPLOAD_PATH_ON_SFTP_EB = 'earlbrown/Order/New';
    const US_STORE_ID = 8;
    const CANADA_EN_STORE_ID = 11;
    const CANADA_FR_STORE_ID = 10;
    const ROOT_NODE = "<order_new></order_new>";
    
/*    
    const EARPHONE_NAME = 'Active Urban Rugged Earphones';
    const EARPHONE_ID = '15';
    const EARPHONE_SKU = 'CUEP-BLYE-00G-0B0';
    const EARPHONE_WEIGHT = '10.0000';
    const FRANCE_STORE_ID = '7';
    const PHONE_ATTRIBUTE_SET_ID = 36;
*/

    protected $_directory_list;
    protected $_date;
    protected $_uploadSftp;
    protected $_arrayToXml;
    protected $_countryInfo;
    protected $_scopeConfig;
    protected $_productRepository;
    protected $_resource;

    /**
     * @param Context $context
     * @param DirectoryList $directory_list
     * @param UploadSftp $uploadSftp
     * @param ArrayToXml $arrayToXml
     */
    public function __construct(
    DirectoryList $directory_list, DateTime $date, UploadSftp $uploadSftp, ArrayToXml $arrayToXml, CountryInformationAcquirerInterface $countryInfo, ScopeConfigInterface $scopeConfig,
    \Magento\Catalog\Model\ProductRepository $productRepository, ResourceConnection $resource
    ) {
        $this->_directory_list = $directory_list;
        $this->_date = $date;
        $this->_uploadSftp = $uploadSftp;
        $this->_arrayToXml = $arrayToXml;
        $this->_countryInfo = $countryInfo;
        $this->_scopeConfig = $scopeConfig;
        $this->_productRepository = $productRepository;
        $this->_resource = $resource;
    }

    /**
     * define execution of observer
     */
    public function execute(Observer $observer) {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/orderSuccess.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('==== New Order Admin ====');

        $order = $observer->getEvent()->getOrder();
        $logger->info('orderId= ' . $order->getIncrementId());
        
        $earlBrown = false;
        $currentDateTime = date(DATE_ATOM, strtotime($this->_date->date()));
        $fileName = 'order_new_' . $order->getIncrementId() . '_' . $currentDateTime . '.xml';
        $pubDir = $this->_directory_list->getPath('var');
        $earlBrownStoreIDs = [self::US_STORE_ID, self::CANADA_EN_STORE_ID, self::CANADA_FR_STORE_ID];
        $fileNameOnSftp = $fileName;
        
        $countryname = "";
        $countryid = "";
        $countryid = $this->_scopeConfig->getValue('general/store_information/country_id',\Magento\Store\Model\ScopeInterface::SCOPE_STORE,$order->getData('store_id') );

        if(isset($countryid) && $countryid !=""){
            //$country = $this->_countryInfo->getCountryInfo($countryid);
            //$countryname = $country->getFullNameLocale();
            $countryname = $countryid;
        }

        if (in_array($order->getData('store_id'), $earlBrownStoreIDs)) {
            $earlBrown = true;
            $xmlLocalPath = $pubDir . '/' . self::NEW_ORDER_LOCAL_DIR_EB . '/' . $fileName;
            $sftpPath = self::XML_UPLOAD_PATH_ON_SFTP_EB. '/';
        } else {
            $earlBrown = false;
            $xmlLocalPath = $pubDir . '/' . self::NEW_ORDER_LOCAL_DIR_CK . '/' . $fileName;
            $sftpPath = self::XML_UPLOAD_PATH_ON_SFTP_CK. '/';
        }

        $billingaddress = $order->getBillingAddress();
        $billStreet = explode("\n", $billingaddress->getData('street'));
        $billStreet1 = "";
        $billStreet1 = "";
        $billingCountryName = "";
        if(is_array($billStreet) && !empty($billStreet)){
            $billStreet1 = $billStreet[0];
            $billStreet2 = $billStreet[1];
        }
        
        if ($billingaddress->getData('country_id')) {
            //$billingCountryId = $billingaddress->getData('country_id');
            //$billingCountry = $this->_countryInfo->getCountryInfo($billingCountryId);
            //$billingCountryName = $billingCountry->getFullNameLocale();
            $billingCountryName = $billingaddress->getData('country_id');
        }

        $shippingaddress = $order->getShippingAddress();
        $shippStreet = explode("\n", $shippingaddress->getData('street'));
        $shippStreet1 = "";
        $shippStreet2 = "";
        $shippingCountryName = "";
        if(is_array($shippStreet) && !empty($shippStreet)){
            $shippStreet1 = $shippStreet[0];
            $shippStreet2 = $shippStreet[1];
        }
        
        if ($shippingaddress->getData('country_id')) {
            //$shippingCountryId = $shippingaddress->getData('country_id');
            //$shippingCountry = $this->_countryInfo->getCountryInfo($shippingCountryId);
            //$shippingCountryName = $shippingCountry->getFullNameLocale();
            $shippingCountryName = $shippingaddress->getData('country_id');
        }
        //Store Name
        $storeName = explode("\n", $order->getData('store_name'));
        $webstoreName = "";
        if(is_array($storeName) && !empty($storeName)){
            $webstoreName = $storeName[0];
        }

        //Payment Info
        $authCode = "";
        $payment = $order->getPayment();
        $paymentInfo = $payment->getAdditionalInformation();

        $methodTitle = $paymentInfo['method_title'];
        if (isset($paymentInfo['processorAuthorizationCode']) && !empty($paymentInfo['processorAuthorizationCode'])) {
            $authCode = $paymentInfo['processorAuthorizationCode'];
        }elseif(isset($paymentInfo['payment_token']) && !empty($paymentInfo['payment_token'])){
            $authCode = $paymentInfo['payment_token'];
        }

        $orderDetail = array();

        $items = $order->getItemsCollection();
        $itemLineNumber = 1;
        $bitemLineNumber = 1;
        $bitemInfo = array();
        $bitemLineInfo = array();
        $itemInfo = array();
        
        $totalItemCount = 0;
        
        foreach ($items as $item) {
            $bundle_selection = $item->getData('product_options');
            if ($item->getData('product_type') == 'bundle') {
                $bitemInfo[$item->getData('item_id')]['bundle_name'] = $item->getData('name');
                $bitemInfo[$item->getData('item_id')]['id'] = $item->getData('product_id');
                
                $sku = $item->getData('sku');
                $sku = str_replace("_CK","",$sku);
                $sku = str_replace("_EB","",$sku);
                
                $bitemInfo[$item->getData('item_id')]['sku'] = $sku;
                $bitemInfo[$item->getData('item_id')]['qty'] = round($item->getData('qty_ordered'));
                $bitemInfo[$item->getData('item_id')]['weight'] = $item->getData('weight');
                $bitemInfo[$item->getData('item_id')]['price'] = $item->getData('price');
                $bitemInfo[$item->getData('item_id')]['tax'] = $item->getData('tax_amount');
                $bitemInfo[$item->getData('item_id')]['discount'] = $item->getData('discount_amount');
                $bitemInfo[$item->getData('item_id')]['final_price'] = $item->getData('price');
            } elseif (array_key_exists('bundle_selection_attributes', $bundle_selection)) {
                $simple_info = unserialize($bundle_selection['bundle_selection_attributes']);
                $bitemLineInfo[$bitemLineNumber]['product_name'] = $item->getData('name');
                $bitemLineInfo[$bitemLineNumber]['id'] = $item->getData('product_id');
                
                $sku = $item->getData('sku');
                $sku = str_replace("_CK","",$sku);
                $sku = str_replace("_EB","",$sku);
                
                $bitemLineInfo[$bitemLineNumber]['sku'] = $sku;
                $bitemLineInfo[$bitemLineNumber]['qty'] = round($simple_info['qty']);
                $bitemLineInfo[$bitemLineNumber]['weight'] = $item->getData('weight');
                $bitemLineInfo[$bitemLineNumber]['price'] = $item->getData('price');
                $bitemLineInfo[$bitemLineNumber]['tax'] = $item->getData('tax_amount');
                $bitemLineInfo[$bitemLineNumber]['discount'] = $item->getData('discount_amount');
                $bitemLineInfo[$bitemLineNumber]['final_price'] = $item->getData('price');
                $bitemLineInfo[$bitemLineNumber]['imei_no'] = "";
                $bitemLineInfo[$bitemLineNumber]['serial_no'] = "";
                $bitemLineInfo[$bitemLineNumber]['cust_item'] = "";

                $bitemLineInfo[$bitemLineNumber]['parent_id'] = $item->getData('parent_item_id');
                $bitemLineNumber++;
                $totalItemCount++;

                /*
                //As request specfic flow for france is commented
                $prod = $this->_productRepository->get($item->getData('sku'));
                if($prod->getData('attribute_set_id') == self::PHONE_ATTRIBUTE_SET_ID && $order->getData('store_id') == self::FRANCE_STORE_ID){
                    $bitemLineInfo[$bitemLineNumber]['product_name'] = self::EARPHONE_NAME;
                    $bitemLineInfo[$bitemLineNumber]['id'] = self::EARPHONE_ID;
                    
                    $sku = self::EARPHONE_SKU;
                    $sku = str_replace("_CK","",$sku);
                    $sku = str_replace("_EB","",$sku);
                    
                    $bitemLineInfo[$bitemLineNumber]['sku'] = $sku;
                    $bitemLineInfo[$bitemLineNumber]['qty'] = round($simple_info['qty']);
                    $bitemLineInfo[$bitemLineNumber]['weight'] = self::EARPHONE_WEIGHT;
                    $bitemLineInfo[$bitemLineNumber]['price'] = "0.0000";
                    $bitemLineInfo[$bitemLineNumber]['tax'] = "0.0000";
                    $bitemLineInfo[$bitemLineNumber]['discount'] = "0.0000";
                    $bitemLineInfo[$bitemLineNumber]['final_price'] = "0.0000";
                    $bitemLineInfo[$bitemLineNumber]['imei_no'] = "";
                    $bitemLineInfo[$bitemLineNumber]['serial_no'] = "";
                    $bitemLineInfo[$bitemLineNumber]['cust_item'] = "";

                    $bitemLineInfo[$bitemLineNumber]['parent_id'] = $item->getData('parent_item_id');
                    $bitemLineNumber++;
                    $totalItemCount++;
                }
                */
            } else {
                $itemInfo[$itemLineNumber]['product_name'] = $item->getData('name');
                $itemInfo[$itemLineNumber]['id'] = $item->getData('product_id');
                
                $sku = $item->getData('sku');
                $sku = str_replace("_CK","",$sku);
                $sku = str_replace("_EB","",$sku);
                
                $itemInfo[$itemLineNumber]['sku'] = $sku;
                $itemInfo[$itemLineNumber]['qty'] = round($item->getData('qty_ordered'));
                $itemInfo[$itemLineNumber]['weight'] = $item->getData('weight');
                $itemInfo[$itemLineNumber]['price'] = $item->getData('price');
                $itemInfo[$itemLineNumber]['tax'] = $item->getData('tax_amount');
                $itemInfo[$itemLineNumber]['discount'] = $item->getData('discount_amount');
                $itemInfo[$itemLineNumber]['final_price'] = $item->getData('price');
                $itemInfo[$itemLineNumber]['imei_no'] = "";
                $itemInfo[$itemLineNumber]['serial_no'] = "";
                $itemInfo[$itemLineNumber]['cust_item'] = "";

                //$itemInfo[$itemLineNumber]['parent_id'] = $item->getData('parent_item');
                $itemLineNumber++;
                $totalItemCount++;
                
                /*
                //As request specfic flow for france is commented
                $prod = $this->_productRepository->get($item->getData('sku'));
                if($prod->getData('attribute_set_id') == self::PHONE_ATTRIBUTE_SET_ID && $order->getData('store_id') == self::FRANCE_STORE_ID){
                    $itemInfo[$itemLineNumber]['product_name'] = self::EARPHONE_NAME;
                    $itemInfo[$itemLineNumber]['id'] = self::EARPHONE_ID;
                    
                    $sku = self::EARPHONE_SKU;
                    $sku = str_replace("_CK","",$sku);
                    $sku = str_replace("_EB","",$sku);
                    
                    $itemInfo[$itemLineNumber]['sku'] = $sku;
                    $itemInfo[$itemLineNumber]['qty'] = round($item->getData('qty_ordered'));
                    $itemInfo[$itemLineNumber]['weight'] = self::EARPHONE_WEIGHT;
                    $itemInfo[$itemLineNumber]['price'] = "0.0000";
                    $itemInfo[$itemLineNumber]['tax'] = "0.0000";
                    $itemInfo[$itemLineNumber]['discount'] = "0.0000";
                    $itemInfo[$itemLineNumber]['final_price'] = "0.0000";
                    $itemInfo[$itemLineNumber]['imei_no'] = "";
                    $itemInfo[$itemLineNumber]['serial_no'] = "";
                    $itemInfo[$itemLineNumber]['cust_item'] = "";

                    //$bitemLineInfo[$itemLineNumber]['parent_id'] = $item->getData('parent_item_id');
                    $itemLineNumber++;
                    $totalItemCount++;
                }
                */
            }
        }

        $fBundle = [];
        $i = 1;
        foreach ($bitemInfo as $bItemK => $bItemV) {
            $fBundle['mainbundle_' . $i] = $bItemV;
            foreach ($bitemLineInfo as $bLineItem) {
                if ($bItemK == $bLineItem['parent_id']) {
                    //$fBundle['mainbundle_' . $i]['bundle_items'][] = $bItemV;
                    //$bLineItem['parent_id']    = $bItemV['id'];
                    unset($bLineItem['parent_id']);
                    $fBundle['mainbundle_' . $i]['bundle_items'][] = $bLineItem;
                }
            }
            $i++;
        }
        $orderDetail['order_no'] = $order->getData('increment_id');

        $createdDate = date(DATE_ATOM, strtotime(($order->getData('created_at'))));

        $orderDetail['order_date'] = $createdDate;
        $orderDetail['total_item_count'] = $totalItemCount;
        $orderDetail['currency'] = $order->getData('store_currency_code');
        $orderDetail['weight'] = $order->getData('weight');
        $orderDetail['payment_method'] = $methodTitle;
        if ($earlBrown) {
            $orderDetail['authorization_code'] = $authCode;
        }
        $orderDetail['shipping_method'] = $order->getData('shipping_description');
        $orderDetail['customer_note'] = "";
        $orderDetail['vat'] = $order->getData('customer_taxvat');
        $orderDetail['grand_total'] = $order->getData('base_grand_total');
        $orderDetail['shipping_cost'] = $order->getData('shipping_amount');
        $orderDetail['discount'] = $order->getData('base_discount_amount');
        $orderDetail['tax'] = $order->getData('base_tax_amount');
        $orderDetail['paid_amount'] = $order->getData('base_total_paid');
        $orderDetail['store_brand'] = $webstoreName;
        $orderDetail['store_country'] = $countryname;
        $orderDetail['cust_order'] = "";
        $orderDetail['note'] = "";

        $orderDetail['billing_address']['first_name'] = $billingaddress->getData('firstname');
        $orderDetail['billing_address']['last_name'] = $billingaddress->getData('lastname');
        $orderDetail['billing_address']['street_address_1'] = $billStreet1;
        $orderDetail['billing_address']['street_address_2'] = $billStreet2;
        $orderDetail['billing_address']['city'] = $billingaddress->getData('city');
        $orderDetail['billing_address']['state'] = $billingaddress->getData('region');
        $orderDetail['billing_address']['country'] = $billingCountryName;
        $orderDetail['billing_address']['zip_code'] = $billingaddress->getData('postcode');
        $orderDetail['billing_address']['telephone'] = $billingaddress->getData('telephone');
        $orderDetail['billing_address']['fax'] = $billingaddress->getData('fax');
        $orderDetail['billing_address']['email'] = $billingaddress->getData('email');

        $orderDetail['shipping_address']['first_name'] = $shippingaddress->getData('firstname');
        $orderDetail['shipping_address']['last_name'] = $shippingaddress->getData('lastname');
        $orderDetail['shipping_address']['street_address_1'] = $shippStreet1;
        $orderDetail['shipping_address']['street_address_2'] = $shippStreet2;
        $orderDetail['shipping_address']['city'] = $shippingaddress->getData('city');
        $orderDetail['shipping_address']['state'] = $shippingaddress->getData('region');
        $orderDetail['shipping_address']['country'] = $shippingCountryName;
        $orderDetail['shipping_address']['zip_code'] = $shippingaddress->getData('postcode');
        $orderDetail['shipping_address']['telephone'] = $shippingaddress->getData('telephone');
        $orderDetail['shipping_address']['fax'] = $shippingaddress->getData('fax');
        $orderDetail['shipping_address']['email'] = $shippingaddress->getData('email');

        $orderDetail['order_items']['items'] = $itemInfo;
        $orderDetail['order_items']['bundles'] = $fBundle;

        $fileCreated = $this->_arrayToXml->generteXml($orderDetail, $xmlLocalPath, self::ROOT_NODE);

        if ($fileCreated) {
            $fileUploaded = $this->_uploadSftp->uploadFileSftp($xmlLocalPath, $sftpPath, $fileNameOnSftp, $earlBrown, $logger);
        }

/*
        if ($fileCreated) {
            $fileUploaded = $this->_uploadSftp->uploadFileSftp($xmlLocalPath, $sftpPath, $fileNameOnSftp, $earlBrown, $logger);
        }
*/

        if ($fileCreated) {
            $bkupDir = $pubDir."/Order-XML-bkup/";
            if (!is_dir($bkupDir)) {
                $oldmask = umask(0);
                mkdir($bkupDir, 0775);
                umask($oldmask);
            }

            $xmlBKUPLocalPath = $bkupDir.$fileName;
            
            $copy = copy( $xmlLocalPath, $xmlBKUPLocalPath );
            if( !$copy ) {
                $logger->info('==== Error : Bkup file ====');
            }
            else{
                $logger->info('==== Bkup created ====');
                
            }

            $logger->info('==== XML file created on rsync ====');
            $connection = $this->_resource->getConnection();
            $tableName = $this->_resource->getTableName('threepl_orders');

            $order_nos = $orderDetail['order_no'];
            if($earlBrown){
                $eb_ck = 'eb';
            }else{
                $eb_ck = 'ck';
            }
            $sql = "INSERT INTO " . $tableName . " (`order_id`, `completed`, `eb_ck`, `file_name`, `current_time`) VALUES ($order_nos, 0, '$eb_ck', '$fileName', now())";
            $connection->query($sql);

        } else {
            $logger->info('==== Error : XML file creation ====');
        }
    }

}

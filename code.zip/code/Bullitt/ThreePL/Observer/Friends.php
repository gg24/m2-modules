<?php

namespace Bullitt\ThreePL\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Customer\Model\Session;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class Friends implements ObserverInterface {

    protected $_resource;
    protected $_customer;

    /**
     * @param ResourceConnection $resource
     */
    public function __construct(ResourceConnection $resource, Session $customer
    ) {
        $this->_resource = $resource;
        $this->_customer = $customer;
    }

    /**
     * define execution of observer
     */
    public function execute(Observer $observer) {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/Friends.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        $couponCode = '';
        $customerEmail = '';
        $quote = $observer->getData('quote');
        $couponCode = $quote->getCouponCode();

        if ($this->_customer->isLoggedIn()) {
            $customerEmail = $this->_customer->getCustomer()->getEmail();
        } else {
            $customerEmail = $quote->getShippingAddress()->getEmail();
        }

        if ($couponCode != '') {
            $connection = $this->_resource->getConnection();
            $tableName = $this->_resource->getTableName('coupon_email');
            $sql = "Select * From " . $tableName . " where `coupon_code` = '$couponCode'";
            //$logger->info($sql);
            $result = $connection->fetchAll($sql);
            if (isset($result)) {
                foreach ($result as $data) {
                    $couponEmail = $data['email'];
                }
                if(isset($couponEmail) && $couponEmail!='') {
                    $logger->info($couponEmail);
                    $logger->info($customerEmail);
                    $logger->info($couponCode);
                    if ($couponEmail != $customerEmail) {
                        try {
                            $quote->setCouponCode('');
                            $quote->collectTotals()->save();
                            throw new NoSuchEntityException(__('Coupon code is not valid '));
                        } catch (\Exception $e) {
                            throw new CouldNotSaveException(__('Could not apply coupon code'));
                        }
                        return false;
                    }
                    return true;
                }
                return true;
            }
            return;
        }

        return;
    }

}

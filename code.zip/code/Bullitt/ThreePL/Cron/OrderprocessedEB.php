<?php

namespace Bullitt\ThreePL\Cron;

use Bullitt\ThreePL\Model\Orderprocessm;
use Bullitt\Salesforce\Helper\UpdateProcessedSF;

class OrderprocessedEB {

    protected $_processed;
    protected $_processedHelper;

    public function __construct(
        Orderprocessm $processed, UpdateProcessedSF $processedHelper
    ) {
        $this->_processed = $processed;
        $this->_processedHelper = $processedHelper;
    }

    /**
     * execute
     * @return \Magento\Framework\Controller\Result\Json
     */
    public function execute() {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/OrderProcessedEB.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Cron Auto Run');

        $earlBrown = true;
        $response = $this->_processed->orderProcessedXML($logger, $earlBrown);
        
        if ($response) {
            if($this->_processedHelper->updateProcessedInfoToSF($logger)){
                $logger->info('--Processed SF Done --');
            }else{
                $logger->info('--Processed SF Not Done--');
            }

            $logger->info('Order Processed Success EB');            
        } else {
            $logger->info('Order Processed Fails EB');
        }
    }
}
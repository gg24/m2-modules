<?php
namespace Bullitt\ThreePL\Cron;

use Bullitt\ThreePL\Model\UpdateInventorym;

class UpdateinventoryEB {

    protected $_inventory;

    /**
     * @param UpdateInventorym $inventory
     */
    public function __construct(
    UpdateInventorym $inventory
    ) {
        $this->_inventory = $inventory;
    }

    /**
     * execute
     * @return \Magento\Framework\Controller\Result\Json
     */
    public function execute() {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/InventoryUpdateEB.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Cron Auto Run');
        $earlBrown = true;
        $response = $this->_inventory->updateInventoryXML($logger, $earlBrown);

        if ($response) {
            $logger->info('Inv Update Success EB');            
        } else {
            $logger->info('Inv Update Fails EB');
        }
    }

}
<?php

namespace Bullitt\ThreePL\Model;

use Magento\Framework\Xml\Parser;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Sales\Model\Order;
use Bullitt\ThreePL\Helper\DownloadSftp;
use Bullitt\ThreePL\Helper\XmlValidator;
use Bullitt\ThreePL\Helper\UpdateImie;
use Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Sales\Model\Order\ShipmentFactory;
use Magento\Framework\DB\TransactionFactory;
use Magento\Sales\Model\Order\Shipment\TrackFactory;
use Magento\Shipping\Model\ShipmentNotifier;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;
use Magento\Framework\App\ResourceConnection;

class Orderdispatchm {

    const ORDER_DISPATCH_LOCAL_DIR_EB = '3PL/earlbrown/Order/Dispatched';
    const ORDER_DISPATCH_SFTP_DIR_EB = 'earlbrown/Order/Dispatched';
    const ORDER_DISPATCH_XMLREAD_LOCAL_DIR_EB = '3PL/earlbrown/Order/XMLRead';
    const ORDER_DISPATCH_XMLREAD_SFTP_DIR_EB = 'earlbrown/Order/XMLRead';
    const ORDER_DISPATCH_LOCAL_DIR_CK = '3PL/charleskendall/Order/Dispatched';
    const ORDER_DISPATCH_SFTP_DIR_CK = 'charleskendall/Order/Dispatched';
    const ORDER_DISPATCH_XMLREAD_LOCAL_DIR_CK = '3PL/charleskendall/Order/XMLRead';
    const ORDER_DISPATCH_XMLREAD_SFTP_DIR_CK = 'charleskendall/Order/XMLRead';
    const XML_VALIDATOR_PATH = '3PL/validator/OrderDispatched.xsd';

    protected $_directory_list;
    protected $_downloadSftp;
    protected $_parser;
    protected $_date;
    protected $_xmlValidator;
    protected $_order;
    protected $_notifier;
    protected $_updateImie;
    protected $_invoiceSender;
    protected $_resource;

    /* @var \Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory */
    protected $invoiceCollectionFactory;

    /* @var \Magento\Sales\Model\Service\InvoiceService */
    protected $invoiceService;

    /* @var \Magento\Sales\Model\Order\ShipmentFactory */
    protected $shipmentFactory;

    /* @var \Magento\Framework\DB\TransactionFactory */
    protected $transactionFactory;

    /* @var \Magento\Sales\Model\Order\Shipment\TrackFactory */
    protected $trackFactory;

    /**
     * @param Parser $parser,
     * @param DirectoryList $directory_list
     * @param DownloadSftp $downloadSftp
     * @param DateTime $date
     * @param Order $orderObject 
     * @param XmlValidator $xmlValidator
     * @param CollectionFactory $invoiceCollectionFactory
     * @param InvoiceService $invoiceService
     * @param ShipmentFactory $shipmentFactory
     * @param TransactionFactory $transactionFactory
     * @param TrackFactory $trackFactory
     */
    public function __construct(
    Parser $parser, DirectoryList $directory_list, DateTime $date, Order $orderObject, DownloadSftp $downloadSftp, XmlValidator $xmlValidator, CollectionFactory $invoiceCollectionFactory, ShipmentFactory $shipmentFactory, InvoiceService $invoiceService, TransactionFactory $transactionFactory, TrackFactory $trackFactory, ShipmentNotifier $notifier, UpdateImie $updateImie, InvoiceSender $invoiceSender,  ResourceConnection $resource
    ) {
        $this->_parser = $parser;
        $this->_directory_list = $directory_list;
        $this->_date = $date;
        $this->_order = $orderObject;
        $this->_downloadSftp = $downloadSftp;
        $this->_xmlValidator = $xmlValidator;
        $this->_invoiceSender = $invoiceSender;
        $this->invoiceCollectionFactory = $invoiceCollectionFactory;
        $this->invoiceService = $invoiceService;
        $this->shipmentFactory = $shipmentFactory;
        $this->transactionFactory = $transactionFactory;
        $this->trackFactory = $trackFactory;
        $this->_notifier = $notifier;
        $this->_updateImie = $updateImie;
        $this->_resource = $resource;
    }

    public function orderDispatchXML($logger, $earlBrown) {
        
        $currentDateTime = date(DATE_ATOM, strtotime($this->_date->date()));

        $pubDir = $this->_directory_list->getPath('var');
        $xsdLocalPath = $pubDir . '/' . self::XML_VALIDATOR_PATH;

        if ($earlBrown) {
            $xmlLocalPath = $pubDir . '/' . self::ORDER_DISPATCH_LOCAL_DIR_EB . '/';
            $sftpPath = self::ORDER_DISPATCH_SFTP_DIR_EB . '/';
            $mvSftpFilePath = self::ORDER_DISPATCH_XMLREAD_SFTP_DIR_EB . '/';
        } else {
            $xmlLocalPath = $pubDir . '/' . self::ORDER_DISPATCH_LOCAL_DIR_CK . '/';
            $sftpPath = self::ORDER_DISPATCH_SFTP_DIR_CK . '/';
            $mvSftpFilePath = self::ORDER_DISPATCH_XMLREAD_SFTP_DIR_CK . '/';
        }

        $fileDownloaded = $this->_downloadSftp->downloadFileSftp($xmlLocalPath, $sftpPath, $mvSftpFilePath, $logger, $earlBrown);

        if (is_array($fileDownloaded) && !empty($fileDownloaded)) {
            foreach ($fileDownloaded as $fileName) {
                $logger->info($fileName . ' : Downloaded');
                $validated = $this->_xmlValidator->validateXmlFile($xsdLocalPath, $xmlLocalPath . $fileName, $logger);
                if ($validated == true) {
                    $parsedArray = $this->_parser->load($xmlLocalPath . $fileName)->xmlToArray();
                    //$parsedArray = $this->_parser->load($xmlLocalPath . 'order2.xml')->xmlToArray();
                    if($this->updateStatusUpdate($parsedArray['order_ship'], $logger)){
                        if ($earlBrown) {
                            $logger->info('==== Order dispatch  earlBrown====');
                            $logger->info($parsedArray['order_ship']['service']);
                            $logger->info($parsedArray['order_ship']['tracking_no']);
                        } else {
                            $logger->info('==== Order dispatch CK ====');
                            $logger->info($parsedArray['order_ship']['service']);
                            $logger->info($parsedArray['order_ship']['tracking_no']);
                        }
                    }
                } else {
                    $logger->info('==== Order dispatch Not valid Fail ====');
                }
            }
        } else {
            $logger->info( ' Order dispatch : NOT Downloaded');
            //echo 'File is not downloaded';
            return false;
        }
        return true;
    }

    /**
     * reindexData : reindex everything after new import
     */
    public function updateStatusUpdate($xmlInfo, $logger) {
        //echo '<pre>'; print_r($xmlInfo); //die('sdfsdf');        
        if (count($xmlInfo) > 0) {
            $logger->info('==== Order Processed Start ====');
            $order = $this->_order->loadByIncrementId($xmlInfo['order_no']);
            $invoice = $this->createInvoice($order, $logger);
            if($invoice) {
               $shipped = $this->createShipment($order, $invoice, $xmlInfo, $logger);
               if($shipped){
                   $items = $order->getItemsCollection();
                   $this->_updateImie->updatePhoneImie($items, $xmlInfo['shipped_items'], $logger);

                    $connection = $this->_resource->getConnection();
                    $tableName  = $this->_resource->getTableName('trigger_sf_after_dispatch');

                    $order_id   = $xmlInfo['order_no'];
                    $orderStatus   = 'Dispatched';

                    $sql = "INSERT INTO " . $tableName . " (`order_status`,`send_sales_force`,`order_id`) VALUES ('$orderStatus',0,'$order_id')";
                    
                    try {
                        $connection->query($sql);
                        $logger->info('----insert flag on trigger_sf_after_dispatch table---');
                    } catch (\Exception $e) {
                        $logger->info($e->getMessage());
                    }
               }
            }
            $logger->info('==== Order Processed End ====');
        }
        return true;
    }

    public function createInvoice($order, $logger) {
        try {
            $invoices = $this->invoiceCollectionFactory->create()->addAttributeToFilter('order_id', array('eq' => $order->getId()));

            $invoices->getSelect()->limit(1);

            if ((int) $invoices->count() !== 0) {
                return null;
            }

            if (!$order->canInvoice()) {
                return null;
            }

            $invoice = $this->invoiceService->prepareInvoice($order);
            $invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_OFFLINE);
            $invoice->register();
            $invoice->getOrder()->setCustomerNoteNotify(false);
            $invoice->getOrder()->setIsInProcess(true);
            $order->addStatusHistoryComment('Automatically INVOICED', false);
            $transactionSave = $this->transactionFactory->create()->addObject($invoice)->addObject($invoice->getOrder());
            $transactionSave->save();
            
            // Magento\Sales\Model\Order\Email\Sender\InvoiceSender
            $this->_invoiceSender->send($invoice, true);
            $order->addStatusHistoryComment(
                __('Notified customer about invoice #%1.', $invoice->getId())
            )->setIsCustomerNotified(true)->save();
            
        } catch (\Exception $e) {
            $logger->info($e->getMessage());
            $order->addStatusHistoryComment('Exception message: ' . $e->getMessage(), false);
            $order->save();
            return null;
        }

        return $invoice;
    }

    public function createShipment($order, $invoice, $xmlInfo, $logger) {
        try {
            $shipment = $this->prepareShipment($invoice, $xmlInfo, $logger);
            if ($shipment) {
                $order->setIsInProcess(true);
                $order->setCustomTrackingNo($xmlInfo['tracking_no']);
                $order->setCustomTrackingUrl($xmlInfo['service']);
                $order->addStatusHistoryComment('Automatically SHIPPED', false);
                $this->transactionFactory->create()->addObject($shipment)->addObject($shipment->getOrder())->save();
                // Send email
                $this->_notifier->notify($shipment);
            }
        } catch (\Exception $e) {
            $order->addStatusHistoryComment('Exception message: ' . $e->getMessage(), false);
            $order->save();
            return null;
        }
        return true;
    }

    public function prepareShipment($invoice, $xmlInfo, $logger) {
        $shipment = $this->shipmentFactory->create(
                $invoice->getOrder(), []
        );
        
        $data = array(
            'carrier_code' => 'custom',
            'title' => $xmlInfo['service'],
            'number' => $xmlInfo['tracking_no'],
        );
        
        $track = $this->trackFactory->create()->addData($data);
        $shipment->addTrack($track);
        return $shipment->getTotalQty() ? $shipment->register() : false;
    }

}

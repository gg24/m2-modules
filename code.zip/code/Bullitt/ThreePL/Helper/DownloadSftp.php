<?php

namespace Bullitt\ThreePL\Helper;

use Magento\Store\Model\Store;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Filesystem\Io\Sftp;
use Magento\Framework\Filesystem\Io\File;
use Bullitt\ThreePL\Helper\SftpDetails;
use Magento\Framework\Stdlib\DateTime\DateTime;

class DownloadSftp extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_sftp;
    protected $_file;
    protected $_sftpDetails;
    protected $_date;

    /**
     * @param Context $context
     * @param Sftp $sftp
     * @param SftpDetails $sftpDetails
     * @param File $file
     */
    public function __construct(
    Context $context, Sftp $sftp, SftpDetails $sftpDetails, File $file, DateTime $date
    ) {
        $this->_sftp = $sftp;
        $this->_file = $file;
        $this->_sftpDetails = $sftpDetails;
        $this->_date = $date;
        parent::__construct($context);
    }

    /**
     * download File From Sftp
     * @param string $xmlLocalPath
     * @param string $sftpPath
     * @param string $fileNameOnSftp
     * @param string $destinationPath
     * @param object $logger
     * 
     * @return boolean
     */
    public function downloadFileSftp($xmlLocalPath, $sftpPath, $xmlReadPath, $logger, $earlBrown) {

        if ($earlBrown) {
            $details = $this->_sftpDetails->getEBConfig();
        } else {
            $details = $this->_sftpDetails->getCKConfig();
        }

        $currentDateTime = date(DATE_ATOM, strtotime($this->_date->date()));
        $fileNames = [];
        try {
            $this->_sftp->open($details);
            $this->_sftp->cd($sftpPath);
            $filesList = $this->_sftp->ls();
            foreach ($filesList as $file) {
                $fileNames[] = $file['text'];
            }
            $fileNames = array_diff($fileNames, array('..', '.'));
            foreach ($fileNames as $fileNameOnSftp) {
                if ($fileNameOnSftp != "") {
                    $fileImportRemoteTmp = $this->_sftp->read($fileNameOnSftp);
                    if (!$this->_file->write($xmlLocalPath . $fileNameOnSftp, $fileImportRemoteTmp)) {
                        $logger->info('Fail to Download XML downloadFileSftp');
                    } else {
                        $logger->info('XML Downloaded ');
                        $this->_sftp->cd('../../..');
                        $sourcePath = $sftpPath . $fileNameOnSftp;
                        $destinationPath = $xmlReadPath . $fileNameOnSftp;
                        if (stripos($fileNameOnSftp, 'Inventory') !== false) {
                            $destinationPath = $xmlReadPath . $currentDateTime ."_".$fileNameOnSftp;
                        }

                        //echo '<br/>SFTP xml source Path : ' .  $sourcePath; 
                        //echo '<br/>SFTP xml destination Path : ' . $destinationPath; 

                        if (!$this->_sftp->mv($sourcePath, $destinationPath)) {
                            $logger->info('XML File Move Fail, SFTP');
                        } else {
                            $logger->info('XML File Move To XMLRead Dir');
                        }
                        $this->_sftp->cd($sftpPath);
                    }
                } else {
                    $logger->info('File Not Found on Sftp: ' . $fileNameOnSftp);
                    return false;
                }
            }

            $this->_sftp->close();

            return $fileNames;
        } catch (\Exception $e) {
            //echo $e->getMessage();
            $logger->info('SFTP Exception');
            $logger->info($e->getMessage());
            return false;
        }
    }

}

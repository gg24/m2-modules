<?php

namespace Bullitt\ThreePL\Helper;

class XmlValidator extends \Magento\Framework\App\Helper\AbstractHelper {

    public function validateXmlFile($xsdPath, $xmlPath, $logger) {
        //echo '<br/> xsd Path : '. $xsdPath;
        //echo '<br/>xml Path : '. $xmlPath;        
        // Enable user error handling 
        libxml_use_internal_errors(true);
        $xml = new \DOMDocument();

        $xml->load($xmlPath);
        if (!$xml->schemaValidate($xsdPath)) {
            $logger->info('XML Validation fails');
            $this->libxml_display_errors($logger);
            return false;
        } else {
            $logger->info('XML Validated');
            return true;
        }
    }

    public function libxml_display_error($error) {
        $return = " ";
        switch ($error->level) {
            case LIBXML_ERR_WARNING:
                $return .= "Warning $error->code : ";
                break;
            case LIBXML_ERR_ERROR:
                $return .= "Error $error->code : ";
                break;
            case LIBXML_ERR_FATAL:
                $return .= "Fatal Error $error->code : ";
                break;
        }
        $return .= trim($error->message);
        if ($error->file) {
            $return .= " in $error->file";
        }
        $return .= " on line $error->line \n";
        return $return;
    }

    public function libxml_display_errors($logger) {
        $errors = libxml_get_errors();
        foreach ($errors as $error) {
            $logger->info($this->libxml_display_error($error));
        }
        libxml_clear_errors();
    }

}

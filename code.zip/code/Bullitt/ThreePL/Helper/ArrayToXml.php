<?php

namespace Bullitt\ThreePL\Helper;

use Magento\Store\Model\Store;

class ArrayToXml extends \Magento\Framework\App\Helper\AbstractHelper{

    /**
     * generteXml file from array
     * @param array $array
     * @param string $xmlLocalPath
     * @param string $rootNode
     * 
     * @return boolean
     */
    public function generteXml($array, $xmlLocalPath, $rootNode) {
        $xml_order_info = new \SimpleXMLElement("<?xml version=\"1.0\"?>$rootNode");
        $xml_order_info = $this->array_to_xml($array, $xml_order_info);
        $xml_file = $xml_order_info->saveXML($xmlLocalPath);
        
        if($xml_file){
            return true;
        }
        return true;       
    }

    /**
     * array_to_xml conversion from array
     * @param array $array
     * @param object $xml_order_info
     * @param string $rootNode
     * 
     * @return boolean
     */
    public function array_to_xml($array, &$xml_order_info) {
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                if (!is_numeric($key)) {
                    if (substr($key, 0, 11) === 'mainbundle_') {
                        $subnode = $xml_order_info->addChild("bundle");
                        $this->array_to_xml($value, $subnode);
                    } else {
                        $subnode = $xml_order_info->addChild("$key");
                        $this->array_to_xml($value, $subnode);
                    }
                } else {
                    $subnode = $xml_order_info->addChild("item");
                    $this->array_to_xml($value, $subnode);
                }
            } else {
                $xml_order_info->addChild("$key", htmlspecialchars("$value"));
            }
        }
        return $xml_order_info;
    }

}

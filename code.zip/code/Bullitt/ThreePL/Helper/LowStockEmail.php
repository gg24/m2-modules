<?php

namespace Bullitt\ThreePL\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Reports\Model\ResourceModel\Product\Lowstock\CollectionFactory;
use Magento\Framework\App\Area;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Escaper;

class LowStockEmail extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_lowstocksFactory;
    protected $_transportBuilder;
    protected $_inlineTranslation;
    protected $_escaper;

    /**
     * @param Context $context
     * @param CollectionFactory $lowstocksFactory
     */
    public function __construct(
    Context $context, CollectionFactory $lowstocksFactory, TransportBuilder $transportBuilder, StateInterface $inlineTranslation, Escaper $escaper
    ) {
        $this->_lowstocksFactory = $lowstocksFactory;
        $this->_transportBuilder = $transportBuilder;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_escaper = $escaper;
        parent::__construct($context);
    }

    /**
     * sendEmailToAdmin     * 
     */
    public function sendEmailToAdmin() {

        $collection = $this->_lowstocksFactory->create()->addAttributeToSelect(
                        '*'
                )->filterByIsQtyProductTypes()->joinInventoryItem(
                        'qty'
                )->useManageStockFilter(
                        \Magento\Store\Model\Store::DEFAULT_STORE_ID
                )->useNotifyStockQtyFilter(
                        \Magento\Store\Model\Store::DEFAULT_STORE_ID
                )->setOrder(
                'qty', \Magento\Framework\Data\Collection::SORT_ORDER_ASC
        );

        $this->collectEmailDetails($collection);
    }

    /**
     * sendEmailToAdmin     * 
     */
    public function collectEmailDetails($collection) {

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/LowstockEmail.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        $emailSender = $this->getEmailSender();

        if (($collection->getSize() > 0) && $emailSender && $emailSender != '') {
            $subject = "Low Stock Notification";

            $emailTo = $this->getEmailID();
            $emailIDs = explode(",", $emailTo);
            
            $emailTemplate = $this->getEmailTemplate();
            $nameSender = $this->getNameSender();

            $msg = '';
            foreach ($collection as $item) {
                $sku = '';
                $qty = '';
                $sku = $item->getData('sku');
                $qty = round($item->getData('qty'));
                $msg .= 'Quantity  =  ' . $qty . ',  SKU = ' . $sku . "\r\n";
            }

            $emailInfo = [
                'subject' => $subject,
                'email_sender' => $emailSender,
                'name_sender' => $nameSender,
                'to_email' => $emailIDs,
                'email_template' => $emailTemplate,
                'msg' => $msg
            ];
            $this->sendEmail($emailInfo, $collection, $logger);
        }
    }

    private function sendEmail($info, $collection, $logger) {

        $logger->info('send email');
        
        $data = [
            'subject' => $info['subject'],
            'msg' => $info['msg']
        ];

        $this->_inlineTranslation->suspend();

        try {
            $error = false;

            $sender = [
                'name' => $this->_escaper->escapeHtml($info['name_sender']),
                'email' => $this->_escaper->escapeHtml($info['email_sender']),
            ];

            $transport = $this->_transportBuilder->setTemplateIdentifier($info['email_template'])
                    ->setTemplateOptions([
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ])
                    ->setTemplateVars($data)
                    ->setFrom($sender)
                    ->addTo($info['to_email'])
                    ->getTransport();

            $transport->sendMessage();
            $logger->info('-----email sent to admin-----');
            $this->_inlineTranslation->resume();
        } catch (\Exception $e) {
            $logger->info($e->getMessage());
            $this->_inlineTranslation->resume();
        }
    }

    public function getSender() {
        return $this->scopeConfig->getValue(
                        'low_stock_email/low_stock_group/email_sender', \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getEmailSender() {
        $sender = $this->getSender();

        return $this->scopeConfig->getValue(
                        'trans_email/ident_' . $sender . '/email', \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getEmailID() {
        return $this->scopeConfig->getValue(
                        'low_stock_email/low_stock_group/email_reciver_ids', \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getEmailTemplate() {
        return $this->scopeConfig->getValue(
                        'low_stock_email/low_stock_group/email_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getNameSender() {
        $sender = $this->getSender();

        return $this->scopeConfig->getValue(
                        'trans_email/ident_' . $sender . '/name', \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

}

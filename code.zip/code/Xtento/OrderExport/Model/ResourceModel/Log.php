<?php

/**
 * Product:       Xtento_OrderExport (2.5.1)
 * ID:            0n3LWDEZ4CR4J0boDJL2nidontPA5OkyR0uG3+vb6z0=
 * Packaged:      2018-03-12T10:50:21+00:00
 * Last Modified: 2015-10-11T13:28:37+00:00
 * File:          app/code/Xtento/OrderExport/Model/ResourceModel/Log.php
 * Copyright:     Copyright (c) 2018 XTENTO GmbH & Co. KG <info@xtento.com> / All rights reserved.
 */

namespace Xtento\OrderExport\Model\ResourceModel;

class Log extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('xtento_orderexport_log', 'log_id');
    }
}

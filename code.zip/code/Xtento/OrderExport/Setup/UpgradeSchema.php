<?php

/**
 * Product:       Xtento_OrderExport (2.5.1)
 * ID:            0n3LWDEZ4CR4J0boDJL2nidontPA5OkyR0uG3+vb6z0=
 * Packaged:      2018-03-12T10:50:21+00:00
 * Last Modified: 2017-09-19T11:53:16+00:00
 * File:          app/code/Xtento/OrderExport/Setup/UpgradeSchema.php
 * Copyright:     Copyright (c) 2018 XTENTO GmbH & Co. KG <info@xtento.com> / All rights reserved.
 */

namespace Xtento\OrderExport\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

/**
 * @codeCoverageIgnore
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $connection = $setup->getConnection();

        if (version_compare($context->getVersion(), '2.3.7', '<')) {
            $connection->addIndex(
                $setup->getTable('xtento_orderexport_profile_history'),
                $setup->getIdxName('xtento_orderexport_profile_history', ['entity_id']),
                ['entity_id']
            );
        }

        $setup->endSetup();
    }
}

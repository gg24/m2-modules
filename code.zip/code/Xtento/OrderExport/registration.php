<?php

/**
 * Product:       Xtento_OrderExport (2.5.1)
 * ID:            0n3LWDEZ4CR4J0boDJL2nidontPA5OkyR0uG3+vb6z0=
 * Packaged:      2018-03-12T10:50:20+00:00
 * Last Modified: 2017-01-07T16:33:15+00:00
 * File:          app/code/Xtento/OrderExport/registration.php
 * Copyright:     Copyright (c) 2018 XTENTO GmbH & Co. KG <info@xtento.com> / All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Xtento_OrderExport',
    __DIR__
);

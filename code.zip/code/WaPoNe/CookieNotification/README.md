# WaPoNe_CookieNotification
Magento 2 extension to inform users about use and management of your website cookies